(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FaIcon",
    ()=>FaIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/free-brands-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$regular$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/free-regular-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/free-solid-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/react-fontawesome/dist/index.js [app-client] (ecmascript)");
// 'use client';
// import type { IconDefinition } from '@fortawesome/fontawesome-svg-core';
// import {
//   faFacebookF,
//   faGoogle,
//   faInstagram,
//   faLinkedinIn,
//   faTwitter,
//   faWhatsapp,
// } from '@fortawesome/free-brands-svg-icons';
// import { faSmile } from '@fortawesome/free-regular-svg-icons';
// import {
//   faBolt,
//   faBriefcase,
//   faBuilding,
//   faCalculator,
//   faChartLine,
//   faEnvelope,
//   faFileInvoiceDollar,
//   faGlobe,
//   faHandshake,
//   faHeadset,
//   faHouse,
//   faInfoCircle,
//   faLeaf,
//   faLocationDot,
//   faPaperPlane,
//   faPhoneAlt,
//   faPiggyBank,
//   faShieldAlt,
//   faStoreAlt,
//   faTools,
//   faUser,
//   faUsers,
// } from '@fortawesome/free-solid-svg-icons';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// const iconMap: Record<string, IconDefinition> = {
//   'fas fa-bolt': faBolt,
//   'fas fa-building': faBuilding,
//   'fas fa-briefcase': faBriefcase,
//   'fas fa-calculator': faCalculator,
//   'fas fa-chart-line': faChartLine,
//   'fas fa-envelope': faEnvelope,
//   'fas fa-globe': faGlobe,
//   'fas fa-handshake': faHandshake,
//   'fas fa-headset': faHeadset,
//   'fa-solid fa-house': faHouse,
//   'fas fa-info-circle': faInfoCircle,
//   'fas fa-leaf': faLeaf,
//   'fas fa-paper-plane': faPaperPlane,
//   'fas fa-phone-alt': faPhoneAlt,
//   'fas fa-piggy-bank': faPiggyBank,
//   'fas fa-shield-alt': faShieldAlt,
//   'fas fa-tools': faTools,
//   'fas fa-users': faUsers,
//   'fas fa-store-alt': faStoreAlt,
//   'fas fa-file-invoice-dollar': faFileInvoiceDollar,
//   'fas fa-user': faUser,
//   'fab fa-facebook-f': faFacebookF,
//   'fa fa-facebook-f': faFacebookF,
//   'fab fa-instagram': faInstagram,
//   'fab fa-linkedin-in': faLinkedinIn,
//   'fa fa-linkedin-in': faLinkedinIn,
//   'fab fa-whatsapp': faWhatsapp,
//   'fa fa-google': faGoogle,
//   'fa fa-twitter': faTwitter,
//   'fab fa-twitter': faTwitter,
//   'far fa-smile': faSmile,
//   'fas fa-location-dot': faLocationDot,
// };
// export interface FaIconProps {
//   iconClass: string;
//   className?: string;
//   title?: string;
//   'aria-label'?: string;
//   [key: string]: any;
// }
// export function FaIcon({ iconClass, className, ...props }: FaIconProps) {
//   const icon = iconMap[iconClass];
//   if (!icon) {
//     console.warn(`FaIcon: ícone não mapeado para '${iconClass}'`);
//     return null;
//   }
//   return <FontAwesomeIcon icon={icon} className={className} {...props} />;
// }
'use client';
;
;
;
;
;
// Mapeamento blindado aceitando variações clássicas (fas) e modernas (fa-solid)
const iconMap = {
    'fas fa-bolt': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faBolt"],
    'fa-solid fa-bolt': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faBolt"],
    'fas fa-building': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faBuilding"],
    'fa-solid fa-building': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faBuilding"],
    'fas fa-briefcase': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faBriefcase"],
    'fa-solid fa-briefcase': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faBriefcase"],
    'fas fa-calculator': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faCalculator"],
    'fa-solid fa-calculator': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faCalculator"],
    'fas fa-chart-line': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faChartLine"],
    'fa-solid fa-chart-line': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faChartLine"],
    'fas fa-envelope': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faEnvelope"],
    'fa-solid fa-envelope': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faEnvelope"],
    'fas fa-globe': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faGlobe"],
    'fa-solid fa-globe': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faGlobe"],
    'fas fa-handshake': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faHandshake"],
    'fa-solid fa-handshake': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faHandshake"],
    'fas fa-headset': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faHeadset"],
    'fa-solid fa-headset': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faHeadset"],
    'fas fa-house': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faHouse"],
    'fa-solid fa-house': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faHouse"],
    'fas fa-info-circle': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faInfoCircle"],
    'fa-solid fa-info-circle': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faInfoCircle"],
    'fas fa-leaf': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLeaf"],
    'fa-solid fa-leaf': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLeaf"],
    'fas fa-paper-plane': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPaperPlane"],
    'fa-solid fa-paper-plane': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPaperPlane"],
    'fas fa-plus': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPlus"],
    'fa-solid fa-plus': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPlus"],
    'fas fa-minus': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faMinus"],
    'fa-solid fa-minus': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faMinus"],
    'fas fa-phone-alt': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPhone"],
    'fa-solid fa-phone': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPhone"],
    'fas fa-piggy-bank': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPiggyBank"],
    'fa-solid fa-piggy-bank': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPiggyBank"],
    'fas fa-shield-alt': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faShieldHalved"],
    'fa-solid fa-shield': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faShieldHalved"],
    'fas fa-tools': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faTools"],
    'fa-solid fa-tools': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faTools"],
    'fas fa-users': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faUsers"],
    'fa-solid fa-users': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faUsers"],
    'fas fa-store-alt': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faStore"],
    'fa-solid fa-store': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faStore"],
    'fas fa-file-invoice-dollar': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faFileInvoiceDollar"],
    'fa-solid fa-file-invoice-dollar': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faFileInvoiceDollar"],
    'fas fa-user': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faUser"],
    'fa-solid fa-user': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faUser"],
    'fab fa-facebook-f': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faFacebookF"],
    'fa fa-facebook-f': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faFacebookF"],
    'fab fa-instagram': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faInstagram"],
    'fab fa-linkedin-in': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLinkedinIn"],
    'fa fa-linkedin-in': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLinkedinIn"],
    'fab fa-whatsapp': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faWhatsapp"],
    'fa fab-whatsapp': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faWhatsapp"],
    'fas fa-whatsapp': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faWhatsapp"],
    'fa-brands fa-whatsapp': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faWhatsapp"],
    whatsapp: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faWhatsapp"],
    'fa fa-google': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faGoogle"],
    'fa fa-twitter': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faTwitter"],
    'fab fa-twitter': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$brands$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faTwitter"],
    'far fa-smile': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$regular$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faSmile"],
    'fas fa-location-dot': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLocationDot"],
    'fa-solid fa-location-dot': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLocationDot"]
};
function FaIcon({ iconClass, className = '', ...props }) {
    // 1. Isola e extrai apenas as duas primeiras palavras da string (o identificador real do ícone)
    const partes = iconClass.trim().split(/\s+/);
    const classeIconeReal = partes.slice(0, 2).join(' ');
    // 2. Coleta qualquer classe de CSS extra que sobrou na string original
    const classesCssDoBanco = partes.slice(2).join(' ');
    // 3. Busca o ícone correspondente no mapa através da classe limpa
    const icon = iconMap[classeIconeReal];
    if (!icon) {
        console.warn(`FaIcon: ícone não mapeado para '${classeIconeReal}'`);
        return null;
    }
    // 4. Junta as propriedades de classe originais com as classes extras trazidas do banco
    const classeFinal = `${classesCssDoBanco} ${className}`.trim();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
        icon: icon,
        className: classeFinal,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/devsolar/utility/fa-icon.tsx",
        lineNumber: 225,
        columnNumber: 10
    }, this);
}
_c = FaIcon;
var _c;
__turbopack_context__.k.register(_c, "FaIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/logo-dev-branco.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/logo-dev-branco.3-x81d6qf5acf.webp");}),
"[project]/src/assets/logo-dev-branco.webp.mjs { IMAGE => \"[project]/src/assets/logo-dev-branco.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$dev$2d$branco$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/logo-dev-branco.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$dev$2d$branco$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1769,
    height: 480,
    blurWidth: 8,
    blurHeight: 2,
    blurDataURL: "data:image/webp;base64,UklGRuAAAABXRUJQVlA4TNQAAAAvB0AAEM1VICICHghIDQAAAACcAkAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAMALwCAgAAQBgAQAAeCDDIAAAAADnv9cBAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5B4INgEAAADA+a8LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAVF4eCCABAAAAwPn/BuMBA2AAAAAAAAAAAAAAAAAAAAAAAAAAGAYAAzDIAAAA8v3sPX6frHKTd0uvoGm/F6CBJNDgDNwC13HaAQ=="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/footer/footer_data_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ADDRESS_INFO",
    ()=>ADDRESS_INFO,
    "COMPANY_NAME",
    ()=>COMPANY_NAME,
    "COMPANY_SLOGAN_PA",
    ()=>COMPANY_SLOGAN_PA,
    "COMPANY_SLOGAN_PB",
    ()=>COMPANY_SLOGAN_PB,
    "CONTACT_EMAIL",
    ()=>CONTACT_EMAIL,
    "CONTACT_PHONE_DISPLAY",
    ()=>CONTACT_PHONE_DISPLAY,
    "CONTACT_PHONE_RAW",
    ()=>CONTACT_PHONE_RAW,
    "CURRENT_YEAR",
    ()=>CURRENT_YEAR,
    "DEVELOPER_NAME",
    ()=>DEVELOPER_NAME,
    "DEVELOPER_URL",
    ()=>DEVELOPER_URL,
    "LOGO_URL",
    ()=>LOGO_URL,
    "WHATSAPP_FLOAT_ICON_URL",
    ()=>WHATSAPP_FLOAT_ICON_URL,
    "WHATSAPP_FLOAT_URL",
    ()=>WHATSAPP_FLOAT_URL,
    "navLinksData",
    ()=>navLinksData,
    "socialLinksData",
    ()=>socialLinksData,
    "usefulLinksData",
    ()=>usefulLinksData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$dev$2d$branco$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo$2d$dev$2d$branco$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/logo-dev-branco.webp.mjs { IMAGE => "[project]/src/assets/logo-dev-branco.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
'use client';
;
const COMPANY_NAME = "DEV Solar";
const COMPANY_SLOGAN_PA = "O FUTURO É SOLAR";
const COMPANY_SLOGAN_PB = "junte-se a essa mudança.";
const CONTACT_PHONE_RAW = "5521999677722"; // Número puro para links
const CONTACT_PHONE_DISPLAY = "+55 (21) 99967-7722"; // Formato para exibição
const CONTACT_EMAIL = "comercial@devsolar.com.br";
const ADDRESS_INFO = {
    line1: "Av. Jambeiro, 474 Loja C",
    line2: "Vila Valqueire - Rio de Janeiro/RJ",
    cep: "21330-300" // Adicionado CEP aqui
};
const CURRENT_YEAR = new Date().getFullYear();
const LOGO_URL = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$dev$2d$branco$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo$2d$dev$2d$branco$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"].src; // Logo para o rodapé
const WHATSAPP_FLOAT_ICON_URL = "/images/WhatsApp.svg" //"https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"; //'/icons/whatsapp-white.svg'; // Ícone branco para botão flutuante
;
const DEVELOPER_NAME = "Pereira Dev";
const DEVELOPER_URL = "https://www.linkedin.com/in/sergiopereira-br/"; // https://github.com/sergioPereiraBR
const navLinksData = [
    {
        id: 'home',
        href: '/#home',
        text: 'Início'
    },
    // { id: 'about', href: '/#sobre', text: 'Sobre Nós' }, // Exemplo de página interna
    {
        id: 'benefits',
        href: '/#beneficios',
        text: 'Benefícios'
    },
    {
        id: 'services',
        href: '/#modalidades',
        text: 'Serviços'
    },
    {
        id: 'cases',
        href: '/#cases',
        text: 'Cases de Sucesso'
    },
    {
        id: 'faq',
        href: '/#faq',
        text: 'Perguntas Frequentes'
    },
    {
        id: 'location',
        href: '/#location',
        text: 'Localização'
    },
    {
        id: 'partners',
        href: '/#parceiros',
        text: 'Parceiros'
    },
    {
        id: 'contact',
        href: '/#contato',
        text: 'Contato'
    }
];
const usefulLinksData = [
    {
        id: 'faq',
        href: '/#faq',
        text: 'Perguntas Frequentes'
    },
    {
        id: 'terms',
        href: '/#home',
        text: 'Termos de Uso'
    },
    {
        id: 'privacy',
        href: '/#home',
        text: 'Política de Privacidade'
    }
];
const socialLinksData = [
    {
        id: 'facebook',
        name: 'Facebook',
        url: 'https://www.facebook.com/profile.php?id=61562778810789',
        iconClass: 'fab fa-facebook-f',
        accessibility: 'Acesse nossa página no Facebook'
    },
    {
        id: 'instagram',
        name: 'Instagram',
        url: 'https://www.instagram.com/devsolar_/',
        iconClass: 'fab fa-instagram',
        accessibility: 'Acesse nosso perfil no Instagram'
    },
    {
        id: 'linkedin',
        name: 'LinkedIn',
        url: 'https://www.linkedin.com/company/dev-solar-efici%C3%AAncia-energ%C3%A9tica/about/',
        iconClass: 'fab fa-linkedin-in',
        accessibility: 'Acesse nossa página no LinkedIn'
    },
    // { id: 'youtube', name: 'YouTube', url: 'https://youtube.com', iconClass: 'fab fa-youtube', accessibility: 'Acesse nosso canal no YouTube' }, // Exemplo de URL real
    {
        id: 'whatsapp',
        name: 'WhatsApp',
        url: `https://wa.me/${CONTACT_PHONE_RAW}?text=Olá!%20Gostaria%20de%20mais%20informações`,
        iconClass: 'fab fa-whatsapp',
        accessibility: 'Entre em contato conosco via WhatsApp'
    }
];
const WHATSAPP_FLOAT_URL = `https://wa.me/${CONTACT_PHONE_RAW}?text=Olá!%20Gostaria%20de%20mais%20informações%20sobre%20os%20serviços%20da%20DEV%20Solar.`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/footer/footer_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "contactIcon": "footer_ds-module__Wx5zbW__contactIcon",
  "contactInfo": "footer_ds-module__Wx5zbW__contactInfo",
  "contactItem": "footer_ds-module__Wx5zbW__contactItem",
  "developerCredit": "footer_ds-module__Wx5zbW__developerCredit",
  "errorMessage": "footer_ds-module__Wx5zbW__errorMessage",
  "footer": "footer_ds-module__Wx5zbW__footer",
  "footerContainer": "footer_ds-module__Wx5zbW__footerContainer",
  "footerCopyright": "footer_ds-module__Wx5zbW__footerCopyright",
  "footerGrid": "footer_ds-module__Wx5zbW__footerGrid",
  "footerInfo": "footer_ds-module__Wx5zbW__footerInfo",
  "footerLinks": "footer_ds-module__Wx5zbW__footerLinks",
  "footerLogo": "footer_ds-module__Wx5zbW__footerLogo",
  "footerSocial": "footer_ds-module__Wx5zbW__footerSocial",
  "footerTitle": "footer_ds-module__Wx5zbW__footerTitle",
  "footerTitleNewsletter": "footer_ds-module__Wx5zbW__footerTitleNewsletter",
  "logoImg": "footer_ds-module__Wx5zbW__logoImg",
  "newsletterFeedback": "footer_ds-module__Wx5zbW__newsletterFeedback",
  "newsletterForm": "footer_ds-module__Wx5zbW__newsletterForm",
  "slogan": "footer_ds-module__Wx5zbW__slogan",
  "socialIconLinkFooter": "footer_ds-module__Wx5zbW__socialIconLinkFooter",
  "socialLinksContainer": "footer_ds-module__Wx5zbW__socialLinksContainer",
  "spinner-border": "footer_ds-module__Wx5zbW__spinner-border",
  "successMessage": "footer_ds-module__Wx5zbW__successMessage",
  "whatsappBtn": "footer_ds-module__Wx5zbW__whatsappBtn",
});
}),
"[project]/src/components/devsolar/estructure/body/footer/footer_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"); // Importar useState para Newsletter
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/footer/footer_data_ds.js [app-client] (ecmascript)"); // Ajuste o caminho se necessário
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/footer/footer_ds.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
// Chave de acesso DO NOVO formulário Newsletter no StaticForms
const NEWSLETTER_STATICFORMS_KEY = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_NEWSLETTER_STATICFORMS_KEY || "sf_0cg1jn4jjmlngif74g76lk9j";
function FooterDS() {
    _s();
    // Estado para o input e feedback da newsletter
    const [newsletterEmail, setNewsletterEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newsletterStatus, setNewsletterStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // null | 'submitting' | 'success' | 'error'
    const [newsletterMessage, setNewsletterMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Handler para o envio da newsletter
    const handleNewsletterSubmit = async (e)=>{
        e.preventDefault();
        if (!newsletterEmail) return;
        setNewsletterStatus('submitting');
        setNewsletterMessage('');
        const payload = {
            accessKey: NEWSLETTER_STATICFORMS_KEY,
            email: newsletterEmail,
            subject: `Nova Inscrição Newsletter DEV Solar: ${newsletterEmail}`,
            // --- Campos Opcionais StaticForms ---
            replyTo: newsletterEmail
        };
        try {
            const response = await fetch('https://api.staticforms.xyz/submit', {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            });
            const result = await response.json();
            if (response.ok && result.success !== false) {
                setNewsletterStatus('success');
                setNewsletterMessage('Obrigado por se inscrever!');
                setNewsletterEmail(''); // Limpa o campo
                setTimeout(()=>setNewsletterStatus(null), 4000); // Limpa msg após 4s
            } else {
                throw new Error(result.error || result.message || 'Erro desconhecido do serviço.');
            }
        } catch (error) {
            //console.error("Newsletter Submit Error:", error);
            setNewsletterStatus('error');
            setNewsletterMessage('Erro ao inscrever. Tente novamente.');
            setTimeout(()=>setNewsletterStatus(null), 5000); // Limpa msg após 5s
        }
    };
    return(// Removido Fragmento
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footer,
        id: "footer",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `container ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerContainer}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerGrid,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerColumn} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerInfo}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerLogo,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/#home",
                                            "aria-label": `Ir para a página inicial de ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMPANY_NAME"]}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoImg,
                                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOGO_URL"],
                                                alt: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMPANY_NAME"]} Logo`,
                                                width: 177,
                                                height: 48
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 90,
                                                columnNumber: 33
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                            lineNumber: 89,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 88,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].slogan,
                                        children: [
                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMPANY_SLOGAN_PA"],
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 99,
                                                columnNumber: 74
                                            }, this),
                                            " ",
                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMPANY_SLOGAN_PB"]
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 99,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactInfo,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactItem} d-flex align-items-center mb-2`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                        iconClass: "fas fa-phone-alt",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactIcon,
                                                        "aria-label": "Telefone DEV Solar"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                        lineNumber: 103,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: `tel:${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONTACT_PHONE_RAW"]}`,
                                                        "aria-label": "Ligar para DEV Solar",
                                                        children: [
                                                            " ",
                                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONTACT_PHONE_DISPLAY"]
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                        lineNumber: 104,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 102,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactItem} d-flex align-items-center mb-2`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                        iconClass: "fas fa-envelope",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactIcon,
                                                        "aria-label": "Email DEV Solar"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                        lineNumber: 108,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: `mailto:${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONTACT_EMAIL"]}`,
                                                        "aria-label": "Enviar email para DEV Solar",
                                                        children: [
                                                            " ",
                                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONTACT_EMAIL"]
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                        lineNumber: 109,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 107,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactItem} d-flex align-items-start mb-2`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                        iconClass: "fas fa-location-dot",
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactIcon} mt-1`,
                                                        "aria-label": "Localização DEV Solar"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                        lineNumber: 113,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADDRESS_INFO"].line1,
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                                lineNumber: 115,
                                                                columnNumber: 57
                                                            }, this),
                                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADDRESS_INFO"].line2,
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                                lineNumber: 116,
                                                                columnNumber: 57
                                                            }, this),
                                                            "CEP: ",
                                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADDRESS_INFO"].cep
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                        lineNumber: 114,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 112,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 100,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                lineNumber: 87,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerColumn} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerLinks}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerTitle,
                                        children: "Navegação"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 125,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navLinksData"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: link.href,
                                                    children: link.text
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                    lineNumber: 128,
                                                    columnNumber: 51
                                                }, this)
                                            }, link.id, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 128,
                                                columnNumber: 33
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 126,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                lineNumber: 124,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerColumn} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerLinks}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerTitle,
                                        children: "Links Úteis"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 135,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usefulLinksData"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: link.href,
                                                    children: link.text
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                    lineNumber: 138,
                                                    columnNumber: 51
                                                }, this)
                                            }, link.id, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 138,
                                                columnNumber: 33
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 136,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                lineNumber: 134,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerColumn} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerSocial}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerTitle,
                                        children: "Siga-nos"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 145,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialLinksContainer} d-flex mb-4`,
                                        children: [
                                            " ",
                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socialLinksData"].map((social)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: social.url,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialIconLinkFooter,
                                                    "aria-label": `Visitar ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMPANY_NAME"]} no ${social.name}`,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                            iconClass: social.iconClass,
                                                            "aria-label": social.accessibility
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                            lineNumber: 156,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "sr-only",
                                                            children: social.accessibility
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                            lineNumber: 157,
                                                            columnNumber: 37
                                                        }, this)
                                                    ]
                                                }, social.id, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                    lineNumber: 148,
                                                    columnNumber: 33
                                                }, this))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 146,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerTitleNewsletter,
                                        children: "Newsletter"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 163,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].newsletterForm,
                                        onSubmit: handleNewsletterSubmit,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "email",
                                                id: "newsletter-email",
                                                name: "newsletter_email",
                                                "aria-label": "Email para newsletter",
                                                placeholder: "Seu melhor e-mail",
                                                value: newsletterEmail,
                                                onChange: (e)=>setNewsletterEmail(e.target.value),
                                                required: true,
                                                disabled: newsletterStatus === 'submitting'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 165,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "submit",
                                                "aria-label": "Inscrever na newsletter",
                                                disabled: newsletterStatus === 'submitting',
                                                children: newsletterStatus === 'submitting' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "spinner-border spinner-border-sm",
                                                    role: "status",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                    lineNumber: 178,
                                                    columnNumber: 37
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                    iconClass: "fas fa-paper-plane",
                                                    "aria-label": "Enviar"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                    lineNumber: 180,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 176,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 164,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].newsletterFeedback,
                                        children: [
                                            newsletterStatus === 'success' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].successMessage,
                                                children: newsletterMessage
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 186,
                                                columnNumber: 64
                                            }, this),
                                            newsletterStatus === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].errorMessage,
                                                children: newsletterMessage
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                                lineNumber: 187,
                                                columnNumber: 62
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 185,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                lineNumber: 144,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                        lineNumber: 84,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footerCopyright,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "© ",
                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CURRENT_YEAR"],
                                    " ",
                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMPANY_NAME"],
                                    " - Todos os direitos reservados.",
                                    "| ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/#",
                                        children: "Política de Privacidade"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 198,
                                        columnNumber: 27
                                    }, this),
                                    " |",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/#",
                                        children: "Termos de Uso"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 199,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                lineNumber: 195,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].developerCredit,
                                children: [
                                    "Powered by ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEVELOPER_URL"],
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEVELOPER_NAME"]
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                        lineNumber: 204,
                                        columnNumber: 36
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                                lineNumber: 203,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                        lineNumber: 194,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                lineNumber: 83,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_FLOAT_URL"],
                target: "_blank",
                rel: "noopener noreferrer",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].whatsappBtn,
                "aria-label": "Entrar em contato pelo WhatsApp",
                children: [
                    "   ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sr-only",
                        children: "Entre em contato conosco via WhatsApp"
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                        lineNumber: 216,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$footer$2f$footer_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_FLOAT_ICON_URL"],
                        alt: "WhatsApp",
                        width: 32,
                        height: 32
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                        lineNumber: 217,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
                lineNumber: 210,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/footer/footer_ds.js",
        lineNumber: 82,
        columnNumber: 9
    }, this));
}
_s(FooterDS, "EWLFkXyOc+mJI1p29JZanoqtMcU=");
_c = FooterDS;
const __TURBOPACK__default__export__ = FooterDS;
var _c;
__turbopack_context__.k.register(_c, "FooterDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/logo_sm.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/logo_sm.2s5-q1rocp88f.webp");}),
"[project]/src/assets/logo_sm.webp.mjs { IMAGE => \"[project]/src/assets/logo_sm.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/logo_sm.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 140,
    height: 38,
    blurWidth: 8,
    blurHeight: 2,
    blurDataURL: "data:image/webp;base64,UklGRuIAAABXRUJQVlA4TNUAAAAvB0AAEM1VICICHgggAQAAAIBNDwDAAAAAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAADPQNAADggQASAAAAAJx/jzcYMAAAAAAAAAAMAAAAAAAAAAAAAAAAABgAAAAAAACe7IEAEgAAAACc/4MHAAAAAAAAAAAAAACAAQYAAAAAAAAAAAAAABgAAGPgmdsDARAAAAAAOP8TMUAACAAAAAAAAAAAAAAAAAAAAAAAABAQAARADAEAgOyxdOJfVsZQWI1qP1U0wGRPzBOnPmzmyAcvapOngTYA"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/photovoltaic.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/photovoltaic.3vr45t1gkolic.webp");}),
"[project]/src/assets/photovoltaic.webp.mjs { IMAGE => \"[project]/src/assets/photovoltaic.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$photovoltaic$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/photovoltaic.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$photovoltaic$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 832,
    height: 468,
    blurWidth: 8,
    blurHeight: 5,
    blurDataURL: "data:image/webp;base64,UklGRuYAAABXRUJQVlA4TNkAAAAvBwABAM1VICICHgiACQMAAACVRJgoAgAAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAIAHAGyzZjMBAAB4IAAnEAAAAOe/u+1XRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfZWdBwKQwgAAAHD+f71XMh5sSggBAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAwixqRT5tdbPn9Z5C26wwBmKkr0F/pSVS8TpfkHHfeDdFB1lvC5C+L0elgQLMHWy5ivfVp/GKQ6EY7qWEv2TGmx8SY4dWiYCAA=="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/utils/financialCalculations.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateDCFValue",
    ()=>calculateDCFValue,
    "calculateDiscountedPayback",
    ()=>calculateDiscountedPayback,
    "calculateEVA",
    ()=>calculateEVA,
    "calculateIRR",
    ()=>calculateIRR,
    "calculateIncrementalIRR",
    ()=>calculateIncrementalIRR,
    "calculateMIRR",
    ()=>calculateMIRR,
    "calculateNPV",
    ()=>calculateNPV,
    "calculatePI",
    ()=>calculatePI,
    "calculateROIC",
    ()=>calculateROIC,
    "calculateSimplePayback",
    ()=>calculateSimplePayback,
    "calculateWACC",
    ()=>calculateWACC,
    "tir",
    ()=>tir,
    "vpl",
    ()=>vpl
]);
//import { irr as calculateLibraryIRR } from 'irr'; // Importa a função da biblioteca
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$irr$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/irr/dist/index.js [app-client] (ecmascript)");
;
function calculateNPV(rate, cashFlows) {
    if (!cashFlows || cashFlows.length === 0) {
        return 0;
    }
    let npv = 0;
    for(let t = 0; t < cashFlows.length; t++){
        npv += (cashFlows[t] || 0) / Math.pow(1 + rate, t);
    }
    return npv;
}
function calculateSimplePayback(cashFlows) {
    if (!cashFlows || cashFlows.length < 1 || cashFlows[0] >= 0) {
        return Infinity; // Sem investimento inicial ou sem fluxos futuros
    }
    const initialInvestment = Math.abs(cashFlows[0]);
    let cumulativeCashFlow = 0;
    for(let t = 1; t < cashFlows.length; t++){
        const previousCumulative = cumulativeCashFlow;
        cumulativeCashFlow += cashFlows[t] || 0;
        if (cumulativeCashFlow >= initialInvestment) {
            // Payback ocorre neste período (t)
            // Interpolação para valor fracionado:
            const investmentRemaining = initialInvestment - previousCumulative;
            const cashFlowThisPeriod = cashFlows[t] || 0;
            if (cashFlowThisPeriod <= 0) return Infinity; // Evita divisão por zero se fluxo for não positivo
            return t - 1 + investmentRemaining / cashFlowThisPeriod;
        }
    }
    return Infinity; // Payback não ocorre dentro do período
}
function calculateDiscountedPayback(rate, cashFlows) {
    if (!cashFlows || cashFlows.length < 1 || cashFlows[0] >= 0) {
        return Infinity;
    }
    const initialInvestment = Math.abs(cashFlows[0]);
    let cumulativeDiscountedCashFlow = 0;
    for(let t = 1; t < cashFlows.length; t++){
        const previousCumulative = cumulativeDiscountedCashFlow;
        const discountedCashFlow = (cashFlows[t] || 0) / Math.pow(1 + rate, t);
        cumulativeDiscountedCashFlow += discountedCashFlow;
        if (cumulativeDiscountedCashFlow >= initialInvestment) {
            const investmentRemaining = initialInvestment - previousCumulative;
            if (discountedCashFlow <= 0) return Infinity;
            // Interpola usando fluxos descontados
            return t - 1 + investmentRemaining / discountedCashFlow;
        }
    }
    return Infinity;
}
function calculateWACC(marketValueEquity, marketValueDebt, costOfEquity, costOfDebt, taxRate) {
    const totalCapital = marketValueEquity + marketValueDebt;
    if (totalCapital <= 0) return NaN; // Evita divisão por zero
    const weightEquity = marketValueEquity / totalCapital;
    const weightDebt = marketValueDebt / totalCapital;
    const wacc = weightEquity * costOfEquity + weightDebt * costOfDebt * (1 - taxRate);
    return wacc;
}
function calculateROIC(nopat, investedCapital) {
    if (investedCapital === 0) return NaN;
    return nopat / investedCapital;
}
function calculateIncrementalIRR(cashFlowsA, cashFlowsB, guess = 0.1) {
    const maxLength = Math.max(cashFlowsA.length, cashFlowsB.length);
    const incrementalFlows = [];
    for(let t = 0; t < maxLength; t++){
        const cfA = cashFlowsA[t] || 0;
        const cfB = cashFlowsB[t] || 0;
        incrementalFlows.push(cfB - cfA);
    }
    // Reutiliza a função calculateIRR nos fluxos incrementais
    return calculateIRR(incrementalFlows, guess);
}
function calculateMIRR(cashFlows, financeRate, reinvestRate) {
    if (!cashFlows || cashFlows.length < 2) return NaN;
    const n = cashFlows.length - 1; // Número de períodos após o inicial
    let pvNegativeFlows = 0;
    let fvPositiveFlows = 0;
    cashFlows.forEach((cf, t)=>{
        if (cf < 0) {
            pvNegativeFlows += Math.abs(cf) / Math.pow(1 + financeRate, t); // Traz negativos a valor presente
        } else if (cf > 0) {
            fvPositiveFlows += cf * Math.pow(1 + reinvestRate, n - t); // Leva positivos a valor futuro
        }
    });
    if (pvNegativeFlows <= 0 || fvPositiveFlows <= 0) {
        // Não é possível calcular se não houver saídas ou entradas (ou se o inicial for positivo)
        return NaN;
    }
    const mirr = Math.pow(fvPositiveFlows / pvNegativeFlows, 1 / n) - 1;
    return mirr;
}
function calculatePI(rate, cashFlows) {
    if (!cashFlows || cashFlows.length < 1 || cashFlows[0] >= 0) {
        return NaN;
    }
    const initialInvestment = Math.abs(cashFlows[0]);
    let pvFutureCashFlows = 0;
    for(let t = 1; t < cashFlows.length; t++){
        pvFutureCashFlows += (cashFlows[t] || 0) / Math.pow(1 + rate, t);
    }
    return pvFutureCashFlows / initialInvestment;
}
function calculateEVA(nopat, investedCapital, wacc) {
    const capitalCharge = investedCapital * wacc;
    return nopat - capitalCharge;
}
function calculateDCFValue(rate, cashFlows) {
    if (!cashFlows || cashFlows.length < 2) {
        return 0;
    }
    let dcfValue = 0;
    for(let t = 1; t < cashFlows.length; t++){
        dcfValue += (cashFlows[t] || 0) / Math.pow(1 + rate, t);
    }
    return dcfValue;
}
function calculateIRR(cashFlows, guess) {
    try {
        // A biblioteca 'irr' pode esperar apenas os fluxos.
        // Verifique a documentação dela para opções como 'guess'.
        // Passa o 'guess' se ele foi fornecido.
        const result = guess !== undefined ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$irr$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(cashFlows, guess) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$irr$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(cashFlows);
        // A biblioteca pode retornar null, NaN ou lançar erro em caso de falha.
        // Adicionamos isFinite para cobrir casos de Infinity/-Infinity também.
        if (result === null || isNaN(result) || !isFinite(result)) {
            console.warn("Cálculo da TIR pela biblioteca falhou ou não convergiu.");
            return NaN; // Retorna NaN em caso de falha ou resultado inválido
        }
        return result; // Retorna o resultado numérico válido
    } catch (error) {
        console.error("Erro ao calcular TIR com a biblioteca:", error);
        return NaN; // Retorna NaN se ocorrer um erro durante a execução
    }
}
function vpl(taxa, montantes) {
    var ret = montantes[0];
    for(var i = 1; i < montantes.length; i++)ret += montantes[i] / Math.pow(1.0 + taxa, i);
    return ret;
}
function tir(montantes) {
    var ret = -1000000000.0;
    var juros_inicial = -1.0;
    var juros_medio = 0.0;
    var juros_final = 1.0;
    var vpl_inicial = 0.0;
    var vpl_final = 0.0;
    var vf = 0.0;
    var erro = 1e-5;
    for(var i = 0; i < 100; i++){
        vpl_inicial = vpl(juros_inicial, montantes);
        vpl_final = vpl(juros_final, montantes);
        if (sinal(vpl_inicial) != sinal(vpl_final)) break;
        juros_inicial -= 1.0;
        juros_final += 1.0;
    }
    ;
    var count = 0;
    for(;;){
        // Busca por Bisseção
        var juros_medio = (juros_inicial + juros_final) / 2.0;
        var vpl_medio = vpl(juros_medio, montantes);
        if (Math.abs(vpl_medio) <= erro) {
            // Resultado foi encontrado
            return juros_medio * 100.0;
        }
        ;
        if (sinal(vpl_inicial) == sinal(vpl_medio)) {
            juros_inicial = juros_medio;
            vpl_inicial = vpl(juros_medio, montantes);
        } else {
            juros_final = juros_medio;
            vpl_final = vpl(juros_medio, montantes);
        }
        ;
        if (++count > 10000) throw "looping inválido";
    }
    ;
    return ret;
}
;
function sinal(x) {
    return x < 0.0 ? -1 : 1;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/utils/solarCalculations.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calcularEconomiaSolar",
    ()=>calcularEconomiaSolar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$financialCalculations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/financialCalculations.js [app-client] (ecmascript)");
;
function calcularEconomiaSolar(custoMensalRs) {
    // Constantes de Cálculo (Exemplo - Devem ser mais precisas ou configuráveis)
    const TAXA_ENERGIA_RS_KWH = 1.18;
    const PERDA_SISTEMA_PERCENT = 25; // %
    const POTENCIA_PAINEL_W = 570;
    const INVESTIMENTO_ESTIMADO_BASE = 18000.0; // Exemplo, cálculo real seria mais complexo
    const TAXA_JUROS_ANUAL_ENERGIA = 0.06; // Para projeção de custo evitado
    const DEGRADACAO_PAINEL_ANO1 = 0.03;
    const DEGRADACAO_PAINEL_ANOS_SEGUINTES = 0.01;
    const VIDA_UTIL_SISTEMA_ANOS = 25;
    // --- Fim das Constantes ---
    // Placeholder - NECESSITA IMPLEMENTAÇÃO REAL (API, JSON, etc.)
    const obterDadosIrradiacao = (uf = 'RJ', latitude = -22.9, longitude = -43.2)=>{
        // console.warn('Placeholder: Implementar busca real de dados de irradiação.');
        // Simulando uma média anual para RJ (exemplo, valor irreal)
        const mediaAnualKWhM2Dia = 5.5; //[0, 0, 0, 0, 5.5, 5.3, 5.1, 5.4, 5.7, 6.0, 6.2, 6.1, 5.9, 5.8, 5.6, 5.4, 5.4]
        // Retorna um array simulando a média para cada mês (simplificado)
        return Array(12).fill(mediaAnualKWhM2Dia); // [5.0, 5.0, ..., 5.0]
    };
    // Placeholder - PRECISA DE DADOS REAIS OU INPUTS (CEP, etc.)
    const getLocalizacaoGeradora = ()=>({
            uf: 'RJ',
            lat: -22.9,
            long: -43.2
        });
    const roundPotenciaPico80p = (potenciaPico)=>{
        // Lógica mantida, mas pode ser simplificada ou usar Math.round diretamente dependendo da regra exata
        const potenciaPico80pMin = potenciaPico * 0.8;
        return Math.max(1, Math.round(potenciaPico80pMin)); // Simplificado para arredondar normal e garantir min 1
    };
    if (!custoMensalRs || custoMensalRs < 300 || custoMensalRs > 999999999.99) {
        return {
            error: 'Custo mensal inválido',
            dataResume: [],
            text_payback: 'N/A'
        };
    }
    // 1. Dados de Consumo
    const consumoTotalKwhMes = custoMensalRs / TAXA_ENERGIA_RS_KWH;
    const consumoTotalKwhAno = consumoTotalKwhMes * 12;
    const consumoMediaKwhDia = consumoTotalKwhAno / 12 / 30;
    // 2. Dados da Unidade Geradora (Simplificado)
    const localizacao = getLocalizacaoGeradora();
    const eficienciaSistema = 1 - PERDA_SISTEMA_PERCENT / 100;
    const irradiacaoMediaDiariaMesKwhM2 = obterDadosIrradiacao(localizacao.uf, localizacao.lat, localizacao.long);
    // console.log('irradiacaoMediaDiariaMesKwhM2: ', irradiacaoMediaDiariaMesKwhM2);
    // Média anual simples para este exemplo
    const irradiacaoMediaAnualKwhM2Dia = irradiacaoMediaDiariaMesKwhM2.reduce((a, b)=>a + b, 0) / 12;
    // console.log('irradiacaoMediaAnualKwhM2Dia: ', irradiacaoMediaAnualKwhM2Dia);
    // 3. Potencial do Sistema
    const consumoCompensadoKwhDia = consumoMediaKwhDia / eficienciaSistema;
    // console.log('consumoCompensadoKwhDia: ', consumoCompensadoKwhDia);
    const potenciaSistemaKwpNecessaria = consumoCompensadoKwhDia / irradiacaoMediaAnualKwhM2Dia;
    // console.log('potenciaSistemaKwpNecessaria: ', potenciaSistemaKwpNecessaria);
    const quantidadePaineis = Math.ceil(potenciaSistemaKwpNecessaria / (POTENCIA_PAINEL_W / 1000));
    // console.log('quantidadePaineis: ', quantidadePaineis);
    // Recalcula a potência real do sistema com base nos painéis inteiros
    const potenciaRealSistemaKwp = quantidadePaineis * (POTENCIA_PAINEL_W / 1000);
    // console.log('potenciaRealSistemaKwp: ', potenciaRealSistemaKwp);
    // 4. Produção Anual Estimada (Simplificado)
    // let potenciaSistemaKwpAno = 0;
    // irradiacaoMediaDiariaMesKwhM2.forEach(irradiacaoMes => {
    //     // Produção mensal = Potência_Sistema * Irradiação_Média_Dia * Dias_no_Mês * Eficiência
    //     // Simplificação: usando média anual de irradiação * 30 dias * 12 meses
    //     potenciaSistemaKwpAno += potenciaRealSistemaKwp * irradiacaoMediaAnualKwhM2Dia * 30 * eficienciaSistema;
    // });
    const potenciaSistemaKwpAno = potenciaRealSistemaKwp * irradiacaoMediaAnualKwhM2Dia * 365.25 * eficienciaSistema;
    // Correção: cálculo direto anual
    // potenciaSistemaKwpAno = potenciaRealSistemaKwp * irradiacaoMediaAnualKwhM2Dia * 365 * eficienciaSistema;
    // console.log('potenciaSistemaKwpAno: ', potenciaSistemaKwpAno);
    // 5. Cálculo do Payback
    let investimento = INVESTIMENTO_ESTIMADO_BASE * potenciaRealSistemaKwp; // Investimento proporcional
    if (custoMensalRs >= 300 && custoMensalRs <= 500) {
        investimento = (custoMensalRs - 300) / (500 - 300) * (16200.0 - 12911.02) + 12911.02;
    }
    if (custoMensalRs > 500 && custoMensalRs <= 800) {
        investimento = (custoMensalRs - 500) / (800 - 500.01) * (17900.0 - 16200.0) + 16200.0;
    }
    if (custoMensalRs > 800 && custoMensalRs <= 1000) {
        investimento = (custoMensalRs - 800) / (1000 - 800.01) * (24000.24 - 17900.0) + 17900.0;
    }
    if (custoMensalRs > 1000) {
        investimento = custoMensalRs * 24.0;
    }
    const acumulado = [];
    let economiaAcumulada = 0.0;
    let custoEvitadoAcumulado = 0.0;
    let paybackAnos = 0;
    let potenciaAtualSistema = potenciaSistemaKwpAno; // Produção no ano 1
    const fc = [
        -1 * investimento
    ];
    for(let ano = 1; ano <= VIDA_UTIL_SISTEMA_ANOS; ano++){
        // Taxa de energia atualizada com inflação energética
        const taxaEnergiaAtualizada = TAXA_ENERGIA_RS_KWH * Math.pow(1 + TAXA_JUROS_ANUAL_ENERGIA, ano - 1);
        // Economia gerada no ano (Produção * Tarifa Atualizada)
        const economiaAno = potenciaAtualSistema * taxaEnergiaAtualizada;
        economiaAcumulada += economiaAno;
        fc.push(economiaAno);
        // Custo que teria sem o sistema
        const custoSemSolarAno = consumoTotalKwhAno * taxaEnergiaAtualizada;
        custoEvitadoAcumulado += custoSemSolarAno;
        // Verifica payback
        if (paybackAnos === 0 && economiaAcumulada >= investimento) {
            // Cálculo mais preciso do mês/ano do payback (simplificado aqui para apenas o ano)
            paybackAnos = ano;
        }
        acumulado.push({
            Ano: new Date().getFullYear() + ano,
            // Recharts funciona melhor com series numericas; arredonda sem converter para string
            Economia: Number(economiaAcumulada.toFixed(2)),
            Custo: Number(custoEvitadoAcumulado.toFixed(2)),
            Payback: Number((economiaAcumulada - investimento).toFixed(2))
        });
        // Aplica degradação para o próximo ano
        const taxaDegradacao = ano === 1 ? DEGRADACAO_PAINEL_ANO1 : DEGRADACAO_PAINEL_ANOS_SEGUINTES;
        potenciaAtualSistema *= 1 - taxaDegradacao;
    }
    // Seleciona pontos para o resumo (dataResume)
    const indices = [
        0,
        1,
        2,
        3,
        4,
        9,
        14,
        19,
        VIDA_UTIL_SISTEMA_ANOS - 1
    ].filter((i)=>i < acumulado.length);
    const dataResume = indices.map((index)=>acumulado[index]);
    // Texto do Payback
    let textPayback = `Mais de ${VIDA_UTIL_SISTEMA_ANOS} anos`;
    if (paybackAnos > 0) {
        textPayback = paybackAnos <= 1 ? `Menos de 1 ano` : `~ ${paybackAnos} anos`;
    }
    // console.log("textPayback: ", textPayback);
    // console.log("acumulado: ", acumulado);
    // console.log("dataResume: ", dataResume);
    // console.log("potenciaRealSistemaKwp: ", potenciaRealSistemaKwp.toFixed(2));
    // console.log("economiaPrimeiroAno: ", (acumulado[0]?.Economia - (acumulado[-1]?.Economia || 0)).toFixed(2));
    // console.log("investimentoEstimado: ", investimento.toFixed(2));
    // console.log("custoMensalInformado: ", custoMensalRs);
    //economiaPrimeiroAno: (acumulado[0]?.Economia - (acumulado[-1]?.Economia || 0)).toFixed(2), // Simplificado
    const reduction = (1 + (economiaAcumulada - custoEvitadoAcumulado) / economiaAcumulada) * 100;
    const roi_calc = (economiaAcumulada - investimento) / investimento * 100;
    const vpl_calc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$financialCalculations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateNPV"])(TAXA_JUROS_ANUAL_ENERGIA, fc);
    const tir_calc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$financialCalculations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tir"])(fc);
    // console.log("fc: ", fc);
    // console.log("reduction: ", reduction);
    // console.log("roi_calc: ", roi_calc);
    // console.log("vpl_calc: ", vpl_calc);
    // console.log("tir_calc: ", tir_calc);
    return {
        text_payback: textPayback,
        data: acumulado,
        dataResume: dataResume,
        potenciaEstimadaKwp: potenciaRealSistemaKwp,
        investimentoEstimado: investimento,
        custoMensalInformado: custoMensalRs,
        economiaAcumulada: economiaAcumulada,
        tir: tir_calc,
        vpl: vpl_calc,
        roi: roi_calc,
        taxCostReduct: reduction,
        projecao: VIDA_UTIL_SISTEMA_ANOS
    };
} // --- Fim das Funções de Cálculo ---
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/module.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/module.23qpdnwszjytf.webp");}),
"[project]/src/assets/module.webp.mjs { IMAGE => \"[project]/src/assets/module.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$module$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/module.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$module$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 232,
    height: 435,
    blurWidth: 4,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRrYAAABXRUJQVlA4TKoAAAAvA8ABAM1VICICHghIDQAAAIArAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKq/AQAAPBBIAAAAAIDzrwEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDHshGDgAAAMD5nwEAAAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAp5HvH9cVqx4tohT5xSANBgjAUyFZ3MztIomSdmZ2AA=="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/utils/device_detector_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDeviceType",
    ()=>getDeviceType
]);
/**
 * Estima o tipo de dispositivo do cliente com base no User Agent e características da tela.
 * IMPORTANTE: A detecção baseada em User Agent não é 100% precisa e pode ser enganada.
 * Use com cautela, principalmente para TV e Console.
 *
 * @returns {'Mobile' | 'Tablet' | 'Desktop' | 'TV' | 'Console' | 'Unknown'} O tipo de dispositivo estimado.
 */ function getDeviceType() {
    // Verifica se o código está rodando no navegador
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !navigator) {
        return 'Unknown'; // Ou talvez 'Server' se for em contexto de SSR sem window
    }
    const ua = navigator.userAgent.toLowerCase();
    // 1. Detecção Mobile (mais confiável)
    // Inclui a maioria dos telefones e alguns tablets Android mais antigos
    if (/android|iphone|ipod|windows phone|blackberry|iemobile|opera mini/i.test(ua)) {
        // Verifica se é um tablet Android (não contém 'mobile') ou iPad
        // O iPad moderno pode não ter 'iPad' no UA, mas terá Mac OS e touch
        const isTablet = /ipad|android(?!.*mobile)/i.test(ua) || navigator.maxTouchPoints > 1 && /macintosh/i.test(ua); // Heurística para iPad recente
        if (isTablet) {
            return 'Tablet';
        }
        return 'Mobile';
    }
    // 2. Detecção de Tablet (iPad já coberto acima, outros casos)
    // Tablets podem ter user agents complexos, usar touch como indicador
    if (/tablet|kindle|silk/i.test(ua) || navigator.maxTouchPoints > 1 && window.innerWidth >= 768) {
        // Considera tablet se tiver touch e largura mínima razoável
        return 'Tablet';
    }
    // 3. Detecção de TV (menos confiável - depende de strings específicas)
    if (/tv|smarttv|googletv|crkey|appletv|tizen|webos|viera|netcast|dtv|nettv|playstation|xbox|nintendo/i.test(ua)) {
        // Verifica se é um console especificamente
        if (/playstation|xbox|nintendo/i.test(ua)) {
            return 'Console';
        }
        return 'TV';
    }
    // 4. Detecção de Console (se não detectado junto com TV)
    if (/playstation|xbox|nintendo/i.test(ua)) {
        return 'Console';
    }
    // 5. Se não for Mobile, Tablet, TV ou Console, assume Desktop
    // Poderia adicionar uma checagem extra para telas muito grandes como possível TV
    // if (window.innerWidth > 1600 || window.innerHeight > 900) {
    //     // Heurística para telas muito grandes, podem ser TVs conectadas a PCs
    // }
    return 'Desktop';
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "btn-success": "whatsapp_sender_ds-module__UVYWpG__btn-success",
  "modalChoiceBody": "whatsapp_sender_ds-module__UVYWpG__modalChoiceBody",
  "modalChoiceButton": "whatsapp_sender_ds-module__UVYWpG__modalChoiceButton",
  "modalChoiceHeader": "whatsapp_sender_ds-module__UVYWpG__modalChoiceHeader",
  "modalChoiceTitle": "whatsapp_sender_ds-module__UVYWpG__modalChoiceTitle",
  "rememberCheckbox": "whatsapp_sender_ds-module__UVYWpG__rememberCheckbox",
});
}),
"[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$device_detector_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/device_detector_ds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Form.js [app-client] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.module.css [app-client] (css module)"); // CSS Module para este componente
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
// Chave para localStorage
const WHATSAPP_PREFERENCE_KEY = 'whatsapp_open_preference'; // ex: 'app' ou 'web'
// Função auxiliar para sanitizar e preparar mensagens
const prepareMessages = (baseMessage, userMessage)=>{
    const trimmedMessage = userMessage?.trim() ?? ''; // Garante que userMessage não seja null/undefined
    if (trimmedMessage === '') return null; // Não processa se não houver pergunta
    const message = trimmedMessage;
    //const sanitizedMessage = trimmedMessage
    //    .replace(/\u00A0/g, ' ') // Remove NBSP
    //    .replace(/\s{2,}/g, ' '); // Remove espaços múltiplos
    // Remove VS16 para App, substitui emoji problemático para Web
    //const message = sanitizedMessage.replace(/\uFE0F/g, '');
    //const questionForWeb = sanitizedQuestion.replace(/\uFE0F/g, '');
    // const questionForWeb = questionForApp.replace(/❤/g, '[emoji]'); // Ou remove ''
    let fullMessage = '';
    if (baseMessage === '') {
        fullMessage = message;
    } else {
        fullMessage = `${baseMessage}\n${message}`;
    }
    //const fullMessageWeb = `${baseMessage}\n\n"${questionForWeb}"`;
    const encodedMessageApp = encodeURIComponent(fullMessage);
    const encodedMessageWeb = encodeURIComponent(fullMessage);
    return {
        encodedMessageApp,
        encodedMessageWeb
    };
};
/**
 * Componente/Hook para lidar com o envio de mensagens para o WhatsApp,
 * incluindo detecção mobile/desktop e modal de escolha.
 *
 * Props:
 * - show: boolean - Controla se o processo de envio deve ser iniciado.
 * - onHide: function - Chamada quando o processo termina (enviado ou cancelado).
 * - phoneNumber: string - O número de telefone do WhatsApp (ex: 55219...).
 * - baseMessage: string - A parte fixa da mensagem (ex: "Olá! Tenho uma dúvida...").
 * - userMessage: string - A pergunta específica do usuário (pode conter emojis).
 */ function WhatsAppSender({ show, onHide, phoneNumber, baseMessage, userMessage }) {
    _s();
    const [deviceType, setDeviceType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('Unknown');
    const [isProcessing, setIsProcessing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // Evita múltiplos cliques/processamentos
    const [showChoiceModal, setShowChoiceModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [preparedUrls, setPreparedUrls] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // --- NOVO ESTADO para "Lembrar Escolha" ---
    const [rememberChoice, setRememberChoice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // Checkbox state
    // Roda uma vez para detectar o tipo de dispositivo
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WhatsAppSender.useEffect": ()=>{
            setDeviceType(__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$device_detector_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDeviceType"]);
        }
    }["WhatsAppSender.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WhatsAppSender.useEffect": ()=>{
            setDeviceType(__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$device_detector_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDeviceType"]);
            // Só processa quando 'show' é true e não está processando
            if (show && !isProcessing && userMessage && deviceType !== 'Unknown') {
                setIsProcessing(true); // Marca como processando
                //console.log("Device Type: ", deviceType);
                const messages = prepareMessages(baseMessage, userMessage);
                if (!messages) {
                    //console.warn("Pergunta do usuário está vazia após sanitização.");
                    onHide(); // Fecha se a pergunta for inválida
                    setIsProcessing(false);
                    return;
                }
                const { encodedMessageApp, encodedMessageWeb } = messages;
                const urls = {
                    app: `whatsapp://send?phone=${phoneNumber}&text=${encodedMessageApp}`,
                    web: `https://web.whatsapp.com/send?phone=${phoneNumber}&text=${encodedMessageWeb}`,
                    pho: `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodedMessageWeb}`
                };
                setPreparedUrls(urls); // Guarda as URLs prontas
                if (deviceType === 'Mobile' || deviceType === 'Tablet') {
                    console.log(`${deviceType}: Tentando abrir app:`, urls.app);
                    window.open(`${urls.pho}`, '_blank', 'noopener,noreferrer');
                    // window.location.href = urls.app;
                    // Pequeno delay antes de chamar onHide no mobile para dar tempo ao redirect
                    setTimeout(onHide, 300);
                } else if (deviceType === 'Desktop') {
                    // --- LÓGICA DESKTOP COM PREFERÊNCIA ---
                    const savedPreference = localStorage.getItem(WHATSAPP_PREFERENCE_KEY);
                    //console.log("Preferência salva:", savedPreference);
                    if (savedPreference === 'app') {
                        //console.log("Desktop: Usando preferência salva 'app'.");
                        window.location.href = urls.app; // Tenta abrir app
                        setTimeout(onHide, 300); // Delay para dar tempo
                    } else if (savedPreference === 'web') {
                        //console.log("Desktop: Usando preferência salva 'web'.");
                        window.open(urls.web, '_blank', 'noopener,noreferrer'); // Abre web
                        onHide();
                    } else {
                        // Nenhuma preferência salva, mostra o modal
                        //console.log("Desktop: Nenhuma preferência salva. Exibindo modal.");
                        setShowChoiceModal(true);
                    // onHide será chamado após a escolha do usuário
                    }
                } else {
                    // Caso desconhecido ou TV/Console - talvez fallback para web?
                    //console.log(`Tipo de dispositivo ${deviceType} não tratado ou desconhecido, usando fallback web.`);
                    window.open(urls.web, '_blank', 'noopener,noreferrer');
                    onHide();
                }
            } else if (!show) {
                // Reseta quando o componente é "escondido"
                setIsProcessing(false);
                setShowChoiceModal(false);
                setPreparedUrls(null);
                setRememberChoice(false); // Reseta o checkbox também
            }
        }
    }["WhatsAppSender.useEffect"], [
        show,
        isProcessing,
        userMessage,
        baseMessage,
        phoneNumber,
        onHide
    ]); // Dependências do effect
    // Handler para a escolha no modal desktop
    const handleDesktopChoice = (useApp)=>{
        if (!preparedUrls) return;
        // --- Salva a Preferência se marcado ---
        if (rememberChoice) {
            const preferenceToSave = useApp ? 'app' : 'web';
            try {
                localStorage.setItem(WHATSAPP_PREFERENCE_KEY, preferenceToSave);
            //console.log("Preferência salva:", preferenceToSave);
            } catch (error) {
            //console.error("Erro ao salvar preferência no localStorage:", error);
            // Informar usuário? Ou apenas falhar silenciosamente?
            }
        }
        // Abre o link escolhido
        if (useApp) {
            //console.log("Usuário escolheu App (Desktop). Tentando URL:", preparedUrls.app);
            window.location.href = preparedUrls.app; // Tenta protocolo
        } else {
            //console.log("Usuário escolheu Navegador (Desktop). Abrindo URL:", preparedUrls.web);
            window.open(preparedUrls.web, '_blank', 'noopener,noreferrer'); // Abre wa.me
        }
        onHide(); // Chama onHide após a escolha e tentativa
    };
    // --- Renderização ---
    // Renderiza apenas o modal se for necessário (Desktop sem preferência salva)
    if (!show || !showChoiceModal || !preparedUrls || deviceType !== 'Desktop') {
        return null;
    }
    // Renderiza o Modal de Escolha para Desktop
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        show: showChoiceModal,
        onHide: onHide,
        centered: true,
        size: "sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                closeButton: true,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalChoiceHeader,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalChoiceTitle,
                    children: "Como abrir o WhatsApp?"
                }, void 0, false, {
                    fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                    lineNumber: 170,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                lineNumber: 169,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalChoiceBody,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Escolha como abrir o WhatsApp:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                        lineNumber: 173,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "d-grid gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "success",
                                onClick: ()=>handleDesktopChoice(true),
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalChoiceButton,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "fab fa-whatsapp me-2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                                        lineNumber: 176,
                                        columnNumber: 25
                                    }, this),
                                    " Abrir no Aplicativo"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                                lineNumber: 175,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "secondary",
                                onClick: ()=>handleDesktopChoice(false),
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalChoiceButton,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "fas fa-globe me-2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                                        lineNumber: 179,
                                        columnNumber: 25
                                    }, this),
                                    " Abrir no Navegador"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                                lineNumber: 178,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                        lineNumber: 174,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                        controlId: "whatsappRememberChoice",
                        className: "mt-3 text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Check, {
                            type: "checkbox",
                            label: "Lembrar minha escolha neste navegador",
                            checked: rememberChoice,
                            onChange: (e)=>setRememberChoice(e.target.checked),
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rememberCheckbox
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                            lineNumber: 184,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                        lineNumber: 183,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
                lineNumber: 172,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js",
        lineNumber: 168,
        columnNumber: 9
    }, this);
//     <Modal show={showChoiceModal} onHide={onHide} centered size="sm">
//         <Modal.Header closeButton className={styles.modalChoiceHeader}>
//             <Modal.Title className={styles.modalChoiceTitle}>Como deseja enviar?</Modal.Title>
//         </Modal.Header>
//         <Modal.Body className={styles.modalChoiceBody}>
//             <p>Escolha como abrir o WhatsApp:</p>
//             <div className="d-grid gap-2">
//                 <Button
//                     variant="success"
//                     onClick={() => handleDesktopChoice(true)}
//                     className={styles.modalChoiceButton}
//                 >
//                     <i className="fab fa-whatsapp me-2"></i> Abrir no Aplicativo
//                 </Button>
//                 <Button
//                     variant="secondary"
//                     onClick={() => handleDesktopChoice(false)}
//                     className={styles.modalChoiceButton}
//                 >
//                     <i className="fas fa-globe me-2"></i> Abrir no Navegador
//                 </Button>
//             </div>
//             <small className="text-muted d-block mt-3">
//                 Abrir no aplicativo tentará usar o WhatsApp Desktop e pode incluir emojis. Abrir no navegador usará o WhatsApp Web (pode não exibir alguns emojis).
//             </small>
//         </Modal.Body>
//     </Modal>
// );
}
_s(WhatsAppSender, "M/4vp5obVSV+hzaZiKoDVdDsiL8=");
_c = WhatsAppSender;
const __TURBOPACK__default__export__ = WhatsAppSender;
var _c;
__turbopack_context__.k.register(_c, "WhatsAppSender");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 /*

        if (deviceType == 'Mobile' || deviceType == 'Tablet' || deviceType == 'TV') {
            //console.log("Mobile: Tentando abrir app:", urls.app);
            window.open(`${urls.pho}`, '_blank', 'noopener,noreferrer');
            onHide(); // Fecha e indica que a ação foi tentada
            // Resetar estado interno? Não precisa aqui, será resetado quando show=false
        }

        if (deviceType == 'Desktop') {
            // Desktop: Mostra o modal de escolha
            //console.log("Desktop: Exibindo modal de escolha.");
            setShowChoiceModal(true);
            // Não chama onHide ainda, espera a escolha do usuário
        }
    } else if (!show) {
        // Reseta quando o componente é "escondido" pelo pai
        setIsProcessing(false);
        setShowChoiceModal(false);
        setPreparedUrls(null);
    }
*/ }),
"[project]/src/components/devsolar/estructure/body/cep.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Form.js [app-client] (ecmascript) <export default as Form>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
// Funções auxiliares (getDigits, formatCep) permanecem as mesmas
const getDigits = (value = '')=>value.replace(/\D/g, '');
const formatCep = (digits)=>{
    if (!digits) return '';
    const cepLength = digits.length;
    if (cepLength <= 5) return digits;
    return `${digits.slice(0, 5)}-${digits.slice(5, 8)}`;
};
// Adicionamos a prop 'name' para flexibilidade
const CustomCepInput = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s(({ initialValue = "", isRequired = true, onCepChange, name = "cep", stylesComp }, ref)=>{
    _s();
    const formatInitial = (val)=>formatCep(getDigits(val));
    const [cep, setCep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "CustomCepInput.useState": ()=>formatInitial(initialValue)
    }["CustomCepInput.useState"]);
    const [cepValid, setCepValid] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [cepTouched, setCepTouched] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const validateCep = (formattedCep)=>{
        if (!isRequired && formattedCep.trim() === '') return true;
        const cepRegex = /^[0-9]{5}-[0-9]{3}$/;
        return cepRegex.test(formattedCep);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CustomCepInput.useEffect": ()=>{
            const formattedInitial = formatInitial(initialValue);
            setCep(formattedInitial);
            setCepValid(validateCep(formattedInitial));
        }
    }["CustomCepInput.useEffect"], [
        initialValue,
        isRequired
    ]);
    const handleChange = (event)=>{
        const rawValue = event.target.value;
        const digits = getDigits(rawValue);
        const nextFormattedValue = formatCep(digits);
        // Só atualiza se o valor formatado realmente mudou
        // Isso pode ajudar a evitar loops ou conflitos com autofill
        if (nextFormattedValue !== cep) {
            setCep(nextFormattedValue);
            if (onCepChange) {
                onCepChange(nextFormattedValue);
            }
            if (cepTouched) {
                setCepValid(validateCep(nextFormattedValue));
            }
        }
    };
    const handleBlur = ()=>{
        setCepTouched(true);
        setCepValid(validateCep(cep));
    };
    const showError = cepTouched && !cepValid;
    // Gera um ID único ou usa o nome para o controlId, se não fornecido explicitamente
    const inputId = `customCep-${name}`;
    return(// Usar o ID gerado ou o nome para associar label e input
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
        className: "mb-3",
        controlId: inputId,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                style: stylesComp.formLabel,
                children: "CEP"
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/cep.js",
                lineNumber: 73,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control, {
                ref: inputRef,
                type: "text",
                placeholder: "_____-___",
                value: cep,
                onChange: handleChange,
                onBlur: handleBlur,
                required: isRequired,
                style: stylesComp.formControl,
                isInvalid: showError,
                maxLength: 9,
                inputMode: "numeric",
                // --- Atributos Chave para Autofill ---
                name: name,
                autoComplete: "postal-code"
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/cep.js",
                lineNumber: 74,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control.Feedback, {
                type: "invalid",
                children: isRequired && cep.trim() === '' && cepTouched ? 'O CEP é obrigatório.' : 'Por favor, insira um CEP válido no formato 12345-678.'
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/cep.js",
                lineNumber: 92,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/cep.js",
        lineNumber: 72,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0)));
}, "m8SrPgFCTr9WFfm2sry73r8K/wM=")), "m8SrPgFCTr9WFfm2sry73r8K/wM=");
_c1 = CustomCepInput;
CustomCepInput.displayName = 'CustomCepInput';
const __TURBOPACK__default__export__ = CustomCepInput;
var _c, _c1;
__turbopack_context__.k.register(_c, "CustomCepInput$forwardRef");
__turbopack_context__.k.register(_c1, "CustomCepInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$module$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$module$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/module.webp.mjs { IMAGE => "[project]/src/assets/module.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Form.js [app-client] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$cep$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/cep.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const ContactSectionDS = ({ textClassButton, textMessage, textTag })=>{
    _s();
    const [userMessage, setUserMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [whatsAppStatus, setWhatsAppStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('initial');
    const phone = '+5521999677722';
    const firstNameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(textMessage || '');
    const [messageWebWhastsapp, setMessageWebWhastsapp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // --- Dados ---
    const COMPANY_LOGO_URL = '@/assets/logo-devsolar-icon.webp';
    const WHATSAPP_CONTACT_NUMBER = '5521999677722';
    const WHATSAPP_BASE_MESSAGE = 'Olá! Solicito falar com um especialista e obter mais informações.\n\n';
    // --- Fim dos Dados ---
    // --- ESTADO PARA ATIVAR O WHATSAPP SENDER ---
    const [showWhatsAppSender, setShowWhatsAppSender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ContactSectionDS.useEffect": ()=>{
            if (showModal) {
                // Resetar a mensagem ao abrir o modal, se necessário
                setFormData({
                    "ContactSectionDS.useEffect": (prev)=>({
                            ...prev,
                            message: textMessage || ''
                        })
                }["ContactSectionDS.useEffect"]);
                // Focar o campo
                if (firstNameRef.current) {
                    firstNameRef.current.focus();
                }
            }
        }
    }["ContactSectionDS.useEffect"], [
        showModal,
        textMessage
    ]); // Adicionar textMessage como dependência se ele puder mudar
    // Estado para guardar todos os dados do formulário
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        firstName: '',
        cep: '',
        roofType: '',
        otherRoof: '',
        message: textMessage || ''
    });
    const resetFormData = ()=>{
        setWhatsAppStatus('initial');
        setFormData((prevData)=>({
                ...prevData,
                firstName: '',
                cep: '',
                roofType: '',
                otherRoof: '',
                message: textMessage || ''
            }));
    };
    // Estado para mostrar feedback após o envio (opcional)
    const [submittedData, setSubmittedData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Callback que será passada para o CustomCepInput
    // Recebe o valor FORMATADO do CEP sempre que ele muda
    const handleCepChange = (formattedCepValue)=>{
        setFormData((prevData)=>({
                ...prevData,
                cep: formattedCepValue
            }));
    };
    // Handler genérico para outros campos do formulário
    const handleInputChange = (event)=>{
        const { name, value } = event.target;
        setFormData((prevData)=>{
            const newData = {
                ...prevData,
                [name]: value
            };
            // Se o campo alterado foi 'roofType' E o novo valor NÃO é 'Outro'
            if (name === 'roofType' && value !== 'Outro') {
                newData.otherRoof = ''; // Limpa o otherRoof
            }
            return newData;
        });
    };
    // Dentro de ContactSectionDS
    const handleSubmit = (event)=>{
        event.preventDefault();
        // Campos obrigatórios
        if (!formData.firstName || !formData.cep || !formData.roofType || formData.roofType === 'Outro' && !formData.otherRoof) {
            // Idealmente, mostre um erro mais específico ou destaque os campos
            alert('Preencha todos os campos obrigatórios.');
            setWhatsAppStatus('initial'); // Resetar status se falhar aqui
            return;
        }
        // Monta a mensagem (pode mover a lógica de dataToSend para cá)
        const finalMessage = formData.message || textMessage || 'Olá, quero falar com um especialista.'; // Garante uma mensagem
        const messageBody = `*Nome:* ${formData.firstName}\n` + `*CEP:* ${formData.cep}\n` + `*Tipo de Telhado:* ${formData.roofType === 'Outro' ? formData.otherRoof : formData.roofType}\n\n` + `*Mensagem:* ${finalMessage}\n\n` + // Usar finalMessage
        `${textTag || ''}`; // Adicionar tag se existir
        const encodedMessage = encodeURIComponent(messageBody);
        setUserMessage(messageBody);
        handleInitiateSend();
        closeForm();
    //handleWhatsAppSenderClose()
    // onClick={handleInitiateSend} disabled={userMessage.trim() === ''
    // 4. Tentar abrir WhatsApp (abordagem simplificada - oferece web como fallback)
    // A detecção de mobile é opcional aqui. Pode tentar o app primeiro.
    //const whatsappUrlApp = `whatsapp://send?phone=${phone}&text=${encodedMessage}`;
    //const whatsappUrlWeb = `https://web.whatsapp.com/send?phone=${phone}&text=${encodedMessage}`; // Corrigido: ?text=
    //setMessageWebWhastsapp(encodedMessage)
    //setWhatsAppStatus("sending"); // Opcional: estado de envio
    // Tenta abrir o app. Se não conseguir (comum no desktop),
    // ou se explicitamente quiser o web, usa o link web.
    // Uma forma simples é sempre oferecer o web como fallback ou opção.
    //try {
    // Tenta o app primeiro (pode não funcionar no desktop sem handler)
    // window.location.href = whatsappUrlApp; // Usar window.open é mais seguro para popups
    // Alternativa: Abrir Web diretamente ou como fallback
    //window.open(whatsappUrlApp, "_blank", "noopener noreferrer");
    //setWhatsAppStatus("sent"); // Ou apenas fechar
    //closeForm(); // Fechar o modal após sucesso
    //} catch (error) {
    //console.error("Erro ao tentar abrir WhatsApp:", error);
    // Se a tentativa acima falhar ou se quiser sempre oferecer:
    //setWhatsAppStatus("failed_fallback_web"); // Novo estado para indicar fallback
    // Não feche o formulário aqui, mostre a opção web
    //}
    };
    const resetFormState = ()=>{
        // Renomeado para clareza
        setFormData({
            firstName: '',
            cep: '',
            roofType: '',
            otherRoof: '',
            message: textMessage || ''
        });
        setWhatsAppStatus('initial');
    };
    function closeForm() {
        resetFormState();
        setShowModal(false);
    }
    // Função que ATIVA o processo de envio
    const handleInitiateSend = ()=>{
        // if (userMessage.trim() === '') return;
        setShowWhatsAppSender(true); // Ativa o componente WhatsAppSender
    };
    // Função chamada pelo WhatsAppSender quando o processo termina (ou é cancelado)
    const handleWhatsAppSenderClose = ()=>{
        setShowWhatsAppSender(false); // Desativa o sender
        setUserMessage(''); // Limpa o input AQUI
    };
    const modalStyles = {
        modalContent: {
            backgroundImage: `url('${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$module$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$module$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"].src}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            color: 'white',
            border: '1px solid #a0a1a4',
            borderRadius: '0.3rem',
            overflow: 'hidden'
        },
        modalHeader: {
            border: 'none',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            color: 'white',
            padding: '15px 20px',
            position: 'relative'
        },
        modalTitle: {
            color: '#ff9e00',
            textShadow: '1px 1px 2px rgba(0, 0, 0, 0.8)',
            marginTop: 100
        },
        closeButton: {
            position: 'absolute',
            right: '15px',
            top: '15px',
            width: '40px',
            height: '40px',
            background: 'black',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            border: 'none',
            boxShadow: '0 0 10px rgba(0, 0, 0, 0.5)',
            opacity: 1,
            transition: 'all 0.2s ease'
        },
        closeButtonIcon: {
            fontSize: '40px',
            fontWeight: 'bold',
            color: '#ddd',
            lineHeight: '1',
            textShadow: 'none',
            marginBottom: 6
        },
        modalBody: {
            padding: '20px',
            backgroundColor: 'rgba(0, 0, 0, 0.5)'
        },
        formLabel: {
            color: 'white',
            textShadow: '1px 1px 2px rgba(0, 0, 0, 0.8)',
            fontWeight: 'bold'
        },
        formControl: {
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            borderColor: 'blue'
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: textClassButton,
                onClick: ()=>{
                    setShowModal(true);
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                        iconClass: "fas fa-headset",
                        className: "me-2",
                        "aria-label": "Falar com Especialista"
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                        lineNumber: 259,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Falar com um Especialista"
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                        lineNumber: 264,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                lineNumber: 253,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                show: showModal,
                onHide: closeForm,
                centered: true,
                contentClassName: "custom-modal-content",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: modalStyles.modalContent,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                            style: modalStyles.modalHeader,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                                    style: modalStyles.modalTitle,
                                    children: "Solicito falar com Especialista:"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                    lineNumber: 275,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    style: modalStyles.closeButton,
                                    onClick: closeForm,
                                    "aria-label": "Fechar",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: modalStyles.closeButtonIcon,
                                            children: "×"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                            lineNumber: 285,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "visually-hidden",
                                            children: "Fechar"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                            lineNumber: 286,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                    lineNumber: 279,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                            lineNumber: 274,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                            style: modalStyles.modalBody,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
                                onSubmit: handleSubmit,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                        className: "mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                                                htmlFor: "firstName",
                                                style: modalStyles.formLabel,
                                                children: "Nome"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 292,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control, {
                                                ref: firstNameRef,
                                                type: "text",
                                                autoComplete: "given-name",
                                                name: "firstName",
                                                value: formData.firstName,
                                                onChange: handleInputChange,
                                                required: true,
                                                id: "firstName",
                                                style: modalStyles.formControl
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 295,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                        lineNumber: 291,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                                md: 4,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$cep$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        stylesComp: modalStyles,
                                                        name: "cep",
                                                        initialValue: formData.cep,
                                                        onCepChange: handleCepChange,
                                                        isRequired: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                        lineNumber: 310,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                    lineNumber: 309,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 308,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                                md: 8,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                                                            htmlFor: "roofType",
                                                            style: modalStyles.formLabel,
                                                            children: "Tipo de Telhado"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                            lineNumber: 322,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Select, {
                                                            name: "roofType",
                                                            value: formData.roofType,
                                                            onChange: handleInputChange,
                                                            required: true,
                                                            id: "roofType",
                                                            style: modalStyles.formControl,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: "Selecione..."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 336,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "Metálico",
                                                                    children: "Metálico"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 337,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "Cerâmico",
                                                                    children: "Cerâmico"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 338,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "Fibrocimento",
                                                                    children: "Fibrocimento"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 339,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "Concreto",
                                                                    children: "Concreto"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 340,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "PVC",
                                                                    children: "PVC"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 341,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "Outro",
                                                                    children: "Outro"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                                    lineNumber: 342,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                            lineNumber: 328,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                    lineNumber: 321,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 320,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                        lineNumber: 307,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    formData.roofType === 'Outro' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                        className: "mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                                                htmlFor: "otherRoof",
                                                style: modalStyles.formLabel,
                                                children: "Especifique"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 350,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control, {
                                                type: "text",
                                                name: "otherRoof",
                                                value: formData.otherRoof,
                                                onChange: handleInputChange,
                                                required: true,
                                                id: "otherRoof",
                                                style: modalStyles.formControl
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 353,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                        lineNumber: 349,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                        className: "mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                                                children: "Mensagem"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 366,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control, {
                                                id: "message",
                                                as: "textarea",
                                                rows: 3,
                                                placeholder: "Digite seu texto aqui...",
                                                spellCheck: "true",
                                                name: "message",
                                                value: formData.message,
                                                onChange: handleInputChange
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 367,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                        lineNumber: 365,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "d-grid",
                                        style: {
                                            marginTop: 50,
                                            marginBottom: 340
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                variant: "primary",
                                                type: "submit",
                                                "aria-label": "Enviar mensagem via WhatsApp",
                                                children: "Enviar Solicitação"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 383,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            whatsAppStatus === 'failed_fallback_web' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    marginTop: 20,
                                                    color: 'yellow'
                                                },
                                                children: [
                                                    ' ',
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "Não foi possível abrir o app WhatsApp automaticamente."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                        lineNumber: 394,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            href: `https://web.whatsapp.com/send?phone=${phone}&text=${messageWebWhastsapp}`,
                                                            "aria-label": "Enviar mensagem via WhatsApp",
                                                            target: "_blank",
                                                            rel: "noopener noreferrer",
                                                            onClick: ()=>{
                                                                // Opcional: Fechar o modal após clicar no link web
                                                                // closeForm();
                                                                setWhatsAppStatus('initial'); // Reseta o status
                                                            },
                                                            children: "Clique aqui para tentar enviar pela versão Web do WhatsApp"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                            lineNumber: 398,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                        lineNumber: 397,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                                lineNumber: 391,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                        lineNumber: 379,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                                lineNumber: 290,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                            lineNumber: 289,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                    lineNumber: 273,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                lineNumber: 267,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$whatsapp$2f$whatsapp_sender_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                show: showWhatsAppSender,
                onHide: handleWhatsAppSenderClose,
                phoneNumber: WHATSAPP_CONTACT_NUMBER,
                baseMessage: WHATSAPP_BASE_MESSAGE,
                userMessage: userMessage
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js",
                lineNumber: 422,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(ContactSectionDS, "B0dFYSkIxlIxWa9u176izB3a0AI=");
_c = ContactSectionDS;
const __TURBOPACK__default__export__ = ContactSectionDS;
var _c;
__turbopack_context__.k.register(_c, "ContactSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/header/header_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "header_ds-module__AbovtW__active",
  "auth-modal": "header_ds-module__AbovtW__auth-modal",
  "auth-tabs": "header_ds-module__AbovtW__auth-tabs",
  "btnContainer": "header_ds-module__AbovtW__btnContainer",
  "calculateButton": "header_ds-module__AbovtW__calculateButton",
  "chartContainer": "header_ds-module__AbovtW__chartContainer",
  "chartDisclaimer": "header_ds-module__AbovtW__chartDisclaimer",
  "chartTitle": "header_ds-module__AbovtW__chartTitle",
  "container": "header_ds-module__AbovtW__container",
  "currencyInput": "header_ds-module__AbovtW__currencyInput",
  "facebook-btn": "header_ds-module__AbovtW__facebook-btn",
  "google-btn": "header_ds-module__AbovtW__google-btn",
  "hero": "header_ds-module__AbovtW__hero",
  "heroBackground": "header_ds-module__AbovtW__heroBackground",
  "heroButtonPrimary": "header_ds-module__AbovtW__heroButtonPrimary",
  "heroButtonSecondary": "header_ds-module__AbovtW__heroButtonSecondary",
  "heroOverlay": "header_ds-module__AbovtW__heroOverlay",
  "inputGroupText": "header_ds-module__AbovtW__inputGroupText",
  "microsoft-btn": "header_ds-module__AbovtW__microsoft-btn",
  "modalBodyInput": "header_ds-module__AbovtW__modalBodyInput",
  "modalBodyResult": "header_ds-module__AbovtW__modalBodyResult",
  "modalDialog": "header_ds-module__AbovtW__modalDialog",
  "modalFooter": "header_ds-module__AbovtW__modalFooter",
  "modalHeader": "header_ds-module__AbovtW__modalHeader",
  "modalTitle": "header_ds-module__AbovtW__modalTitle",
  "nav-link": "header_ds-module__AbovtW__nav-link",
  "oauth-btn": "header_ds-module__AbovtW__oauth-btn",
  "resultHighlight": "header_ds-module__AbovtW__resultHighlight",
  "resultLabel": "header_ds-module__AbovtW__resultLabel",
  "resultValue": "header_ds-module__AbovtW__resultValue",
  "textContainer": "header_ds-module__AbovtW__textContainer",
});
}),
"[project]/src/components/devsolar/estructure/body/header/header_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/logo_sm.webp.mjs { IMAGE => "[project]/src/assets/logo_sm.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)'); // Importa a imagem do logo pequeno
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$photovoltaic$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$photovoltaic$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/photovoltaic.webp.mjs { IMAGE => "[project]/src/assets/photovoltaic.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$solarCalculations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/solarCalculations.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>"); // Adicionar Button, Spinner
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Spinner$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Spinner.js [app-client] (ecmascript) <export default as Spinner>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js [app-client] (ecmascript)"); // Confirme o caminho
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/header/header_ds.module.css [app-client] (css module)"); // Importar CSS Module
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const Example = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/tremor/area-chart-15.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/tremor/area-chart-15.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Example;
// --- Constantes de Configuração (Mover para arquivo .config.js ou similar idealmente) ---
const HERO_IMAGE_URL = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$photovoltaic$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$photovoltaic$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"];
const FALE_CONOSCO_BTN_CLASS = 'btn btn-outline-light btn-lg mb-3'; // Classe do botão "Falar com Especialista"
const FALE_CONOSCO_MESSAGE = 'Olá, quero falar com especialista.';
const FALE_CONOSCO_TAG_HERO = '#solNaEconomia';
const FALE_CONOSCO_TAG_RESULT = '#calculaEconomia'; // Tag base para resultado
// --- Componente Principal ---
function HeaderDS() {
    _s();
    // Estados do Modal
    const [showInputModal, setShowInputModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showResultModal, setShowResultModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [calculando, setCalculando] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [inputValueToMsg, setInputValueToMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0); // Valor como string para o input
    // Estado do Input (Controlado)
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''); // Valor como string para o input
    const inputCustoMesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Estado para os Resultados
    const [calculationResult, setCalculationResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // Guarda todo o resultado do cálculo
    // Formatter de Moeda (Exibição)
    const currencyFormatter = new Intl.NumberFormat('pt-BR', {
        // style: 'currency', // Opcional: Adiciona R$
        // currency: 'BRL',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    // Foco no input ao abrir modal
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeaderDS.useEffect": ()=>{
            if (showInputModal && inputCustoMesRef.current) {
                inputCustoMesRef.current.focus();
            }
        }
    }["HeaderDS.useEffect"], [
        showInputModal
    ]);
    // Limpa input ao fechar modal
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeaderDS.useEffect": ()=>{
            if (!showInputModal && !showResultModal) {
                setInputValue('');
                setCalculationResult(null); // Limpa resultado também
            }
        }
    }["HeaderDS.useEffect"], [
        showInputModal,
        showResultModal
    ]);
    // Handler do Input de Custo
    const handleInputChange = (e)=>{
        const rawValue = e.target.value.replace(/[^0-9]/g, '').substring(0, 11); // Permite apenas dígitos
        setInputValue(rawValue); // Atualiza o estado da string do input
    };
    // Função para obter o valor numérico do input
    const getNumericCost = ()=>{
        if (!inputValue) return 0;
        const num = parseInt(inputValue, 10);
        return num / 100; // Divide por 100 para obter o valor em Reais (ex: 12345 -> 123.45)
    };
    // Formata o valor numérico para exibição no input
    const formatValueForInput = (rawStringValue)=>{
        if (!rawStringValue) return '';
        const num = parseInt(rawStringValue, 10);
        if (isNaN(num)) return '';
        return currencyFormatter.format(num / 100);
    };
    // Abre o modal de input
    const handleShowInput = ()=>{
        setShowInputModal(true);
    };
    // Fecha o modal de input, calcula e abre o modal de resultado
    const handleCalculateAndShowResult = async ()=>{
        const numericCost = getNumericCost();
        if (numericCost < 300 || numericCost > 999999999.99) return; // Não calcula se o valor for inválido
        setShowInputModal(false);
        setCalculando(true);
        setCalculationResult(null); // Limpa resultado anterior
        // Simula um pequeno atraso para o cálculo (pode remover se o cálculo for rápido)
        // ou mantenha para melhor UX visual do spinner
        await new Promise((resolve)=>setTimeout(resolve, 600));
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$solarCalculations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calcularEconomiaSolar"])(numericCost); // Chama a função de cálculo refatorada
        setCalculationResult(result);
        setCalculando(false);
        if (!result.error) {
            setShowResultModal(true);
        } else {
            // Poderia mostrar um alerta de erro aqui
            //console.error("Erro no cálculo:", result.error);
            alert(`Erro ao calcular: ${result.error}. Verifique o valor inserido.`); // Feedback simples
        }
    };
    // Fecha o modal de resultado
    const handleHideResult = ()=>{
        setShowResultModal(false);
    // O useEffect de limpeza cuidará de resetar o inputValue
    };
    // Previne envio com Enter no input de custo
    const handleInputKeyDown = (e)=>{
        if (e.key === 'Enter') {
            e.preventDefault();
            if (getNumericCost() > 0) {
                handleCalculateAndShowResult();
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    id: "home",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].hero,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "position-relative container",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `col-lg-6 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textContainer}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                className: "display-4 fw-bold mb-4",
                                                children: "Transforme o Sol do Rio de Janeiro em Economia Real com Energia Solar"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                lineNumber: 141,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "lead mb-4",
                                                children: "Reduza a conta de luz da sua casa, empresa ou condomínio em até 95% e proteja-se dos aumentos de tarifa."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                lineNumber: 145,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                        lineNumber: 140,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `col-lg- ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].btnContainer}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                    variant: "primary",
                                                    size: "lg",
                                                    className: `mb-3 me-3 ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroButtonPrimary}`,
                                                    onClick: handleShowInput,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                            iconClass: "fas fa-calculator",
                                                            className: "me-2",
                                                            "aria-label": "Calcular Economia",
                                                            "aria-hidden": "true"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                            lineNumber: 159,
                                                            columnNumber: 21
                                                        }, this),
                                                        "Calcular Economia"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                    lineNumber: 153,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    textClassButton: `${FALE_CONOSCO_BTN_CLASS} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroButtonSecondary}`,
                                                    textMessage: FALE_CONOSCO_MESSAGE,
                                                    textTag: FALE_CONOSCO_TAG_HERO
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                    lineNumber: 168,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 151,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 139,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBackground,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    alt: "Fazenda de painéis solares",
                                    src: HERO_IMAGE_URL,
                                    fill: true,
                                    style: {
                                        objectFit: 'cover'
                                    },
                                    quality: 70,
                                    fetchPriority: "high",
                                    priority: true,
                                    loading: "eager"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroOverlay
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                    lineNumber: 188,
                                    columnNumber: 13
                                }, this),
                                " "
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                            lineNumber: 177,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                    lineNumber: 137,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                lineNumber: 135,
                columnNumber: 7
            }, this),
            ' ',
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                show: showInputModal,
                onHide: ()=>setShowInputModal(false),
                centered: true,
                size: "md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                        closeButton: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalHeader,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                            children: "Quanto Posso Economizar?"
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                            lineNumber: 201,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                        lineNumber: 200,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalBodyInput,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Informe o valor médio mensal da sua conta de luz para simular sua economia - valor minímo de R$ 300,00:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 204,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "input-group mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `input-group-text ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputGroupText}`,
                                        children: "R$"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                        lineNumber: 209,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        ref: inputCustoMesRef,
                                        type: "text",
                                        inputMode: "numeric",
                                        className: `form-control form-control-lg ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].currencyInput}`,
                                        id: "valor-consumo",
                                        name: "valor-consumo",
                                        value: formatValueForInput(inputValue),
                                        onChange: handleInputChange,
                                        onKeyDown: handleInputKeyDown,
                                        placeholder: "0,00",
                                        autoComplete: "off"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                        lineNumber: 212,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 208,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalFooter,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "secondary",
                                onClick: ()=>setShowInputModal(false),
                                children: "Cancelar"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 228,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "primary",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].calculateButton,
                                onClick: handleCalculateAndShowResult,
                                disabled: calculando || getNumericCost() < 300,
                                children: calculando ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Spinner$3e$__["Spinner"], {
                                            animation: "border",
                                            size: "sm",
                                            role: "status",
                                            "aria-hidden": "true",
                                            className: "me-2"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 239,
                                            columnNumber: 17
                                        }, this),
                                        "Calculando..."
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "fas fa-calculator me-2"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 250,
                                            columnNumber: 17
                                        }, this),
                                        "Calcular Economia"
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 231,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                        lineNumber: 227,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                lineNumber: 194,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                show: showResultModal,
                onHide: handleHideResult,
                centered: true,
                size: "xl",
                children: [
                    ' ',
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                        closeButton: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalHeader,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                            className: "w-100",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "position-relative d-flex align-items-center w-100",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
                                        alt: "Logo DEV Solar",
                                        width: 140,
                                        height: 38
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                        lineNumber: 268,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "position-absolute start-50 translate-middle-x text-center",
                                        style: {
                                            fontSize: '2rem',
                                            fontWeight: '500'
                                        },
                                        children: "Resultado da Simulação"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                        lineNumber: 269,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 267,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                            lineNumber: 266,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalBodyResult,
                        children: calculando ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-5 text-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Spinner$3e$__["Spinner"], {
                                animation: "border",
                                role: "status",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "visually-hidden",
                                    children: "Carregando..."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                    lineNumber: 282,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 281,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                            lineNumber: 280,
                            columnNumber: 13
                        }, this) : calculationResult && !calculationResult.error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                                    className: "mb-4 text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            md: 4,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultHighlight,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultLabel,
                                                        children: "Investimento Estimado"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                        lineNumber: 290,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultValue,
                                                        children: [
                                                            "R$",
                                                            ' ',
                                                            currencyFormatter.format(calculationResult.investimentoEstimado)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                        lineNumber: 293,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                lineNumber: 289,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 288,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            md: 4,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultHighlight,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultLabel,
                                                        children: "Payback Estimado"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                        lineNumber: 303,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultValue,
                                                        children: calculationResult.text_payback
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                        lineNumber: 304,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                lineNumber: 302,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 301,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            md: 4,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultHighlight,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultLabel,
                                                        children: "Potência do Sistema"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                        lineNumber: 311,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultValue,
                                                        children: [
                                                            currencyFormatter.format(calculationResult.potenciaEstimadaKwp),
                                                            ' ',
                                                            "kWp"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                        lineNumber: 314,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                                lineNumber: 310,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 309,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                    lineNumber: 287,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].chartContainer,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].chartTitle,
                                            children: [
                                                "Projeção de Economia Acumulada vs Custo Evitado (",
                                                calculationResult.projecao,
                                                " Anos)"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 325,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Example, {
                                            dataProject: calculationResult
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                            lineNumber: 329,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                    lineNumber: 324,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].chartDisclaimer,
                                    children: "*Valores e projeções são estimativas e podem variar, fale com especialista."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                    lineNumber: 331,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-danger p-4 text-center",
                            children: "Não foi possível gerar o resultado. Verifique o valor informado."
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                            lineNumber: 337,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                        lineNumber: 278,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalFooter,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "secondary",
                                onClick: handleHideResult,
                                children: "Fechar"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 343,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                textClassButton: `btn btn-primary ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$header_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroButtonPrimary}`,
                                textMessage: `Olá, vi minha simulação de economia, meu custo médio mensal é de R$ ${currencyFormatter.format(calculationResult && calculationResult.custoMensalInformado)} e quero falar com especialista.`,
                                textTag: `${FALE_CONOSCO_TAG_RESULT}`
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                                lineNumber: 346,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                        lineNumber: 342,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/header/header_ds.js",
                lineNumber: 257,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(HeaderDS, "7jIgsJakSqs2RXVfBSmackJ6DtU=");
_c1 = HeaderDS;
const __TURBOPACK__default__export__ = HeaderDS;
var _c, _c1;
__turbopack_context__.k.register(_c, "Example");
__turbopack_context__.k.register(_c1, "HeaderDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/header/nav_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "align-items-center": "nav_ds-module__5jmWZW__align-items-center",
  "footerLogo": "nav_ds-module__5jmWZW__footerLogo",
  "loginButton": "nav_ds-module__5jmWZW__loginButton",
  "navLinkCustom": "nav_ds-module__5jmWZW__navLinkCustom",
  "navbarBrandCustom": "nav_ds-module__5jmWZW__navbarBrandCustom",
  "navbarCustom": "nav_ds-module__5jmWZW__navbarCustom",
});
}),
"[project]/src/components/devsolar/estructure/body/header/nav_links_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "navLinksData",
    ()=>navLinksData
]);
'use client';
const navLinksData = [
    {
        id: 'beneficios',
        href: '#beneficios',
        text: 'Benefícios'
    },
    {
        id: 'modalidades',
        href: '#modalidades',
        text: 'Serviços'
    },
    {
        id: 'cases',
        href: '#cases',
        text: 'Cases de Sucesso'
    },
    {
        id: 'faq',
        href: '#faq',
        text: 'FAQ'
    },
    {
        id: 'location',
        href: '#location',
        text: 'Localização'
    },
    {
        id: 'parceiros',
        href: '#parceiros',
        text: 'Parceiros'
    },
    {
        id: 'contato',
        href: '#contato',
        text: 'Contato'
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/header/nav_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// Necessário pelos hooks
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/logo_sm.webp.mjs { IMAGE => "[project]/src/assets/logo_sm.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nav$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Nav.js [app-client] (ecmascript) <export default as Nav>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navbar$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Navbar.js [app-client] (ecmascript) <export default as Navbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/header/nav_ds.module.css [app-client] (css module)"); // Importar CSS Module
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_links_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/header/nav_links_ds.js [app-client] (ecmascript)"); // Importar dados dos links
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const LeadAccessModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/devsolar/estructure/body/header/LeadAccessModal.js [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/devsolar/estructure/body/header/LeadAccessModal.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = LeadAccessModal;
const LOGO_URL = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo_sm$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"].src;
function NavDS() {
    _s();
    const [modalShow, setModalShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // Estado do menu hamburger
    const navbarRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Ref para a Navbar
    const smoothScrollTo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NavDS.useCallback[smoothScrollTo]": (targetY)=>{
            const startY = window.scrollY;
            const distance = targetY - startY;
            if (Math.abs(distance) < 2) {
                return;
            }
            const duration = Math.min(900, Math.max(350, Math.abs(distance) * 0.35));
            const startTime = performance.now();
            const easeInOutCubic = {
                "NavDS.useCallback[smoothScrollTo].easeInOutCubic": (t)=>t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
            }["NavDS.useCallback[smoothScrollTo].easeInOutCubic"];
            const step = {
                "NavDS.useCallback[smoothScrollTo].step": (currentTime)=>{
                    const elapsed = currentTime - startTime;
                    const progress = Math.min(1, elapsed / duration);
                    const eased = easeInOutCubic(progress);
                    window.scrollTo(0, Math.round(startY + distance * eased));
                    if (progress < 1) {
                        window.requestAnimationFrame(step);
                    }
                }
            }["NavDS.useCallback[smoothScrollTo].step"];
            window.requestAnimationFrame(step);
        }
    }["NavDS.useCallback[smoothScrollTo]"], []);
    // --- Lógica para Scroll Padding Dinâmico ---
    const updateScrollPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NavDS.useCallback[updateScrollPadding]": ()=>{
            if (navbarRef.current) {
                const navbarHeight = navbarRef.current.offsetHeight;
                document.documentElement.style.setProperty('--scroll-padding', `${navbarHeight + 20}px`);
                // Aplica diretamente também para garantir compatibilidade
                document.documentElement.style.scrollPaddingTop = `${navbarHeight + 20}px`;
            } else {
                // Fallback se a navbar não for encontrada imediatamente
                document.documentElement.style.setProperty('--scroll-padding', `90px`);
                document.documentElement.style.scrollPaddingTop = `90px`;
            }
        }
    }["NavDS.useCallback[updateScrollPadding]"], []); // useCallback sem dependências, pois navbarRef.current não deve ser dependência
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavDS.useEffect": ()=>{
            // Define o padding inicial
            updateScrollPadding();
            // Adiciona listener para redimensionamento
            window.addEventListener('resize', updateScrollPadding);
            // Função de limpeza para remover o listener e o estilo
            return ({
                "NavDS.useEffect": ()=>{
                    window.removeEventListener('resize', updateScrollPadding);
                    document.documentElement.style.removeProperty('--scroll-padding');
                    document.documentElement.style.scrollPaddingTop = '';
                }
            })["NavDS.useEffect"];
        }
    }["NavDS.useEffect"], [
        updateScrollPadding
    ]); // Depende da função memoizada
    // --- Handlers ---
    const handleNavLinkClick = (e)=>{
        const href = e.currentTarget?.getAttribute('href') || '';
        if (!href.includes('#')) {
            setExpanded(false);
            return;
        }
        e.preventDefault();
        const hash = href.slice(href.indexOf('#'));
        const targetId = hash.replace('#', '');
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            const navbarHeight = navbarRef.current?.offsetHeight || 70;
            const top = targetElement.getBoundingClientRect().top + window.scrollY - (navbarHeight + 20);
            smoothScrollTo(top);
        }
        setExpanded(false); // Fecha o menu mobile ao clicar em um link
    };
    const handleBrandClick = (e)=>{
        e.preventDefault(); // Previne a navegação padrão para '#'
        setExpanded(false);
        smoothScrollTo(0); // Scroll suave para o topo
    };
    const handleShowLoginModal = ()=>{
        setModalShow(true);
        setExpanded(false); // Fecha o menu mobile ao abrir o modal
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navbar$3e$__["Navbar"], {
                ref: navbarRef,
                expand: "lg",
                // Usa classe do module OU mantém as classes Bootstrap/custom
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navbarCustom} bg-body-tertiary navbar-light sticky-top bg-white py-2 shadow-sm`,
                expanded: expanded,
                onToggle: setExpanded,
                collapseOnSelect: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
                    className: "py-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navbar$3e$__["Navbar"].Brand, {
                            href: "/#home",
                            onClick: handleBrandClick,
                            "aria-label": "Ir para o topo da página",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navbarBrandCustom,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoImg,
                                src: LOGO_URL,
                                alt: "Logo da DEV Solar",
                                width: 140,
                                height: 38
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                                lineNumber: 141,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                            lineNumber: 135,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navbar$3e$__["Navbar"].Toggle, {
                            "aria-controls": "basic-navbar-nav"
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                            lineNumber: 151,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navbar$3e$__["Navbar"].Collapse, {
                            id: "basic-navbar-nav",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nav$3e$__["Nav"], {
                                className: "align-items-center ms-auto",
                                children: [
                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_links_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navLinksData"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nav$3e$__["Nav"].Link, {
                                            href: link.href,
                                            onClick: handleNavLinkClick,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].navLinkCustom,
                                            children: link.text
                                        }, link.id, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                                            lineNumber: 159,
                                            columnNumber: 17
                                        }, this)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        variant: "outline-secondary",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$header$2f$nav_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loginButton} ms-lg-3 mt-lg-0 mt-2`,
                                        "aria-label": "Entrar ou acessar área do cliente",
                                        onClick: handleShowLoginModal,
                                        disabled: false,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                iconClass: "fas fa-user",
                                                className: "me-lg-2 me-1",
                                                "aria-label": "Entrar",
                                                "aria-hidden": "true"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                                                lineNumber: 177,
                                                columnNumber: 17
                                            }, this),
                                            ' ',
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "d-inline-block",
                                                children: "Entrar"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                                                lineNumber: 184,
                                                columnNumber: 17
                                            }, this),
                                            ' '
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                                        lineNumber: 170,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                                lineNumber: 156,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                            lineNumber: 154,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                    lineNumber: 133,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                lineNumber: 124,
                columnNumber: 7
            }, this),
            modalShow ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LeadAccessModal, {
                show: modalShow,
                onHide: ()=>setModalShow(false)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/header/nav_ds.js",
                lineNumber: 198,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true);
}
_s(NavDS, "9VllhgbU4MUC54ROyZewmDoKTao=");
_c1 = NavDS;
const __TURBOPACK__default__export__ = NavDS;
var _c, _c1;
__turbopack_context__.k.register(_c, "LeadAccessModal");
__turbopack_context__.k.register(_c1, "NavDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/benefits_data_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "benefitsData",
    ()=>benefitsData
]);
'use client';
// src/data/benefitsData.js ou um local similar
/**
 * Estrutura de dados para a seção de benefícios.
 * Cada objeto no array principal representa um benefício.
 * Cada benefício contém um array de 'categories' (Residência, Condomínio, Empresa).
 * Cada categoria contém um objeto 'detail' com informações específicas,
 * gerado pela função auxiliar createCategoryDetail.
 */ // Função auxiliar para criar a estrutura de detalhes da categoria
const createCategoryDetail = (id, title, detailTitle, text, citations, references, contactMessage, contactTag)=>({
        id,
        title,
        detailTitle,
        text,
        citations: citations.map((cite, index)=>({
                id: `cite-${id}-${index + 1}`,
                text: cite.text,
                link: cite.link
            })),
        references: references.map((ref, index)=>({
                id: `ref-${id}-${index + 1}`,
                text: ref
            })),
        contactMessage,
        contactTag
    });
const benefitsData = [
    // 1. Economia Imediata
    {
        id: 'economia',
        title: 'Economia Imediata',
        iconClass: 'fa-solid fa-piggy-bank',
        description: 'Reduza sua conta de luz em até 95% já no primeiro mês após a instalação.',
        modalTitle: 'Economia Imediata com Energia Solar',
        contactMessageBase: 'Olá, tenho interesse em reduzir custos com energia elétrica e quero falar com especialista.',
        contactTagBase: '#economiaImediata',
        categories: [
            {
                id: 'economia-residencia',
                iconClass: 'fa-solid fa-house',
                title: 'Residência',
                description: 'Reduza drasticamente ou elimine sua conta de luz já no primeiro mês.',
                detail: createCategoryDetail('ec-res', 'Residência - Economia Imediata', 'Elimine sua conta de luz já no primeiro mês após a instalação.', 'O investimento inicial se paga com a economia contínua ao longo dos anos.', [
                    {
                        text: '"Com a instalação de um sistema fotovoltaico, você pode reduzir drasticamente os custos com energia elétrica..."',
                        link: 'https://blog.intelbras.com.br/como-funciona-energia-solar-residencial/'
                    },
                    {
                        text: '"Sistema fotovoltaico pode economizar até 95% na sua conta de energia..."',
                        link: 'https://solalux.com.br/sistema-fotovoltaico-economia-energia/'
                    },
                    {
                        text: '"Redução de custos com energia elétrica é um dos principais benefícios..."',
                        link: 'https://www.reenergisa.com.br/blog/fontes-renovaveis/conheca-os-muitos-beneficios-da-energia-solar-para-residencias-e-empresas'
                    }
                ], [
                    '[1] Como funciona a energia solar residencial... Intelbras Blog. Acesso em: 11 abr. 2025.',
                    '[2] Sistema Fotovoltaico: Como Economizar Até 95%... Solalux. Acesso em: 11 abr. 2025.',
                    '[3] Conheça os muitos benefícios da Energia Solar... Reenergisa. Acesso em: 11 abr. 2025.'
                ], 'Olá, tenho interesse em reduzir custos com energia elétrica na residência e quero falar com especialista.', '#economia #residencial')
            },
            {
                id: 'economia-condominio',
                iconClass: 'fas fa-building',
                title: 'Condomínio',
                description: 'Diminua significativamente a taxa condominial para todos os moradores.',
                detail: createCategoryDetail('ec-con', 'Condomínio - Economia Imediata', 'Diminua significativamente a taxa condominial para todos os moradores.', 'Gere uma economia coletiva imediata, tornando o custo de vida mais acessível.', [
                    {
                        text: '"Reajustar a taxa condominial anualmente... permite contemplar correções..."',
                        link: 'https://vieirabraga.com.br/defesa-em-caso-de-divida-de-taxa-condominial-o-que-fazer/'
                    },
                    {
                        text: '"Ações coletivas, como instalação de energia solar, reduzem custos condominiais..."',
                        link: 'https://repositorio.ulisboa.pt/bitstream/10451/38313/1/ulfc124909_tm_Tom%C3%A1s_Jord%C3%A3o.pdf'
                    },
                    {
                        text: '"Pequenas atitudes, como otimização de recursos, geram economia no dia a dia..."',
                        link: 'https://fabasa.com.br/2023/04/27/pequenas-atitudes-podem-gerar-economia-no-dia-a-dia/'
                    }
                ], [
                    '[1] Defesa em caso de dívida de taxa condominial... Vieira Braga. Acesso em: 11 abr. 2025.',
                    '[2] Viabilidade económica de medidas... Repositório ULisboa. Acesso em: 11 abr. 2025.',
                    '[3] Pequenas atitudes podem gerar economia... Fabasa. Acesso em: 11 abr. 2025.'
                ], 'Olá, tenho interesse em reduzir custos com energia elétrica no condomínio e quero falar com especialista.', '#economia #condominial')
            },
            {
                id: 'economia-empresa',
                iconClass: 'fas fa-briefcase',
                title: 'Empresa',
                description: 'Reduza seus custos operacionais, aumentando a margem de lucro.',
                detail: createCategoryDetail('ec-emp', 'Empresa - Economia Imediata', 'Aumente sua margem de lucro e a competitividade do seu negócio.', 'Viabilizado pela redução dos seus custos operacionais com energia elétrica, desde o início da operação do sistema solar.', [
                    {
                        text: '"Empresas reduzem custos operacionais com energia em até 95%..."',
                        link: 'https://solalux.com.br/sistema-fotovoltaico-economia-energia/'
                    },
                    {
                        text: '"Energia solar é uma estratégia sustentável e econômica para empresas..."',
                        link: 'https://www.reenergisa.com.br/blog/fontes-renovaveis/conheca-os-muitos-beneficios-da-energia-solar-para-residencias-e-empresas'
                    },
                    {
                        text: '"O investimento em projetos de energia solar... decisão inteligente e estratégica..."',
                        link: 'https://elysia.com.br/energia-solar-empresa-competitividade-economia/'
                    }
                ], [
                    '[1] Sistema Fotovoltaico: Como Economizar Até 95%... Solalux. Acesso em: 11 abr. 2025.',
                    '[2] Conheça os muitos benefícios da Energia Solar... Reenergisa. Acesso em: 11 abr. 2025.',
                    '[3] EMPRESA com energia solar: aumento de competitividade... Elysia. Acesso em: 11 abr. 2025.'
                ], 'Olá, tenho interesse em reduzir custos com energia elétrica na empresa e quero falar com especialista.', '#economia #empresarial')
            }
        ]
    },
    // 2. Sustentabilidade
    {
        id: 'sustentabilidade',
        title: 'Sustentabilidade',
        iconClass: 'fas fa-leaf',
        description: 'Energia limpa e renovável que reduz significativamente sua pegada de carbono.',
        modalTitle: 'Sustentabilidade com Energia Solar',
        contactMessageBase: 'Olá, tenho interesse em reduzir a pegada de carbono, em energia limpa e renovável e quero falar com especialista.',
        contactTagBase: '#sustentabilidade',
        categories: [
            {
                id: 'sustentabilidade-residencia',
                iconClass: 'fa-solid fa-house',
                title: 'Residência',
                description: 'Contribua ativamente para um futuro mais verde, reduzindo sua pegada de carbono.',
                detail: createCategoryDetail('sus-res', 'Residência - Sustentabilidade', 'Contribua ativamente para um futuro mais verde', 'Utilizando uma fonte de energia limpa e renovável, reduzindo sua pegada de carbono e o impacto ambiental.', [
                    {
                        text: '"A escolha de fontes renováveis... pode ajudar os consumidores a reduzir a sua pegada de carbono"',
                        link: 'https://www.publituris.pt/opiniao/como-a-energia-renovavel-pode-ajudar-a-reduzir-a-pegada-de-carbono-das-viagens-em-portugal'
                    },
                    {
                        text: '"O objetivo da energia limpa é reduzir ou eliminar a pegada de carbono..."',
                        link: 'https://fia.com.br/blog/energia-limpa/'
                    },
                    {
                        text: '"A principal vantagem da energia limpa é a sua capacidade de reduzir significativamente as emissões..."',
                        link: 'https://origoenergia.com.br/blog/energia/energia-limpa-vantagens-e-desvantagens'
                    }
                ], [
                    '[1] Como a energia renovável pode ajudar... Publituris. Acesso em: 12 abr. 2025.',
                    '[2] Energia limpa: o que é, vantagens... FIA. Acesso em: 12 abr. 2025.',
                    '[3] Energia Limpa: veja quais as vantagens... Origo Energia. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse em reduzir a pegada de carbono, em energia limpa e renovável na residência e quero falar com especialista.', '#sustentabilidade #residencial')
            },
            {
                id: 'sustentabilidade-condominio',
                iconClass: 'fas fa-building',
                title: 'Condomínio',
                description: 'Demonstre o compromisso com a sustentabilidade em larga escala.',
                detail: createCategoryDetail('sus-con', 'Condomínio - Sustentabilidade', 'Compromisso com sustentabilidade em larga escala', 'Tornando-se um exemplo de responsabilidade ambiental para toda a comunidade.', [
                    {
                        text: '"Transição para energias limpas substituem combustíveis fósseis poluentes..."',
                        link: 'https://www.iberdrola.com/sustentabilidade/pegada-carbono'
                    },
                    {
                        text: '"O fornecimento de energia renovável reduz significativamente a emissão de gases..."',
                        link: 'https://repositorio.ufersa.edu.br/server/api/core/bitstreams/102331ca-d5d5-45b1-a991-c215f4f4d590/content'
                    },
                    {
                        text: '"Para alcançar um futuro sustentável, devemos priorizar fontes renováveis..."',
                        link: 'https://www.linkedin.com/pulse/o-futuro-da-gera%C3%A7%C3%A3o-de-energia-reduzindo-pegada-aline-marchetti/'
                    }
                ], [
                    '[1] O que é a pegada de carbono?... Iberdrola. Acesso em: 12 abr. 2025.',
                    '[2] Energia fotovoltaica e suas contribuições... Repositório UFERSA. Acesso em: 12 abr. 2025.',
                    '[3] O Futuro da Geração de Energia... LinkedIn. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse em reduzir a pegada de carbono, em energia limpa e renovável no condomínio e quero falar com especialista.', '#sustentabilidade #condominial')
            },
            {
                id: 'sustentabilidade-empresa',
                iconClass: 'fas fa-briefcase',
                title: 'Empresa',
                description: 'Fortaleça a imagem da sua marca como ecologicamente responsável.',
                detail: createCategoryDetail('sus-emp', 'Empresa - Sustentabilidade', 'Fortaleça sua imagem como empresa ecologicamente responsável', 'Atraindo clientes e investidores conscientes e alinhando-se com as práticas ESG.', [
                    {
                        text: '"A biomassa e o biogás são fontes de energia renovável que podem desempenhar um papel fundamental..."',
                        link: 'https://www.ecogenbrasil.com.br/o-que-e-pegada-de-carbono/'
                    },
                    {
                        text: '"A energia solar tem emergido como uma solução sustentável chave para o agronegócio..."',
                        link: 'https://mayaenergy.com.br/reduzindo-a-pegada-de-carbono-com-energia-solar/'
                    },
                    {
                        text: '"Energia renovável com baixa emissão de carbono é essencial para alinhar práticas empresariais..."',
                        link: 'https://www.kas.de/documents/265553/265602/7_file_storage_file_15610_5.pdf/7a71f052-c16e-6f6f-069f-a7849912a97d'
                    }
                ], [
                    '[1] O que é pegada de carbono e como reduzir... Ecogen Brasil. Acesso em: 12 abr. 2025.',
                    '[2] Reduzindo a Pegada de Carbono com Energia Solar. Maya Energy. Acesso em: 12 abr. 2025.',
                    '[3] Energia renovável com baixa emissão de carbono. KAS. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse em reduzir a pegada de carbono, em energia limpa e renovável na empresa e quero falar com especialista.', '#sustentabilidade #empresarial')
            }
        ]
    },
    // 3. Valorização Imobiliária
    {
        id: 'valorizacao',
        title: 'Valorização Imobiliária',
        iconClass: 'fas fa-chart-line',
        description: 'Imóveis com sistemas solares são avaliados em até 4% acima do valor de mercado.',
        modalTitle: 'Valorização Imobiliária com Energia Solar',
        contactMessageBase: 'Olá, tenho interesse na valorização do imóvel e quero falar com especialista.',
        contactTagBase: '#valorizaçãoImobiliária',
        categories: [
            {
                id: 'valorizacao-residencia',
                iconClass: 'fa-solid fa-house',
                title: 'Residência',
                description: 'Aumente o valor de mercado do seu imóvel, tornando-o mais atrativo.',
                detail: createCategoryDetail('val-res', 'Residência - Valorização Imobiliária', 'Aumente o valor de mercado do seu imóvel', 'Casas com sistemas de energia solar instalados são mais atrativas para compradores e podem ser vendidas por um preço mais alto.', [
                    {
                        text: '"A energia solar valoriza imóveis... A valorização pode chegar a 30%..."',
                        link: 'https://grupoe4.com.br/energia-solar-valoriza-o-imovel/'
                    },
                    {
                        text: '"Estudos mostram que... um imóvel pode valorizar até 10%..."',
                        link: 'https://g1.globo.com/sc/santa-catarina/especial-publicitario/top-sun/top-sun-energia-solar/noticia/2023/03/24/valorize-seu-imovel-em-ate-10percent-com-energia-solar.ghtml'
                    },
                    {
                        text: '"Um imóvel com energia solar se valoriza... entre 3% e 6%..."',
                        link: 'https://blog.solarpowerenergy.com.br/imoveis-com-energia-solar/'
                    }
                ], [
                    '[1] Energia solar valoriza o imóvel?. Grupo E4. Acesso em: 12 abr. 2025.',
                    '[2] Valorize seu imóvel em até 10%... G1. Acesso em: 12 abr. 2025.',
                    '[3] Você sabia que os imóveis com energia solar... Solar Power Energy Blog. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na valorização do imóvel da residência e quero falar com especialista.', '#valorizaçãoImobiliária #residencial')
            },
            {
                id: 'valorizacao-condominio',
                iconClass: 'fas fa-building',
                title: 'Condomínio',
                description: 'Valorize todas as unidades, tornando-o mais desejável.',
                detail: createCategoryDetail('val-con', 'Condomínio - Valorização Imobiliária', 'Valorize todas as unidades do condomínio', 'Tornando-o mais desejável para potenciais compradores e inquilinos, além de reduzir os custos para os moradores atuais.', [
                    {
                        text: '"Investir em energia solar não só reduz custos... mas também aumenta significativamente a valorização..."',
                        link: 'https://solarvale.com.br/o-impacto-da-energia-solar-na-valorizacao-de-imoveis/'
                    },
                    {
                        text: '"A energia solar fotovoltaica pode ter um impacto significativo na valorização imobiliária..."',
                        link: 'https://imperiosolar.com.br/valorizacao-imobiliaria-o-impacto-da-energia-solar-fotovoltaica/'
                    },
                    {
                        text: '"É crescente a demanda de mercado que visa a aquisição de energia solar... para valorização de imóveis... condomínios."',
                        link: 'https://g1.globo.com/sp/presidente-prudente-regiao/especial-publicitario/solar-power-photovoltaic/noticia/2021/05/14/a-solar-power-ensina-como-valorizar-o-seu-imovel-em-ate-30percent-com-energia-solar.ghtml'
                    }
                ], [
                    '[4] O impacto da energia solar na valorização... Solar Vale. Acesso em: 12 abr. 2025.',
                    '[5] Valorização imobiliária, o impacto da energia solar... Imperio Solar. Acesso em: 12 abr. 2025.',
                    '[6] A Solar Power ensina como valorizar o seu imóvel... G1. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na valorização do imóvel do condomínio e quero falar com especialista.', '#valorizaçãoImobiliária #condominial')
            },
            {
                id: 'valorizacao-empresa',
                iconClass: 'fas fa-briefcase',
                title: 'Empresa',
                description: 'Seu imóvel comercial se torna um ativo mais valioso e competitivo.',
                detail: createCategoryDetail('val-emp', 'Empresa - Valorização Imobiliária', 'Seu imóvel comercial com energia solar', 'Torna-se um ativo mais valioso e competitivo no mercado imobiliário, além de reduzir seus custos operacionais.', [
                    {
                        text: '"Imóveis com energia solar oferecem economia de longo prazo, atraindo compradores..."',
                        link: 'https://acssolar.com.br/o-impacto-da-energia-solar-na-valorizacao-de-imoveis-na-regiao-dos-lagos/'
                    },
                    {
                        text: '"Investir em energia solar pode aumentar o valor do seu imóvel em até 10%..."',
                        link: 'https://www.linkedin.com/pulse/energia-solar-o-potencial-de-valoriza%C3%A7%C3%A3o-imobili%C3%A1ria-e-nelson-assis-0apef/?originalSubdomain=pt'
                    },
                    {
                        text: '"A energia solar é uma excelente opção... valoriza o patrimônio."',
                        link: 'https://meufinanciamentosolar.com.br/dicas/para-voce/valorizacao-do-imovel-energia-solar'
                    }
                ], [
                    '[7] O Impacto da Energia Solar na Valorização... ACS Solar. Acesso em: 12 abr. 2025.',
                    '[8] Energia Solar: O Potencial de Valorização... LinkedIn. Acesso em: 12 abr. 2025.',
                    '[9] Valorização do imóvel com energia solar... Meu Financiamento Solar. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na valorização do imóvel da empresa e quero falar com especialista.', '#valorizaçãoImobiliária #empresarial')
            }
        ]
    },
    // 4. Baixa Manutenção
    {
        id: 'manutencao',
        title: 'Baixa Manutenção',
        iconClass: 'fas fa-tools',
        description: 'Sistemas duráveis com garantia de até 25 anos e mínima necessidade de manutenção.',
        modalTitle: 'Baixa Manutenção do Sistema de Energia Solar',
        contactMessageBase: 'Olá, tenho interesse na baixa manutenção do sistema de energia solar e quero falar com especialista.',
        contactTagBase: '#baixaManutenção',
        categories: [
            {
                id: 'manutencao-residencia',
                iconClass: 'fa-solid fa-house',
                title: 'Residência',
                description: 'Sistemas requerem pouca manutenção, geralmente apenas limpezas periódicas.',
                detail: createCategoryDetail('man-res', 'Residência - Baixa Manutenção', 'Sistemas solares de baixa manutenção', 'Os sistemas solares requerem pouca manutenção, geralmente apenas limpezas periódicas dos painéis para garantir a máxima eficiência. Desfrute de energia limpa sem grandes preocupações.', [
                    {
                        text: '"A manutenção inclui principalmente a limpeza regular dos módulos..."',
                        link: 'https://energiasroraima.com.br/wp-content/uploads/2024/03/Cartilha-Manutencao-e-Operacao.pdf'
                    },
                    {
                        text: '"A sujeira depositada sobre as células... pode reduzir a efetividade..."',
                        link: 'https://www.solarvolt.com.br/blog/manutencao-sistemas-fotovoltaicos/'
                    },
                    {
                        text: '"Embora os sistemas fotovoltaicos sejam projetados para operar com baixa necessidade de manutenção..."',
                        link: 'https://sunergia.com.br/blog/instalacao-manutencao-e-suporte-em-energia-solar-fotovoltaica/'
                    }
                ], [
                    '[1] Energia solar fotovoltaica... Cartilha Manutenção [PDF]. Energias Roraima. Acesso em: 12 abr. 2025.',
                    '[2] Manutenção de sistemas fotovoltaicos... Solar Volt Blog. Acesso em: 12 abr. 2025.',
                    '[3] Instalação, manutenção e suporte... Sunergia Blog. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na baixa manutenção do sistema de energia solar na residência e quero falar com especialista.', '#baixaManutenção #residencial')
            },
            {
                id: 'manutencao-condominio',
                iconClass: 'fas fa-building',
                title: 'Condomínio',
                description: 'Custos e trabalho de conservação mínimos, otimizando recursos a longo prazo.',
                detail: createCategoryDetail('man-con', 'Condomínio - Baixa Manutenção', 'Sistemas duráveis e econômicos', 'Com sistemas duráveis e de baixa manutenção, os custos e o trabalho de conservação são mínimos, otimizando os recursos do condomínio a longo prazo.', [
                    {
                        text: '"A preocupação com a manutenção vem com a evolução do sistema..."',
                        link: 'https://pleiade.uniamerica.br/index.php/bibliotecadigital/article/download/556/665/1713'
                    },
                    {
                        text: '"A baixa demanda por manutenção é mais um fator que torna a geração de energia solar uma excelente opção"',
                        link: 'https://energiasirius.com/manutencao-energia-solar/'
                    },
                    {
                        text: '"Exige pouca manutenção em suas centrais de produção"',
                        link: 'https://energiasirius.com/manutencao-energia-solar/'
                    }
                ], [
                    '[4] A importância dos cuidados técnicos... [PDF]. Plêiade Uniamerica. Acesso em: 12 abr. 2025.',
                    '[5] Manutenção em energia solar... Energia Sirius. Acesso em: 12 abr. 2025.',
                    '[6] Energia solar: como funciona... Energia Sirius. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na baixa manutenção do sistema de energia solar no condomínio e quero falar com especialista.', '#baixaManutenção #condominial')
            },
            {
                id: 'manutencao-empresa',
                iconClass: 'fas fa-briefcase',
                title: 'Empresa',
                description: 'Sistemas projetados para durar, permitindo foco no core business.',
                detail: createCategoryDetail('man-emp', 'Empresa - Baixa Manutenção', 'Foco no core business', 'Sistemas solares são projetados para durar e exigem pouca intervenção, permitindo que sua empresa foque no core business sem se preocupar com manutenções constantes.', [
                    {
                        text: '"As normas estabelecem diretrizes para garantir a segurança durante todas as fases..."',
                        link: 'https://www.portalsolar.com.br/norma-tecnica-energia-solar'
                    },
                    {
                        text: '"Sistemas fotovoltaicos integrados... como uma fonte renovável..."',
                        link: 'https://pt.scribd.com/document/389444993/Citacoes-Parafrases-e-Citacao-Da-Citacao'
                    },
                    {
                        text: '"A produção de energia solar é uma solução durável e de baixa manutenção..."',
                        link: 'https://teses.usp.br/teses/disponiveis/102/102131/tde-31082018-154505/publico/TeseCorrigidaRosileneRegolao.pdf'
                    }
                ], [
                    '[7] Norma técnica de instalação... Portal Solar. Acesso em: 12 abr. 2025.',
                    '[8] Citações Paráfrases e Citação Da Citação [PDF]. Scribd. Acesso em: 12 abr. 2025.',
                    '[9] Análise integrada de desempenho... [PDF] Teses USP. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na baixa manutenção do sistema de energia solar na empresa e quero falar com especialista.', '#baixaManutenção #empresarial')
            }
        ]
    },
    // 5. Proteção contra Aumentos
    {
        id: 'protecao',
        title: 'Proteção contra Aumentos',
        iconClass: 'fas fa-shield-alt',
        description: 'Fique imune aos constantes aumentos na tarifa de energia elétrica.',
        modalTitle: 'Proteção contra Aumentos na Conta de Luz',
        contactMessageBase: 'Olá, tenho interesse na proteção contra aumentos no custo da energia e quero falar com especialista.',
        contactTagBase: '#proteçãoContraAumento',
        categories: [
            {
                id: 'protecao-residencia',
                iconClass: 'fa-solid fa-house',
                title: 'Residência',
                description: 'Proteja seu orçamento familiar contra elevações nas tarifas.',
                detail: createCategoryDetail('pro-res', 'Residência - Proteção contra Aumentos', 'Proteção contra aumentos na conta de luz', 'Proteja seu orçamento familiar contra as constantes elevações nas tarifas de energia elétrica. Com a energia solar, você tem mais controle sobre seus gastos.', [
                    {
                        text: '"A energia solar protege o consumidor dos aumentos na conta de luz..."',
                        link: 'https://www.portalsolar.com.br/energia-solar-vale-a-pena'
                    },
                    {
                        text: '"A energia solar é uma excelente alternativa para diminuir seus gastos..."',
                        link: 'https://cordeiroenergia.com.br/entenda-a-relacao-entre-conta-de-luz-e-energia-solar/'
                    },
                    {
                        text: '"O papo de hoje é com você que quer aprender tudo sobre inflação energética..."',
                        link: 'https://insolenergia.com.br/tecnologia/como-se-proteger-dos-aumentos-na-conta-de-luz/'
                    }
                ], [
                    '[1] Energia Solar Fotovoltaica vale a pena?. Portal Solar. Acesso em: 12 abr. 2025.',
                    '[2] Entenda a relação entre conta de luz... Cordeiro Energia. Acesso em: 12 abr. 2025.',
                    '[3] Como se proteger dos aumentos... Insol Energia. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na proteção contra aumentos no custo da energia consumida na residência e quero falar com especialista.', '#proteçãoContraAumento #residencial')
            },
            {
                id: 'protecao-condominio',
                iconClass: 'fas fa-building',
                title: 'Condomínio',
                description: 'Reduza a vulnerabilidade do condomínio aos aumentos tarifários.',
                detail: createCategoryDetail('pro-con', 'Condomínio - Proteção contra Aumentos', 'Redução de vulnerabilidade tarifária', 'Reduza a vulnerabilidade do condomínio aos aumentos tarifários, garantindo uma despesa mais estável e previsível para todos os moradores.', [
                    {
                        text: '"A Lei nº 14.300/2022 institui o marco legal da microgeração..."',
                        link: 'https://www.gov.br/aneel/pt-br/acesso-a-informacao/perguntas-frequentes/micro-e-minigeracao-distribuida'
                    },
                    {
                        text: '"A energia solar fotovoltaica converte a luz solar em eletricidade sem emissões..."',
                        link: 'https://www.semace.ce.gov.br/wp-content/uploads/sites/46/2020/09/RIMA-Usina-Solar-Geradora-de-Energia-SGA-Ltda-Sao-Goncalo-Setembro-2020.pdf'
                    },
                    {
                        text: '"A taxação do Sol afeta o retorno financeiro... mas sistemas existentes permanecem protegidos..."',
                        link: 'https://solardospomares.com.br/taxacao-do-sol-e-seu-impacto-economico/'
                    }
                ], [
                    '[4] Micro e Minigeração Distribuída. Gov.br ANEEL. Acesso em: 12 abr. 2025.',
                    '[5] RELATÓRIO DE IMPACTO AMBIENTAL [PDF]. SEMACE CE. Acesso em: 12 abr. 2025.',
                    '[6] O Impacto da Taxação do Sol... Solar dos Pomares. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na proteção contra aumentos no custo da energia consumida no condomínio e quero falar com especialista.', '#proteçãoContraAumento #condominial')
            },
            {
                id: 'protecao-empresa',
                iconClass: 'fas fa-briefcase',
                title: 'Empresa',
                description: 'Minimize o impacto das flutuações de custos de energia no seu negócio.',
                detail: createCategoryDetail('pro-emp', 'Empresa - Proteção contra Aumentos', 'Planejamento financeiro seguro', 'Minimize o impacto das flutuações e aumentos nos custos de energia, tornando seu planejamento financeiro mais seguro e competitivo a longo prazo.', [
                    {
                        text: '"A energia solar protege o consumidor dos aumentos na conta de luz..."',
                        link: 'https://www.portalsolar.com.br/energia-solar-vale-a-pena'
                    },
                    {
                        text: '"A taxação do Sol impacta o retorno financeiro, mas empresas com sistemas instalados antes..."',
                        link: 'https://solardospomares.com.br/taxacao-do-sol-e-seu-impacto-economico/'
                    },
                    {
                        text: '"A microgeração distribuída permite que empresas gerem própria energia..."',
                        link: 'https://www.gov.br/aneel/pt-br/acesso-a-informacao/perguntas-frequentes/micro-e-minigeracao-distribuida'
                    }
                ], [
                    '[7] Energia Solar Fotovoltaica vale a pena?. Portal Solar. Acesso em: 12 abr. 2025.',
                    '[8] O Impacto da Taxação do Sol... Solar dos Pomares. Acesso em: 12 abr. 2025.',
                    '[9] Micro e Minigeração Distribuída. Gov.br ANEEL. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse na proteção contra aumentos no custo da energia consumida na empresa e quero falar com especialista.', '#proteçãoContraAumento #empresarial')
            }
        ]
    },
    // 6. Financiamento Facilitado
    {
        id: 'financiamento',
        title: 'Financiamento Facilitado',
        iconClass: 'fas fa-file-invoice-dollar',
        description: 'Parcelas que cabem no seu bolso, muitas vezes menores que sua atual conta de luz.',
        modalTitle: 'Financiamento Facilitado para Energia Solar',
        contactMessageBase: 'Olá, tenho interesse no financiamento facilitado e quero falar com especialista.',
        contactTagBase: '#financiamentoFacilitado',
        categories: [
            {
                id: 'financiamento-residencia',
                iconClass: 'fa-solid fa-house',
                title: 'Residência',
                description: 'Aproveite diversas opções com condições facilitadas e taxas atrativas.',
                detail: createCategoryDetail('fin-res', 'Residência - Financiamento Facilitado', 'Financiamento facilitado para energia solar', 'Aproveite diversas opções de financiamento com condições facilitadas e taxas atrativas para tornar a energia solar acessível para o seu lar.', [
                    {
                        text: '"O financiamento para energia solar fotovoltaica amplia o acesso a sistemas residenciais..."',
                        link: 'https://cmsarquivos.febraban.org.br/Arquivos/documentos/PDF/FINAL_L08_energia_solar_ONLINE.pdf'
                    },
                    {
                        text: '"Incentivos fiscais e linhas de crédito específicas tornam a energia solar uma opção financeiramente viável..."',
                        link: 'https://www.portalsolar.com.br/energia-solar-no-brasil.html'
                    },
                    {
                        text: '"O setor solar brasileiro conta com programas de financiamento que reduzem custos iniciais..."',
                        link: 'https://cresesb.cepel.br/publicacoes/download/Manual_de_Engenharia_FV_2014.pdf'
                    }
                ], [
                    '[1] FINANCIAMENTO PARA ENERGIA SOLAR... [PDF]. Febraban. Acesso em: 12 abr. 2025.',
                    '[2] Energia Solar no Brasil... Portal Solar. Acesso em: 12 abr. 2025.',
                    '[3] Manual de Engenharia para Sistemas... Cresesb/CEPEL. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse no financiamento facilitado para residência e quero falar com especialista.', '#financiamentoFacilitado #residencial')
            },
            {
                id: 'financiamento-condominio',
                iconClass: 'fas fa-building',
                title: 'Condomínio',
                description: 'Explore linhas de crédito e financiamentos especiais para condomínios.',
                detail: createCategoryDetail('fin-con', 'Condomínio - Financiamento Facilitado', 'Financiamento coletivo e sustentável', 'Explore linhas de crédito e financiamentos especiais para condomínios, tornando o investimento em energia solar viável e com retorno garantido para todos.', [
                    {
                        text: '"Condomínios podem acessar linhas de financiamento coletivo..."',
                        link: 'https://cmsarquivos.febraban.org.br/Arquivos/documentos/PDF/FINAL_L08_energia_solar_ONLINE.pdf'
                    },
                    {
                        text: '"A regulamentação brasileira incentiva a geração distribuída, incluindo condomínios..."',
                        link: 'https://cresesb.cepel.br/publicacoes/download/Manual_de_Engenharia_FV_2014.pdf'
                    },
                    {
                        text: '"A energia solar é uma das fontes renováveis com maior crescimento... impulsionada por financiamentos..."',
                        link: 'https://www.absolar.org.br/noticia/energia-solar-e-a-2a-maior-fonte-energetica-do-pais-como-ter-em-casa/'
                    }
                ], [
                    '[1] FINANCIAMENTO PARA ENERGIA SOLAR... [PDF]. Febraban. Acesso em: 12 abr. 2025.',
                    '[3] Manual de Engenharia para Sistemas... Cresesb/CEPEL. Acesso em: 12 abr. 2025.',
                    '[4] Energia solar é a 2ª maior fonte... Absolar. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse no financiamento facilitado para condomínio e quero falar com especialista.', '#financiamentoFacilitado #condominial')
            },
            {
                id: 'financiamento-empresa',
                iconClass: 'fas fa-briefcase',
                title: 'Empresa',
                description: 'Descubra linhas de financiamento e incentivos fiscais disponíveis.',
                detail: createCategoryDetail('fin-emp', 'Empresa - Financiamento Facilitado', 'Incentivos fiscais e linhas de crédito', 'Descubra as diversas linhas de financiamento e incentivos fiscais disponíveis para empresas que investem em energia solar, facilitando a implementação do sistema.', [
                    {
                        text: '"Empresas têm acesso a incentivos fiscais e linhas de crédito específicas..."',
                        link: 'https://www.portalsolar.com.br/energia-solar-no-brasil.html'
                    },
                    {
                        text: '"O marco legal da microgeração distribuída... facilita o financiamento..."',
                        link: 'https://cresesb.cepel.br/publicacoes/download/Manual_de_Engenharia_FV_2014.pdf'
                    },
                    {
                        text: '"Financiamentos para energia solar são estratégicos para empresas..."',
                        link: 'https://cmsarquivos.febraban.org.br/Arquivos/documentos/PDF/FINAL_L08_energia_solar_ONLINE.pdf'
                    }
                ], [
                    '[2] Energia Solar no Brasil... Portal Solar. Acesso em: 12 abr. 2025.',
                    '[3] Manual de Engenharia para Sistemas... Cresesb/CEPEL. Acesso em: 12 abr. 2025.',
                    '[1] FINANCIAMENTO PARA ENERGIA SOLAR... [PDF]. Febraban. Acesso em: 12 abr. 2025.'
                ], 'Olá, tenho interesse no financiamento facilitado para empresa e quero falar com especialista.', '#financiamentoFacilitado #empresarial')
            }
        ]
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "benefitCard": "benefits_section_ds-module__WNjqMq__benefitCard",
  "benefitDescription": "benefits_section_ds-module__WNjqMq__benefitDescription",
  "benefitIcon": "benefits_section_ds-module__WNjqMq__benefitIcon",
  "benefitTitle": "benefits_section_ds-module__WNjqMq__benefitTitle",
  "categoryCard": "benefits_section_ds-module__WNjqMq__categoryCard",
  "categoryDescription": "benefits_section_ds-module__WNjqMq__categoryDescription",
  "categoryIcon": "benefits_section_ds-module__WNjqMq__categoryIcon",
  "citationLink": "benefits_section_ds-module__WNjqMq__citationLink",
  "citations": "benefits_section_ds-module__WNjqMq__citations",
  "detailModalBody": "benefits_section_ds-module__WNjqMq__detailModalBody",
  "detailText": "benefits_section_ds-module__WNjqMq__detailText",
  "detailTitle": "benefits_section_ds-module__WNjqMq__detailTitle",
  "modalDialog": "benefits_section_ds-module__WNjqMq__modalDialog",
  "modalHeader": "benefits_section_ds-module__WNjqMq__modalHeader",
  "modalTitle": "benefits_section_ds-module__WNjqMq__modalTitle",
  "references": "benefits_section_ds-module__WNjqMq__references",
  "sectionBenefits": "benefits_section_ds-module__WNjqMq__sectionBenefits",
  "sectionSubtitle": "benefits_section_ds-module__WNjqMq__sectionSubtitle",
  "sectionTitle": "benefits_section_ds-module__WNjqMq__sectionTitle",
});
}),
"[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js [app-client] (ecmascript)"); // Confirme o caminho
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/benefits_data_ds.js [app-client] (ecmascript)"); // Importa os dados estruturados
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.module.css [app-client] (css module)"); // Importar CSS Module
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
// Componente para o Card de Benefício Principal
const BenefitCard = ({ benefit, onClick })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
        md: 6,
        lg: 4,
        className: "mb-4",
        children: [
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].benefitCard} h-100`,
                onClick: ()=>onClick(benefit),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Body, {
                    className: "text-center p-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                            iconClass: benefit.iconClass,
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].benefitIcon,
                            "aria-label": benefit.description
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 15,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Title, {
                            as: "h3",
                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].benefitTitle} fw-bold`,
                            children: benefit.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 16,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Text, {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].benefitDescription,
                            children: benefit.description
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 17,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                    lineNumber: 14,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                lineNumber: 13,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
        lineNumber: 12,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
_c = BenefitCard;
// Componente para o Card de Categoria dentro do Modal
const CategoryCard = ({ category, onClick })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryCard} h-100`,
            onClick: ()=>onClick(category.detail),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Body, {
                className: "d-flex flex-column text-center p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                        iconClass: category.iconClass,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryIcon,
                        "aria-label": category.description
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 28,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Title, {
                        as: "h4",
                        className: "fw-bold",
                        children: category.title
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 29,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Text, {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].categoryDescription} flex-grow-1`,
                        children: category.description
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 30,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                lineNumber: 27,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
            lineNumber: 26,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
_c1 = CategoryCard;
function BenefitsSectionDS() {
    _s();
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Guarda os dados do benefício ou do detalhe da categoria a ser exibido
    const [modalContent, setModalContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Controla se o modal está exibindo a lista de categorias (false) ou o detalhe final (true)
    const [isDetailView, setIsDetailView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Abre o modal no nível das categorias
    const handleShowBenefitModal = (benefitData)=>{
        setModalContent(benefitData);
        setIsDetailView(false); // Mostra as categorias primeiro
        setShowModal(true);
    };
    // Mostra o detalhe final (citações, etc.) dentro do mesmo modal
    const handleShowDetailView = (detailData)=>{
        setModalContent(detailData); // Agora o modalContent guarda os detalhes
        setIsDetailView(true); // Muda a visualização para detalhes
    };
    // Fecha o modal e reseta tudo
    const handleCloseModal = ()=>{
        setShowModal(false);
        setIsDetailView(false);
        // Pequeno delay para não ver o conteúdo antigo sumindo
        setTimeout(()=>setModalContent(null), 300);
    };
    // ---- Funções auxiliares para renderizar conteúdo do modal ----
    const renderCategoryView = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                        xs: 1,
                        sm: 2,
                        md: 3,
                        className: "g-3",
                        children: modalContent?.categories?.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryCard, {
                                category: category,
                                onClick: handleShowDetailView
                            }, category.id, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                lineNumber: 73,
                                columnNumber: 25
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 71,
                        columnNumber: 17
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                    lineNumber: 70,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                    className: "justify-content-center justify-content-md-end",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        textClassButton: `btn btn-outline-custom btn-lg ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalFooterButton}`,
                        textMessage: modalContent?.contactMessageBase || 'Olá, quero falar com especialista sobre os benefícios.',
                        textTag: modalContent?.contactTagBase || '#devSolar #beneficios'
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 82,
                        columnNumber: 17
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                    lineNumber: 81,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true);
    const renderDetailView = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].detailModalBody,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].detailTitle,
                            children: modalContent?.detailTitle
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 94,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].detailText,
                            children: modalContent?.text
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 95,
                            columnNumber: 17
                        }, this),
                        modalContent?.citations?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].citations,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                    children: "Citações"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                    lineNumber: 99,
                                    columnNumber: 25
                                }, this),
                                modalContent.citations.map((cite)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: [
                                                    "Citação ",
                                                    cite.id.split('-').pop(),
                                                    ":"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                                lineNumber: 102,
                                                columnNumber: 33
                                            }, this),
                                            " ",
                                            cite.text,
                                            cite.link && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: cite.link,
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].citationLink,
                                                children: [
                                                    " [",
                                                    cite.id.split('-').pop(),
                                                    "]"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                                lineNumber: 103,
                                                columnNumber: 47
                                            }, this)
                                        ]
                                    }, cite.id, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                        lineNumber: 101,
                                        columnNumber: 29
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 98,
                            columnNumber: 21
                        }, this),
                        modalContent?.references?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].references,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                    children: "Referências"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                    lineNumber: 111,
                                    columnNumber: 25
                                }, this),
                                modalContent.references.map((ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "[",
                                            ref.id.split('-').pop(),
                                            "] ",
                                            ref.text
                                        ]
                                    }, ref.id, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                        lineNumber: 113,
                                        columnNumber: 29
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 110,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                    lineNumber: 93,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                    className: "justify-content-center justify-content-md-end",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: handleCloseModal,
                        textClassButton: `btn btn-outline-custom btn-lg ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalFooterButton}`,
                        textMessage: modalContent?.contactMessage || 'Olá, quero falar com especialista sobre este benefício.',
                        textTag: modalContent?.contactTag || '#devSolar #beneficioDetalhe'
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 119,
                        columnNumber: 17
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                    lineNumber: 118,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "beneficios",
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionBenefits} section`,
                "aria-labelledby": "benefits-title",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "benefits-title",
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold`,
                                    children: "Por que escolher energia solar?"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                    lineNumber: 134,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} lead`,
                                    children: "Descubra os benefícios que milhares de clientes já aproveitam"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                    lineNumber: 135,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 133,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            className: "g-4 justify-content-center",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["benefitsData"].map((benefit)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BenefitCard, {
                                    benefit: benefit,
                                    onClick: handleShowBenefitModal
                                }, benefit.id, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                                    lineNumber: 140,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 138,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                    lineNumber: 132,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                lineNumber: 131,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                show: showModal,
                onHide: handleCloseModal,
                size: "lg",
                centered: true,
                dialogClassName: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalDialog,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                        closeButton: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalHeader,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$benefits_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalTitle,
                            children: isDetailView ? modalContent?.title : modalContent?.modalTitle
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                            lineNumber: 153,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                        lineNumber: 152,
                        columnNumber: 17
                    }, this),
                    isDetailView ? renderDetailView() : renderCategoryView()
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/benefits_section_ds.js",
                lineNumber: 151,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
_s(BenefitsSectionDS, "d6+PZieON8lJ+FuqP5frAtNSyHM=");
_c2 = BenefitsSectionDS;
const __TURBOPACK__default__export__ = BenefitsSectionDS;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "BenefitCard");
__turbopack_context__.k.register(_c1, "CategoryCard");
__turbopack_context__.k.register(_c2, "BenefitsSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/contact_data_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "contactInfoData",
    ()=>contactInfoData,
    "socialLinksData",
    ()=>socialLinksData
]);
'use client';
const contactInfoData = [
    {
        id: 'cnpj',
        iconClass: 'fas fa-handshake',
        title: 'DEV Eficiência Energética Ltda.',
        text: 'CNPJ: 53.538.425/0001-15'
    },
    {
        id: 'address',
        iconClass: 'fas fa-location-dot',
        title: 'Endereço',
        text: 'Av. Jambeiro, 474 Loja C - Vila Valqueire - Rio de Janeiro, RJ.'
    },
    {
        id: 'phone',
        iconClass: 'fas fa-phone-alt',
        title: 'Telefone',
        text: '(21) 99967-7722',
        link: 'tel:+5521999677722'
    },
    {
        id: 'email',
        iconClass: 'fas fa-envelope',
        title: 'Email',
        text: 'comercial@devsolar.com.br',
        link: 'mailto:comercial@devsolar.com.br'
    }
];
const socialLinksData = [
    {
        id: 'facebook',
        name: 'Facebook',
        url: 'https://www.facebook.com/profile.php?id=61562778810789',
        iconClass: 'fab fa-facebook-f',
        accessibility: 'Acesse nossa página no Facebook'
    },
    {
        id: 'instagram',
        name: 'Instagram',
        url: 'https://www.instagram.com/devsolar_/',
        iconClass: 'fab fa-instagram',
        accessibility: 'Acesse nosso perfil no Instagram'
    },
    {
        id: 'linkedin',
        name: 'LinkedIn',
        url: 'https://www.linkedin.com/company/dev-solar-efici%C3%AAncia-energ%C3%A9tica/about/',
        iconClass: 'fab fa-linkedin-in',
        accessibility: 'Acesse nossa página no LinkedIn'
    },
    // { id: 'youtube', name: 'YouTube', url: '#', iconClass: 'fab fa-youtube', accessibility: 'Acesse nosso canal no YouTube' }, // Exemplo de link interno ou placeholder
    // { id: 'youtube', name: 'YouTube', url: 'https://youtube.com/', iconClass: 'fab fa-youtube', accessibility: 'Acesse nosso canal no YouTube' }, // Exemplo link externo
    {
        id: 'whatsapp',
        name: 'WhatsApp',
        url: 'https://wa.me/5521999677722?text=Olá!%20Gostaria%20de%20mais%20informações',
        iconClass: 'fab fa-whatsapp',
        accessibility: 'Entre em contato conosco via WhatsApp'
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/contact_section_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "contactLink": "contact_section_ds-module__4xBhyW__contactLink",
  "contactSection": "contact_section_ds-module__4xBhyW__contactSection",
  "contactText": "contact_section_ds-module__4xBhyW__contactText",
  "contactTitle": "contact_section_ds-module__4xBhyW__contactTitle",
  "formCard": "contact_section_ds-module__4xBhyW__formCard",
  "formTitle": "contact_section_ds-module__4xBhyW__formTitle",
  "icon": "contact_section_ds-module__4xBhyW__icon",
  "iconWrapper": "contact_section_ds-module__4xBhyW__iconWrapper",
  "recaptchaContainer": "contact_section_ds-module__4xBhyW__recaptchaContainer",
  "recaptchaHint": "contact_section_ds-module__4xBhyW__recaptchaHint",
  "sectionSubtitle": "contact_section_ds-module__4xBhyW__sectionSubtitle",
  "sectionTitle": "contact_section_ds-module__4xBhyW__sectionTitle",
  "shadow-sm": "contact_section_ds-module__4xBhyW__shadow-sm",
  "socialIconLink": "contact_section_ds-module__4xBhyW__socialIconLink",
  "socialLinksContainer": "contact_section_ds-module__4xBhyW__socialLinksContainer",
  "submitButton": "contact_section_ds-module__4xBhyW__submitButton",
  "text-center": "contact_section_ds-module__4xBhyW__text-center",
});
}),
"[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"); // Adicionado useRef
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/contact_data_ds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/contact_section_ds.module.css [app-client] (css module)");
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const ReCAPTCHA = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/node_modules/react-google-recaptcha/lib/esm/index.js [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/node_modules/react-google-recaptcha/lib/esm/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = ReCAPTCHA;
// Subcomponente para item de contato
const ContactInfoItem = ({ iconClass, title, text, link })=>// ... (código inalterado) ...
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactItem} d-flex align-items-start mb-3`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconWrapper} me-3 flex-shrink-0`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                    iconClass: iconClass,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].icon
                }, void 0, false, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                    lineNumber: 22,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                lineNumber: 21,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-grow-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactTitle} mb-0`,
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                        lineNumber: 25,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    link ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: link,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactLink,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactText} mb-0`,
                            children: text
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                            lineNumber: 28,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                        lineNumber: 27,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactText} mb-0`,
                        children: text
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                        lineNumber: 31,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                lineNumber: 24,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
        lineNumber: 20,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c1 = ContactInfoItem;
const RECAPTCHA_SITE_KEY = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || '6LeshiwrAAAAAPVbR8FTS_4l-80ea1G_UyBhZuFk';
const STATICFORMS_ACCESS_KEY = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_STATICFORMS_KEY || 'sf_b14798mng2klecllc3dljkgb';
function ContactSectionDS() {
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        message: ''
    });
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [submitStatus, setSubmitStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // 'success', 'error', 'error_recaptcha'
    const recaptchaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Ref para o componente reCAPTCHA
    const sectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [shouldLoadRecaptcha, setShouldLoadRecaptcha] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const ensureRecaptchaLoaded = ()=>{
        setShouldLoadRecaptcha(true);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ContactSectionDS.useEffect": ()=>{
            if (shouldLoadRecaptcha || !sectionRef.current || typeof IntersectionObserver === 'undefined') {
                return;
            }
            const observer = new IntersectionObserver({
                "ContactSectionDS.useEffect": (entries)=>{
                    const isVisible = entries.some({
                        "ContactSectionDS.useEffect.isVisible": (entry)=>entry.isIntersecting
                    }["ContactSectionDS.useEffect.isVisible"]);
                    if (isVisible) {
                        setShouldLoadRecaptcha(true);
                        observer.disconnect();
                    }
                }
            }["ContactSectionDS.useEffect"], {
                rootMargin: '300px 0px'
            });
            observer.observe(sectionRef.current);
            return ({
                "ContactSectionDS.useEffect": ()=>observer.disconnect()
            })["ContactSectionDS.useEffect"];
        }
    }["ContactSectionDS.useEffect"], [
        shouldLoadRecaptcha
    ]);
    const handleChange = (e)=>{
        const { id, value } = e.target;
        setFormData((prevData)=>({
                ...prevData,
                [id]: value
            }));
    };
    const handleSubmitReact = async (e)=>{
        e.preventDefault(); // Previne envio nativo
        setIsSubmitting(true);
        setSubmitStatus(null);
        if (!shouldLoadRecaptcha) {
            setShouldLoadRecaptcha(true);
            setSubmitStatus('error_recaptcha');
            setIsSubmitting(false);
            return;
        }
        //console.log("event: ", e); // Debug
        // 1. Obter token do reCAPTCHA
        const recaptchaToken = recaptchaRef.current?.getValue(); // Usa optional chaining
        //console.log("recaptchaToken: ", recaptchaToken); // Debug
        // 2. Validar token
        if (!recaptchaToken) {
            setSubmitStatus('error_recaptcha');
            setIsSubmitting(false);
            recaptchaRef.current?.reset(); // Reseta para o usuário tentar de novo
            //console.error("reCAPTCHA não preenchido.");
            return;
        }
        // Montar Payload
        const isLocalDevelopment = window.location.hostname === 'localhost' || window.location.hostname.startsWith('192.168.'); // Ou outra forma de detectar dev
        let redirectToEmail = '';
        if (!isLocalDevelopment) {
            redirectToEmail = 'https://devsolar.com.br/#contato';
        }
        // 3. Montar Payload para StaticForms (incluindo campos hidden e reCAPTCHA)
        const payload = {
            ...formData,
            // --- Campos específicos devido políticas da API ---
            // name: `${formData.firstName} ${formData.lastName} - ${formData.phone}`,
            // email: `${formData.email}`,
            // message: `${formData.message}`,
            // --- Campos específicos para StaticForms ---
            accessKey: STATICFORMS_ACCESS_KEY,
            subject: `Contato Site DEV Solar: ${formData.firstName} ${formData.lastName}`,
            // replyTo: formData.email, // Email do remetente para responder
            // redirectTo: { redirectToEmail },  // redirectTo: "https://devsolar.com.br/#contato", // *** CRIE UMA PÁGINA DE OBRIGADO ***
            // --- Fim dos campos StaticForms ---
            'g-recaptcha-response': recaptchaToken
        };
        //console.log("Enviando payload:", payload); // Debug
        // 4. Enviar via Fetch
        try {
            const response = await fetch('https://api.staticforms.xyz/submit', {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: {
                    'accept-charset': 'UTF-8',
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }
            });
            //console.log("response status:", response.status); // Debug status
            //console.log("response ok:", response.ok); // Debug ok flag
            // Tenta ler o JSON mesmo se não for ok, para pegar a msg de erro
            const result = await response.json();
            //console.log("result:", result);
            // --- CORREÇÃO AQUI: Verificar response.ok ou result específico ---
            if (response.ok && result.success !== false) {
                // Verifica se a requisição foi OK (status 2xx) E se o JSON não indica falha explicitamente
                // OU, se StaticForms SEMPRE retorna 'message' no sucesso:
                // if (response.ok && result.message === 'Form submitted successfully') {
                //console.log("StaticForms Success:", result);
                setSubmitStatus('success'); // <<< Define SUCESSO
                // Limpar formulário após sucesso
                setFormData({
                    firstName: '',
                    lastName: '',
                    phone: '',
                    email: '',
                    message: ''
                });
                recaptchaRef.current?.reset(); // Reseta o reCAPTCHA
                setTimeout(()=>setSubmitStatus(null), 6000); // Limpa msg após 4s
            // Opcional: Redirecionar (se removeu o redirectTo do payload)
            // setTimeout(() => { window.location.href = "/obrigado"; }, 1500);
            } else {
                // Erro HTTP ou erro reportado pelo StaticForms
                //console.error("StaticForms Error Response:", result.error || result.message || 'Erro desconhecido');
                setSubmitStatus('error'); // <<< Define ERRO
                recaptchaRef.current?.reset();
            }
        } catch (error) {
            // Erro na requisição fetch (rede, CORS local, etc.)
            //console.error("Submit Fetch Error:", error);
            setSubmitStatus('error'); // <<< Define ERRO
        // Não precisa resetar o recaptcha aqui necessariamente, pois a submissão falhou antes da validação dele
        // recaptchaRef.current?.reset();
        } finally{
            setIsSubmitting(false); // Finaliza o estado de envio
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: sectionRef,
        id: "contato",
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactSection}`,
        "aria-labelledby": "contact-heading",
        onMouseEnter: ensureRecaptchaLoaded,
        onTouchStart: ensureRecaptchaLoaded,
        children: [
            shouldLoadRecaptcha && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: "https://www.google.com/recaptcha/api.js",
                strategy: "lazyOnload",
                async: true,
                defer: true
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                lineNumber: 214,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "contact-heading",
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold mb-4`,
                                    children: "Entre em Contato"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                    lineNumber: 226,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} mb-4`,
                                    children: "Estamos prontos para esclarecer todas as suas dúvidas e ajudar você a economizar com energia solar."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                    lineNumber: 232,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-4",
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contactInfoData"].map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactInfoItem, {
                                            ...item
                                        }, item.id, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                            lineNumber: 238,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                    lineNumber: 236,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialLinksContainer} d-flex`,
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_data_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socialLinksData"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: link.url,
                                            target: link.url.startsWith('http') ? '_blank' : '_self',
                                            rel: link.url.startsWith('http') ? 'noopener noreferrer' : '',
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].socialIconLink,
                                            "aria-label": `Visite nosso ${link.name}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                    iconClass: link.iconClass
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 251,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "sr-only",
                                                    children: link.accessibility
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 252,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, link.id, true, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                            lineNumber: 243,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                    lineNumber: 241,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                            lineNumber: 224,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-6 mt-lg-0 mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formCard} card shadow-sm`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "card-body p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formTitle} fw-bold mb-4`,
                                            children: "Envie sua Mensagem"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                            lineNumber: 262,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                            id: "contactForm",
                                            onSubmit: handleSubmitReact,
                                            onFocusCapture: ensureRecaptchaLoaded,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            htmlFor: "firstName",
                                                            className: "form-label",
                                                            children: "Nome"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 273,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "text",
                                                            className: "form-control var(--branco)",
                                                            id: "firstName",
                                                            name: "firstName",
                                                            required: true,
                                                            value: formData.firstName,
                                                            onChange: handleChange,
                                                            autoComplete: "given-name"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 276,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 272,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            htmlFor: "lastName",
                                                            className: "form-label",
                                                            children: "Sobrenome"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 288,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "text",
                                                            className: "form-control var(--branco)",
                                                            id: "lastName",
                                                            name: "lastName",
                                                            required: true,
                                                            value: formData.lastName,
                                                            onChange: handleChange,
                                                            autoComplete: "family-name"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 291,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 287,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            htmlFor: "email",
                                                            className: "form-label",
                                                            children: "E-mail"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 303,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "email",
                                                            className: "form-control var(--branco)",
                                                            id: "email",
                                                            name: "email",
                                                            required: true,
                                                            value: formData.email,
                                                            onChange: handleChange,
                                                            autoComplete: "email"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 306,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 302,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            htmlFor: "phone",
                                                            className: "form-label",
                                                            children: "Telefone"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 318,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "tel",
                                                            className: "form-control var(--branco)",
                                                            id: "phone",
                                                            name: "phone",
                                                            required: true,
                                                            value: formData.phone,
                                                            onChange: handleChange,
                                                            autoComplete: "tel"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 321,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 317,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            htmlFor: "message",
                                                            className: "form-label",
                                                            children: "Mensagem"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 333,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                            className: "form-control var(--branco)",
                                                            id: "message",
                                                            name: "message",
                                                            rows: "4",
                                                            value: formData.message,
                                                            onChange: handleChange
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                            lineNumber: 336,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 332,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    htmlFor: "recaptcha",
                                                    className: "form-label d-block",
                                                    children: "Verificação*"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 347,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                                                    id: "recaptcha",
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].recaptchaContainer} m-0 mb-3 border-0 p-0`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mb-3",
                                                        children: [
                                                            shouldLoadRecaptcha ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ReCAPTCHA, {
                                                                ref: recaptchaRef,
                                                                sitekey: RECAPTCHA_SITE_KEY,
                                                                onChange: (token)=>console.log('Captcha token:', token),
                                                                hl: "pt-BR"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                                lineNumber: 356,
                                                                columnNumber: 25
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].recaptchaHint} small mb-0`,
                                                                children: "A verificação será carregada quando você começar a preencher o formulário."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                                lineNumber: 365,
                                                                columnNumber: 25
                                                            }, this),
                                                            submitStatus === 'error_recaptcha' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-danger small mt-1",
                                                                children: "Por favor, complete a verificação."
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                                lineNumber: 371,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                        lineNumber: 354,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 350,
                                                    columnNumber: 19
                                                }, this),
                                                submitStatus === 'success' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "alert alert-success",
                                                    children: "Obrigado! Sua mensagem foi enviada com sucesso! Entraremos em contato em breve."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 379,
                                                    columnNumber: 21
                                                }, this),
                                                submitStatus === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "alert alert-danger",
                                                    children: "Ocorreu um erro ao enviar a mensagem. Por favor, tente novamente ou entre em contato por outro canal."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 385,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "d-grid",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "submit",
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$contact_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submitButton} btn btn-primary-custom`,
                                                        disabled: isSubmitting,
                                                        children: isSubmitting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "spinner-border spinner-border-sm me-2",
                                                                    role: "status",
                                                                    "aria-hidden": "true"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                                    lineNumber: 400,
                                                                    columnNumber: 27
                                                                }, this),
                                                                "Enviando..."
                                                            ]
                                                        }, void 0, true) : 'Enviar Mensagem'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                        lineNumber: 393,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                                    lineNumber: 392,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                            lineNumber: 266,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                    lineNumber: 261,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                                lineNumber: 260,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                            lineNumber: 259,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                    lineNumber: 222,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
                lineNumber: 221,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/main/contact_section_ds.js",
        lineNumber: 205,
        columnNumber: 5
    }, this);
}
_s(ContactSectionDS, "RNSpQy34CJ7rvvZwJXsAcunKU48=");
_c2 = ContactSectionDS;
const __TURBOPACK__default__export__ = ContactSectionDS;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ReCAPTCHA");
__turbopack_context__.k.register(_c1, "ContactInfoItem");
__turbopack_context__.k.register(_c2, "ContactSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/cta_section_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "ctaButton": "cta_section_ds-module__R15Ifa__ctaButton",
  "ctaSection": "cta_section_ds-module__R15Ifa__ctaSection",
  "headline": "cta_section_ds-module__R15Ifa__headline",
  "headlineIcon": "cta_section_ds-module__R15Ifa__headlineIcon",
  "subtext": "cta_section_ds-module__R15Ifa__subtext",
});
}),
"[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import FaleConoscoDS from '../fale_conosco_ds';
// function CTASectionDS() {
//     return (
//         <>
//             {/* CTA Section */}
//             <section className="py-5 bg-primary-custom text-white">
//                 <div className="container">
//                     <div className="row align-items-center">
//                         <div className="col-lg-8 mb-4 mb-lg-0">
//                             <h2 className="fw-bold">Pronto para começar a economizar?</h2>
//                             <p className="lead mb-0">Solicite agora mesmo uma avaliação gratuita para seu imóvel.</p>
//                         </div>
//                         <div className="col-lg-4 text-lg-end">
//                             {/*   <button className="btn btn-light btn-lg" data-bs-toggle="modal" data-bs-target="#contactModal" onClick={() => console.log("Fala Aí!")}>
//                                 <i className="fas fa-headset me-2"></i><span>Falar com Especialista</span>
//                             </button> */}
//                             <FaleConoscoDS
//                                 textClassButton="btn btn-light btn-lg mb-3"
//                                 textMessage="Olá, quero falar com especialista."
//                                 textTag="#avaliaçãoGratuita"
//                             />
//                         </div>
//                     </div>
//                 </div>
//             </section >
//         </>
//     );
// }
// export default CTASectionDS;
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js [app-client] (ecmascript)"); // Confirme o caminho
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/cta_section_ds.module.css [app-client] (css module)"); // Importe o CSS Module
'use client';
;
;
;
;
// Opcional: Importe um ícone se for usar SVG ou uma biblioteca
// import { FaBolt } from 'react-icons/fa'; // Exemplo com react-icons
function CTASectionDS() {
    // Defina a classe do botão aqui ou use diretamente na prop
    const buttonClasses = `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].ctaButton} mb-3`; // Combina estilo do module com margem do Bootstrap
    return(// Removido o Fragmento desnecessário
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].ctaSection,
        "aria-labelledby": "cta-headline",
        children: [
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row align-items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-8 mb-4 mb-lg-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "cta-headline",
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headline,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                            iconClass: "fas fa-bolt",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headlineIcon
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                                            lineNumber: 56,
                                            columnNumber: 29
                                        }, this),
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Pronto para começar a economizar?"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                                            lineNumber: 57,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                                    lineNumber: 53,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtext,
                                    children: "Solicite agora mesmo uma avaliação gratuita para seu imóvel."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                                    lineNumber: 59,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                            lineNumber: 52,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `col-lg-4 text-lg-end ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$cta_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].buttonContainer}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                // Passando as classes CSS (incluindo a customizada do module)
                                textClassButton: buttonClasses,
                                // Mantém as outras props
                                textMessage: "Olá, quero falar com especialista sobre avaliação gratuita.",
                                textTag: "#avaliacaoGratuitaCTA"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                                lineNumber: 64,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                            lineNumber: 63,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                    lineNumber: 51,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
                lineNumber: 50,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/main/cta_section_ds.js",
        lineNumber: 49,
        columnNumber: 9
    }, this));
}
_c = CTASectionDS;
const __TURBOPACK__default__export__ = CTASectionDS;
var _c;
__turbopack_context__.k.register(_c, "CTASectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/logo-devsolar-icon.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/logo-devsolar-icon.1sprf_48qa6-s.webp");}),
"[project]/src/assets/logo-devsolar-icon.webp.mjs { IMAGE => \"[project]/src/assets/logo-devsolar-icon.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$devsolar$2d$icon$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/logo-devsolar-icon.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$devsolar$2d$icon$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 300,
    height: 300,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRjwBAABXRUJQVlA4TDABAAAvB8ABEM1VICICHgiADQIAAIDxA4Ac5yQAAAAAIIcDDkAAIIEAAAQJgIAAAACAAAAIfg4A2nMCdzTIAQA8EIAUBgAAgPM/7OsHoCxAiMAAAAAAAAAAAAAAAAAAAAAAAAAAAACgEJ49AAD/ozwQEBQGAACA878ZtB4AAACUYQgCwwAAAAAAAAAAAAAAAAAACIBAIAAgwQDAW5EBDwQghQEAAOD8b9GAJyoPAAAAgBkAAAgAAQgEAgJjEAAYAMBgAAIEAAAAAGsM8AAgP7AAQO0xa6MfBk34dnHpN5T3vgIA7RLSMp5znfdxfGfYVixnfqMvbXdP3wpQrwnns2l561cOClnlisOHa9FQ6zW/KY89V536mFppVt1t5Hp69V2F+Xf8vS2P2dAvgpZwAGIAAPAD"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/persona-1.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/persona-1.33vdklqy7ylqb.webp");}),
"[project]/src/assets/persona-1.webp.mjs { IMAGE => \"[project]/src/assets/persona-1.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$1$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/persona-1.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$1$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 300,
    height: 300,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRiIBAABXRUJQVlA4TBUBAAAvB8ABAM1VICICHgiADQIAAAC6chypJwIkiAMAAAIAAAAAAAAAAABAAAAAABAABCilp3ccXYXfxD0JAADAAwHIQQAAADj/+//W2luBDAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAACrY1/r3QIByUAEAAM5/W29dt1ZNBFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAACIAPAB/SaJ1kFymWY3U/256AyzBYfhfOCvIhH5SiXcmRx1Zk6oBtz0EzL5lxEa8SbPeg3gcmHjmtVisVC8DjsIkcbWxNkoKBqlqg1LO+bjLoX/I+UP/01wI0DL0N/6tM/pldXZ9jAIkT+eEPvLt3pkImY7G5+vqM6U1kYB9oudkCAA=="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/persona-2.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/persona-2.1mjq1sen-979m.webp");}),
"[project]/src/assets/persona-2.webp.mjs { IMAGE => \"[project]/src/assets/persona-2.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$2$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/persona-2.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$2$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 300,
    height: 300,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRhwBAABXRUJQVlA4TA8BAAAvB8ABAM1VICICHggADiIAAIC7CQWQECEEIQAAAAAAAAAAAAAAAAAAAAAAwgIAQknkAVOUsBR3zXc1AAAADwQgBwEAAOD877YflRA1KAAAAAAAAAAAAAAAAAAAAAAAAAAAEAqAAiSRgGQUMpreAwE4QgAAADj/u7UJEiBRiqcCAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALzytYu8tZGxyeHIUL3KPiIAhCe1o/bNdtX4jxwQUDC2aHPubZXqeZr3Kn5FA5Wz3GqxmEH8SjnRa/IjJEZw95D8tEESIQ2ZSNXHMc/nsk0+eX558nQAoLI713Kf4/4ex9IP1xpGi0SQkdHPIgzptP+XpVm3IVIgAA=="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/persona-3.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/persona-3.32hzr9j1r_0p2.webp");}),
"[project]/src/assets/persona-3.webp.mjs { IMAGE => \"[project]/src/assets/persona-3.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$3$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/persona-3.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$3$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 300,
    height: 300,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRhoBAABXRUJQVlA4TA4BAAAvB8ABAM1VICICHgiADQIAAIBelanIlTpAAkEIIRAAAEAAAgEAAAAAAAAAAAAAAAgCKBCPLgL5+/UKAADAAwE4QgAAADj/u21fopAEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ0Sv1294DAbhhBAAAOP/Lp/FbgA1jAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIABQDvN3RrZ28jWBzkg1vRel/vCQOEUWGuydmK/A/wPxN+NE1H+qu7FvODo3vbqoZRMCexqbKxvGXQC7JUU+YAFvFqbmYBuuPibxmeaEBET6Zfy3Pgl92ZNEVqo7Mg2YLQYn0PVVlKDsCndsflYkcQp+5xpwzCZCwE="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/persona-4.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/persona-4.253pjpk-d0jx9.webp");}),
"[project]/src/assets/persona-4.webp.mjs { IMAGE => \"[project]/src/assets/persona-4.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$4$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/persona-4.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$4$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 300,
    height: 300,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRh4BAABXRUJQVlA4TBIBAAAvB8ABAM1VICICHggACAIAAICrFwDGYMBsAMAAgAEAAAAAAAAAAAADYAx78M9gz8/AD+AfCE+V/gMAAOCBAOQgAAAAnP/9vn9YbAalRDAgCAASAAAAgoIACBAACAAAAAAAAAAAAAAAAAAQW8sDAThCAAAAOP/b2s9IARQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIjeUv+ai5xSGQAk1FozARsG3F2YBjIw0T/yb9tkLsjKdvyUkFQZ2rKG2x8v5EZJSw8jNlcpafCzAm6OH8IAEu/6+api2Uhy8cWTVS8wi3C46kUFuV68nCDA675TZ7eguQOdtOPETvbDhyfiy6q4U1E++bgdxX5uc6MtlnUF"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/persona-5.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/persona-5.1px7vh_eyyunl.webp");}),
"[project]/src/assets/persona-5.webp.mjs { IMAGE => \"[project]/src/assets/persona-5.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$5$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/persona-5.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$5$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 300,
    height: 300,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRgwBAABXRUJQVlA4TAABAAAvB8ABAM1VICICHghQDioAAIB3kl2mCQMoCAAgAAACAAAAAAAAAAAAAAAAAKCEAAAACfjnF6QomJU5AACABwKUgwoAAHD+7+3ONlGfEAoBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiAS5+rHbeSAgNwwAAADnf9maKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsKZt/iMFRDJMZ/6dEvRXdpZZALCoxu1v1qqXPe1r1wbQnzjQxjtv+sSHAqCUxZ2NSGkKURaA+gQPDgGIKbdyA2h7Dxyfs7RPxnO6dwBo0WGLq8X5f/332AiAN1lqPeNdPf7Saa67VqIA"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/faq_section_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "answerBubble": "faq_section_ds-module__3D_KpG__answerBubble",
  "answerRow": "faq_section_ds-module__3D_KpG__answerRow",
  "avatarContainer": "faq_section_ds-module__3D_KpG__avatarContainer",
  "avatarImage": "faq_section_ds-module__3D_KpG__avatarImage",
  "emojiButton": "faq_section_ds-module__3D_KpG__emojiButton",
  "emojiPickerWrapper": "faq_section_ds-module__3D_KpG__emojiPickerWrapper",
  "faqAccordion": "faq_section_ds-module__3D_KpG__faqAccordion",
  "faqItem": "faq_section_ds-module__3D_KpG__faqItem",
  "inputAreaContainer": "faq_section_ds-module__3D_KpG__inputAreaContainer",
  "messageBody": "faq_section_ds-module__3D_KpG__messageBody",
  "messageBubble": "faq_section_ds-module__3D_KpG__messageBubble",
  "messageHeader": "faq_section_ds-module__3D_KpG__messageHeader",
  "messageRow": "faq_section_ds-module__3D_KpG__messageRow",
  "messageRowAns": "faq_section_ds-module__3D_KpG__messageRowAns",
  "questionBubble": "faq_section_ds-module__3D_KpG__questionBubble",
  "questionRow": "faq_section_ds-module__3D_KpG__questionRow",
  "sectionFaq": "faq_section_ds-module__3D_KpG__sectionFaq",
  "sectionSubtitle": "faq_section_ds-module__3D_KpG__sectionSubtitle",
  "sectionTitle": "faq_section_ds-module__3D_KpG__sectionTitle",
  "sendButton": "faq_section_ds-module__3D_KpG__sendButton",
  "toggleIcon": "faq_section_ds-module__3D_KpG__toggleIcon",
  "toggleIconClosed": "faq_section_ds-module__3D_KpG__toggleIconClosed",
  "toggleIconOpen": "faq_section_ds-module__3D_KpG__toggleIconOpen",
  "userInput": "faq_section_ds-module__3D_KpG__userInput",
  "userInputSection": "faq_section_ds-module__3D_KpG__userInputSection",
  "userInputTitle": "faq_section_ds-module__3D_KpG__userInputTitle",
});
}),
"[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$devsolar$2d$icon$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo$2d$devsolar$2d$icon$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/logo-devsolar-icon.webp.mjs { IMAGE => "[project]/src/assets/logo-devsolar-icon.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$1$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$1$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/persona-1.webp.mjs { IMAGE => "[project]/src/assets/persona-1.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$2$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$2$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/persona-2.webp.mjs { IMAGE => "[project]/src/assets/persona-2.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$3$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$3$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/persona-3.webp.mjs { IMAGE => "[project]/src/assets/persona-3.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$4$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$4$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/persona-4.webp.mjs { IMAGE => "[project]/src/assets/persona-4.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$5$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$5$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/persona-5.webp.mjs { IMAGE => "[project]/src/assets/persona-5.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/free-solid-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/react-fontawesome/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Accordion.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/faq_section_ds.module.css [app-client] (css module)");
;
;
;
var _s = __turbopack_context__.k.signature();
// No topo do arquivo FAQSectionDS.jsx
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const EmojiPicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/node_modules/emoji-picker-react/dist/emoji-picker-react.esm.js [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/node_modules/emoji-picker-react/dist/emoji-picker-react.esm.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = EmojiPicker;
const WhatsAppSender = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c1 = WhatsAppSender;
// --- Dados ---
const faqData = [
    // ... (seus dados faqData existentes) ...
    {
        id: '0',
        question: 'Quanto tempo leva para instalar um sistema solar?',
        answer: 'A instalação física é rápida, levando de 2 a 3 dias para residências e de 1 a 3 semanas para grandes projetos comerciais, industriais ou condomínios. No entanto, o processo completo inclui a homologação da concessionária para conectar o sistema à rede elétrica pública, etapa que leva de 1 a 4 semanas.',
        personaImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$1$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$1$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"]
    },
    {
        id: '1',
        question: 'Os painéis funcionam em dias nublados?',
        answer: 'Sim!<br><br>Os painéis solares dependem da luminosidade e radiação, não do calor, por isso continuam gerando energia mesmo com o céu encoberto. Em dias totalmente nublados, a produção se mantém ativa, operando entre 10% e 25% da sua capacidade máxima em comparação a um dia de céu limpo.',
        personaImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$2$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$2$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"]
    },
    {
        id: '2',
        question: 'Preciso de baterias para armazenar energia?',
        answer: 'Não necessariamente.<br><br>A maioria dos sistemas utiliza o modelo On-Grid, que funciona conectado à rede pública. Durante o dia, os painéis geram energia para consumo imediato e o excedente é enviado para a distribuidora, transformando-se em créditos. À noite ou em dias chuvosos, você consome a energia da rede e abate desses créditos acumulados.<br><br>O uso de baterias é restrito aos modelos Off-Grid ou Híbridos, indicados apenas para situações específicas. São elas: locais isolados sem acesso à rede, proteção contra apagões, armazenamento estratégico para horários de tarifa alta e atendimento a sistemas críticos.',
        personaImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$3$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$3$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"]
    },
    {
        id: '3',
        question: 'Qual a vida útil dos painéis solares?',
        answer: 'Os painéis solares modernos têm vida útil superior a 25 anos. Os fabricantes garantem que eles manterão pelo menos 80% a 85% da sua capacidade de geração original ao final desse período. Na prática, muitos módulos continuam gerando energia por 30 ou 40 anos, operando apenas com uma eficiência ligeiramente reduzida.',
        personaImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$4$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$4$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"]
    },
    {
        id: '4',
        question: 'Como funciona o financiamento dos sistemas?',
        answer: 'O processo é estruturado para que a própria economia gerada pague o investimento. O objetivo principal é que o valor da parcela seja igual ou menor do que a redução obtida na sua conta de luz. Para isso, oferecemos opções de financiamento de até 100% do projeto, cobrindo tanto os equipamentos (painéis e inversor) quanto a mão de obra de instalação.',
        personaImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$persona$2d$5$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$persona$2d$5$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"]
    }
];
const COMPANY_LOGO_URL = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$logo$2d$devsolar$2d$icon$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$logo$2d$devsolar$2d$icon$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"];
const WHATSAPP_CONTACT_NUMBER = '5521999677722';
const WHATSAPP_BASE_MESSAGE = 'FAQ do site:';
// --- Fim dos Dados ---
function renderAnswerWithLineBreaks(answerText) {
    return answerText.split(/<br\s*\/?\s*>/i).map((part, index, parts)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: [
                part,
                index < parts.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                    lineNumber: 78,
                    columnNumber: 35
                }, this) : null
            ]
        }, `${index}-${part.slice(0, 12)}`, true, {
            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
            lineNumber: 76,
            columnNumber: 5
        }, this));
}
function FAQSectionDS() {
    _s();
    const [userMessage, setUserMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showEmojiPicker, setShowEmojiPicker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const emojiPickerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const devSolarLogo = {
        width: 'auto',
        height: '60px'
    };
    // --- ESTADO PARA ATIVAR O WHATSAPP SENDER ---
    const [showWhatsAppSender, setShowWhatsAppSender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ... (handleUserInputChange, onEmojiClick, useEffect para fechar picker - inalterados) ...
    const handleUserInputChange = (e)=>{
        setUserMessage(e.target.value);
    };
    const onEmojiClick = (emojiObject)=>{
        setUserMessage((prevInput)=>prevInput + emojiObject.emoji);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FAQSectionDS.useEffect": ()=>{
            /* ... lógica de identificar device e fechar picker ... */ function handleClickOutside(event) {
                if (emojiPickerRef.current && !emojiPickerRef.current.contains(event.target)) {
                    const toggleButton = document.getElementById('emoji-toggle-button');
                    if (!toggleButton || !toggleButton.contains(event.target)) {
                        setShowEmojiPicker(false);
                    }
                }
            }
            document.addEventListener('mousedown', handleClickOutside);
            return ({
                "FAQSectionDS.useEffect": ()=>{
                    document.removeEventListener('mousedown', handleClickOutside);
                }
            })["FAQSectionDS.useEffect"];
        }
    }["FAQSectionDS.useEffect"], [
        emojiPickerRef
    ]);
    // Função que ATIVA o processo de envio
    const handleInitiateSend = ()=>{
        if (userMessage.trim() === '') return;
        setShowWhatsAppSender(true); // Ativa o componente WhatsAppSender
    };
    // Função chamada pelo WhatsAppSender quando o processo termina (ou é cancelado)
    const handleWhatsAppSenderClose = ()=>{
        setShowWhatsAppSender(false); // Desativa o sender
        setUserMessage(''); // Limpa o input AQUI
        setShowEmojiPicker(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "faq",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionFaq,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-5 text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold`,
                                    children: "Perguntas Frequentes (FAQ)"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                    lineNumber: 139,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} lead`,
                                    children: "Tire suas dúvidas sobre energia solar"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                    lineNumber: 142,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "row justify-content-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "col-lg-9 col-md-10",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        defaultActiveKey: "0",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].faqAccordion,
                                        children: faqData.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Item, {
                                                eventKey: item.id,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].faqItem,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Header, {
                                                        as: "div",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageHeader,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageRow} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].questionRow}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].avatarContainer,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: item.personaImage,
                                                                        alt: `Persona ${item.id + 1}`,
                                                                        width: 60,
                                                                        height: 60,
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].avatarImage,
                                                                        objectfit: "cover"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                        lineNumber: 163,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                    lineNumber: 162,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageBubble} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].questionBubble}`,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        children: item.question
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                        lineNumber: 175,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                    lineNumber: 172,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].toggleIcon,
                                                                    "aria-hidden": "true",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faAnglesDown"],
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].toggleIconClosed
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                            lineNumber: 178,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faComments"],
                                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].toggleIconOpen
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                            lineNumber: 182,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                    lineNumber: 177,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                            lineNumber: 159,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                        lineNumber: 158,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Body, {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageBody,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageRowAns} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].answerRow}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].messageBubble} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].answerBubble}`,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                        children: renderAnswerWithLineBreaks(item.answer)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                        lineNumber: 197,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                    lineNumber: 194,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].avatarContainer,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: COMPANY_LOGO_URL,
                                                                        alt: "Logo da Empresa",
                                                                        width: 60,
                                                                        height: 60,
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].avatarImage,
                                                                        style: {
                                                                            devSolarLogo
                                                                        }
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                        lineNumber: 200,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                                    lineNumber: 199,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                            lineNumber: 191,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                        lineNumber: 190,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, item.id, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                lineNumber: 151,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].userInputSection,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].userInputTitle,
                                                children: "Tire suas dúvidas para gerar sua própria energia com a Dev Solar:"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                lineNumber: 217,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputAreaContainer,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        id: "emoji-toggle-button",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].emojiButton,
                                                        onClick: ()=>setShowEmojiPicker(!showEmojiPicker),
                                                        "aria-label": "Selecionar emoji",
                                                        type: "button",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                            iconClass: "far fa-smile"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                            lineNumber: 230,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                        lineNumber: 223,
                                                        columnNumber: 19
                                                    }, this),
                                                    showEmojiPicker && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        ref: emojiPickerRef,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].emojiPickerWrapper,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmojiPicker, {
                                                            onEmojiClick: onEmojiClick,
                                                            emojiStyle: "native",
                                                            height: 350,
                                                            width: "100%"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                            lineNumber: 237,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                        lineNumber: 233,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        id: "pergunta-faq",
                                                        name: "pergunta_faq",
                                                        "aria-label": "Digite sua pergunta para o FAQ",
                                                        ref: inputRef,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].userInput,
                                                        rows: "1",
                                                        placeholder: "Digite sua pergunta...",
                                                        value: userMessage,
                                                        onChange: handleUserInputChange,
                                                        onInput: (e)=>{
                                                            e.target.style.height = 'auto';
                                                            e.target.style.height = e.target.scrollHeight + 'px';
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                        lineNumber: 246,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$faq_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendButton,
                                                        onClick: handleInitiateSend,
                                                        disabled: userMessage.trim() === '',
                                                        "aria-label": "Enviar pergunta via WhatsApp",
                                                        type: "button",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                            iconClass: "fas fa-paper-plane"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                            lineNumber: 269,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                        lineNumber: 262,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                                lineNumber: 221,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                        lineNumber: 216,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                                lineNumber: 147,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                            lineNumber: 146,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                    lineNumber: 136,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                lineNumber: 135,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WhatsAppSender, {
                show: showWhatsAppSender,
                onHide: handleWhatsAppSenderClose,
                phoneNumber: WHATSAPP_CONTACT_NUMBER,
                baseMessage: WHATSAPP_BASE_MESSAGE,
                userMessage: `"${userMessage}"`
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/faq_section_ds.js",
                lineNumber: 279,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(FAQSectionDS, "e6iirmvJVB4MiaGKTPEVqDQqK7E=");
_c2 = FAQSectionDS;
const __TURBOPACK__default__export__ = FAQSectionDS;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "EmojiPicker");
__turbopack_context__.k.register(_c1, "WhatsAppSender");
__turbopack_context__.k.register(_c2, "FAQSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/location_map_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "addressText": "location_map_ds-module__w5L9KG__addressText",
  "directionsButton": "location_map_ds-module__w5L9KG__directionsButton",
  "mapContainer": "location_map_ds-module__w5L9KG__mapContainer",
  "mapPlaceholder": "location_map_ds-module__w5L9KG__mapPlaceholder",
  "mapTitle": "location_map_ds-module__w5L9KG__mapTitle",
  "sectionLocation": "location_map_ds-module__w5L9KG__sectionLocation",
  "sectionSubtitle": "location_map_ds-module__w5L9KG__sectionSubtitle",
  "sectionTitle": "location_map_ds-module__w5L9KG__sectionTitle",
});
}),
"[project]/src/components/devsolar/estructure/body/main/location_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$location_map_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/location_map_ds.module.css [app-client] (css module)"); // Importar CSS Module
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const LocationMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/devsolar/estructure/body/main/location_map_ds.js [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/devsolar/estructure/body/main/location_map_ds.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = LocationMap;
function LocationSectionDS() {
    _s();
    const sectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [shouldRenderMap, setShouldRenderMap] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LocationSectionDS.useEffect": ()=>{
            if (shouldRenderMap || !sectionRef.current || typeof IntersectionObserver === 'undefined') {
                return;
            }
            const observer = new IntersectionObserver({
                "LocationSectionDS.useEffect": (entries)=>{
                    const isVisible = entries.some({
                        "LocationSectionDS.useEffect.isVisible": (entry)=>entry.isIntersecting
                    }["LocationSectionDS.useEffect.isVisible"]);
                    if (isVisible) {
                        setShouldRenderMap(true);
                        observer.disconnect();
                    }
                }
            }["LocationSectionDS.useEffect"], {
                rootMargin: '300px 0px'
            });
            observer.observe(sectionRef.current);
            return ({
                "LocationSectionDS.useEffect": ()=>observer.disconnect()
            })["LocationSectionDS.useEffect"];
        }
    }["LocationSectionDS.useEffect"], [
        shouldRenderMap
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            ref: sectionRef,
            id: "location",
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$location_map_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionLocation}`,
            "aria-labelledby": "benefits-title",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-5 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                id: "location-title",
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$location_map_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold`,
                                children: "Nossa Localização"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                                lineNumber: 68,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$location_map_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} lead`,
                                children: "Vamos marcar, encontre sua rota para vir falar com a gente!"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                                lineNumber: 74,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                        className: "g-4 justify-content-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-9",
                            children: shouldRenderMap ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LocationMap, {}, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                                lineNumber: 82,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$location_map_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mapPlaceholder,
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                                lineNumber: 84,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
                lineNumber: 66,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/devsolar/estructure/body/main/location_ds.js",
            lineNumber: 60,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(LocationSectionDS, "+coU943b+Mgra2GyEyTEJdL+lis=");
_c1 = LocationSectionDS;
const __TURBOPACK__default__export__ = LocationSectionDS;
var _c, _c1;
__turbopack_context__.k.register(_c, "LocationMap");
__turbopack_context__.k.register(_c1, "LocationSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "cardBody": "modalities_section_ds-module__BY3k3q__cardBody",
  "cardDescription": "modalities_section_ds-module__BY3k3q__cardDescription",
  "cardHeader": "modalities_section_ds-module__BY3k3q__cardHeader",
  "cardIcon": "modalities_section_ds-module__BY3k3q__cardIcon",
  "cardTitle": "modalities_section_ds-module__BY3k3q__cardTitle",
  "detailsButton": "modalities_section_ds-module__BY3k3q__detailsButton",
  "modalBodyContentStacked": "modalities_section_ds-module__BY3k3q__modalBodyContentStacked",
  "modalDialog": "modalities_section_ds-module__BY3k3q__modalDialog",
  "modalFooter": "modalities_section_ds-module__BY3k3q__modalFooter",
  "modalHeader": "modalities_section_ds-module__BY3k3q__modalHeader",
  "modalImage": "modalities_section_ds-module__BY3k3q__modalImage",
  "modalImageContainerStacked": "modalities_section_ds-module__BY3k3q__modalImageContainerStacked",
  "modalTextContent": "modalities_section_ds-module__BY3k3q__modalTextContent",
  "modalTitle": "modalities_section_ds-module__BY3k3q__modalTitle",
  "modalityCard": "modalities_section_ds-module__BY3k3q__modalityCard",
  "sectionModalities": "modalities_section_ds-module__BY3k3q__sectionModalities",
  "sectionSubtitle": "modalities_section_ds-module__BY3k3q__sectionSubtitle",
  "sectionTitle": "modalities_section_ds-module__BY3k3q__sectionTitle",
});
}),
"[project]/src/assets/producao-compartilhada.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/producao-compartilhada.1bf1atc1zo36g.webp");}),
"[project]/src/assets/producao-compartilhada.webp.mjs { IMAGE => \"[project]/src/assets/producao-compartilhada.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$compartilhada$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/producao-compartilhada.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$compartilhada$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1024,
    height: 1024,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRiYBAABXRUJQVlA4TBoBAAAvB8ABAM1VICICHgiADQIAAIBeqqhzWPcgAQQAAgAAAAAAAAAAAAEAAAAABABAAAACSBHCI91/05sAAAA8EAAbBAAAgPP/3upd5wcAwQEAAgACAAAAAAAAAAAAAAAAAAAAAAAADwggoOpf3rc8EAAbBAAAgPO3e5buLT/pBQEEAAAAAAAAAAAAAAAAAAAAAAAAAAAABEFErrrU7ycvcuQZqyEduTuENIYvL6JGbxsx/Diw96SzeAYpb48pmU9IyH6zkOYxo84tInRG3bSl7K7X4L8/YoNPSex6V5VQyzy1pJ3mMNOxjjqoOUjXmO+iVTbqQdEw7IH8PS3l8vT7JT4rxejW+wwbwJGa9EPVhc1qQKm0gXXLIfuKKr0="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/producao-negocio.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/producao-negocio.3tfxle-aj0uhe.webp");}),
"[project]/src/assets/producao-negocio.webp.mjs { IMAGE => \"[project]/src/assets/producao-negocio.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$negocio$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/producao-negocio.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$negocio$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 1024,
    height: 1024,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRh4BAABXRUJQVlA4TBEBAAAvB8ABAM1VICICHgiADQIAAAA4gAAIABChIAQAgKAAAAAAAAgAAAAAUACQEEECoVJa1YPeiyBFae8AAADwQACOEAAAAM6/3W3/Ej4BAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQgP9vW/NAAGwQAAAAzn/fu4+9K0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4LhUvDr/tkhwVGCk7IpwFz4CLwzF+TlDn+UHNBwtYFCEoOhPLOACSNx6Yl9uI7UZ8Xdr9ZSdTiaTgazGJjxLlYN+gx8yzcFrUgNh96VppD+2m0YP02FZb/soVqqc3KNwNm69us7vqTYXMXdeATDq9nbnTcajw5/vAYuXHQEA"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/producao-propria.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/producao-propria.3gwar_bo2nw8v.webp");}),
"[project]/src/assets/producao-propria.webp.mjs { IMAGE => \"[project]/src/assets/producao-propria.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$propria$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/producao-propria.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$propria$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 740,
    height: 531,
    blurWidth: 8,
    blurHeight: 6,
    blurDataURL: "data:image/webp;base64,UklGRlQBAABXRUJQVlA4TEgBAAAvB0ABEM1VICICHgiADQIAAIBC5MH9HQ4AAJIDAARAAIADDgQAgAQAeAoAAHIJQCBwQAABhDlUhJMcAADAAwHIQQAAADj/85EgABDfIoQBAAAABgAAAAAAAAAAAAAAAAOAIQBAAGAwgUbw2N7eAwGwQQAAADj/isAjBw4CF4cAASAAwV0IAcCTAwAcvDMAAAAAAAAIADgAgAB0P+AB80AwYBAAAADOfwIRBAAOhyN4AABwAAEAABAAAIDA4QBwAPAAAABAwEXEiQMU4IejnA5jmb57IilmlmsMJELFh5alrfx3H1wdNbzSIaEypwihhO0zWk6OdZO7XF+Kw7y6iGANT2X9+OsOBoPuIZ2M5+zIOkzq6RqMJllVPsNcfWXw+b+vyAmla7dOZcPe1iD/gsWmfD3x7an16bKc/dEs/u0NSkvuEtftsfsW"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/utility/fa-icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/fale_conosco_ds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.module.css [app-client] (css module)"); // Importar CSS Module
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$compartilhada$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$producao$2d$compartilhada$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/producao-compartilhada.webp.mjs { IMAGE => "[project]/src/assets/producao-compartilhada.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$negocio$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$producao$2d$negocio$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/producao-negocio.webp.mjs { IMAGE => "[project]/src/assets/producao-negocio.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$propria$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$producao$2d$propria$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/producao-propria.webp.mjs { IMAGE => "[project]/src/assets/producao-propria.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
// --- Dados (com HTML, definidos fora) ---
const modalitiesData = [
    // ... (cole os dados ATUALIZADOS do modalitiesData com HTML aqui) ...
    {
        id: 'propria',
        title: 'Produção Própria',
        iconClass: 'fa-solid fa-bolt',
        shortDescription: 'Gere energia para consumo no próprio local...',
        buttonText: 'Saiba Mais: Produção Própria de Energia',
        modalTitle: 'Modalidade: Produção Própria',
        modalMessage: 'produção de energia para utilização no mesmo imóvel',
        modalImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$propria$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$producao$2d$propria$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        modalText: `
            Esta modalidade permite que o consumidor gere energia para consumo no próprio local de instalação dos painéis fotovoltaicos.<br /><br />
            <strong>Pontos-chave:</strong><br /><br />
            <strong>Base legal:</strong> Regulamentada pela Resolução Normativa ANEEL nº 482/2012 e suas atualizações, como a Lei nº 14.300/2022 (Marco Legal da Microgeração).<br /><br />
            <strong>Aplicação:</strong> Ideal para residências unifamiliares, empresas, indústrias e propriedades rurais que possuam espaço adequado para instalação.<br /><br />
            <strong>Benefício fiscal:</strong> Os equipamentos possuem isenção de ICMS em muitos estados e possibilidade de depreciação acelerada para pessoas jurídicas.<br /><br />
            <strong>Economia:</strong> Redução de até 95% na conta de energia, dependendo do dimensionamento do sistema.<br /><br />
            <strong>Compensação:</strong> A energia excedente gera créditos que podem ser utilizados em até 60 meses.<br /><br />
            <strong>Valorização imobiliária:</strong> Propriedades com sistemas solares tendem a valorizar no mercado.<br /><br />`
    },
    {
        id: 'compartilhada',
        title: 'Produção Compartilhada',
        iconClass: 'fas fa-users',
        shortDescription: 'Múltiplos consumidores compartilham os benefícios...',
        buttonText: 'Saiba Mais: Produção Compartilhada',
        modalTitle: 'Modalidade: Produção Compartilhada',
        modalMessage: 'produção de energia com utilização também em outro imóvel',
        modalImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$compartilhada$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$producao$2d$compartilhada$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        modalText: `Esta modalidade permite que múltiplos consumidores compartilhem os benefícios de uma mesma usina solar, mesmo estando em locais diferentes.<br /><br />
            <strong>Pontos-chave:</strong><br /><br />
            <strong>Base legal:</strong> Amparada pela Resolução Normativa ANEEL nº 687/2015 e Lei nº 14.300/2022.<br /><br />
            <strong>Formato jurídico:</strong> Pode ser estruturada como consórcio, cooperativa ou outras formas de associação.<br /><br />
            <strong>Aplicação ideal:</strong> Condomínios residenciais e comerciais, grupos empresariais com múltiplas unidades, associações de produtores rurais.<br /><br />
            <strong>Vantagem competitiva:</strong> Permite acesso à energia solar para quem não possui telhado adequado ou capital para instalação individual.<br /><br />
            <strong>Distribuição de créditos:</strong> Estabelecida por contrato entre os participantes, com percentuais fixos ou variáveis conforme participação no investimento.<br /><br />
            <strong>Economia de escala:</strong> Redução no custo por kWp instalado devido ao maior porte da instalação.<br /><br />
            <strong>Flexibilidade:</strong> Possibilidade de realocação de créditos entre unidades consumidoras de acordo com necessidades sazonais.<br /><br />`
    },
    {
        id: 'negocio',
        title: 'Produção para Negócio',
        iconClass: 'fas fa-store-alt',
        shortDescription: 'Comercialização de créditos de energia solar...',
        buttonText: 'Saiba Mais: Produção para Negócio',
        modalTitle: 'Modalidade: Produção para Negócio',
        modalMessage: 'produção de energia e comercialização de créditos',
        modalImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$producao$2d$negocio$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$producao$2d$negocio$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        modalText: `Esta modalidade permite a comercialização de créditos de energia solar para terceiros, criando um modelo de negócio específico.<br /><br />
            <strong>Pontos-chave:</strong><br /><br />
            <strong>Base legal:</strong> Estruturada conforme a Lei nº 14.300/2022 e regulamentações estaduais específicas.<br /><br />
            <strong>Modelo de negócio:</strong> Pode operar como uma usina solar dedicada à venda de créditos ou excedentes.<br /><br />
            <strong>Tributação específica:</strong> Incidência de PIS/COFINS e ICMS sobre a comercialização dos créditos em muitos estados.<br /><br />
            <strong>Contratos de fornecimento:</strong> Necessidade de instrumentos jurídicos robustos para garantir o fornecimento e estabelecer preços e condições.<br /><br />
            <strong>Público-alvo:</strong> Investidores que buscam retorno financeiro no setor energético, empresas com capacidade de investimento excedente.<br /><br />
            <strong>Rentabilidade:</strong> ROI de 12% a 20% ao ano, dependendo da escala e condições locais.<br /><br />
            <strong>Aspectos regulatórios:</strong> Necessidade de registro e autorizações específicas junto à ANEEL e concessionárias locais.<br /><br />
            <strong>Valor agregado:</strong> Possibilidade de vincular a comercialização a certificados de energia renovável ou programas ESG.<br /><br />`
    }
];
// --- Fim dos Dados ---
function ModalitiesSectionDS() {
    _s();
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedModalContent, setSelectedModalContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Guarda os dados do benefício ou do detalhe da categoria a ser exibido
    const [modalContent, setModalContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleShowModal = (modalityData)=>{
        setSelectedModalContent(modalityData);
        setShowModal(true);
    };
    const handleCloseModal = ()=>{
        setShowModal(false);
        setSelectedModalContent(null);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "modalidades",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionModalities,
                "aria-labelledby": "modalities-title",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "modalities-title",
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold`,
                                    children: "O que Fazer com Seu Potencial Solar"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                    lineNumber: 104,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} lead`,
                                    children: "Descubra a modalidade dos nossos serviços ideal para você"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                    lineNumber: 105,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                            lineNumber: 103,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            className: "g-4 justify-content-center",
                            children: modalitiesData.map((modality)=>// ... (Estrutura do Card inalterada) ...
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    md: 6,
                                    lg: 4,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalityCard} h-100`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardHeader,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                        iconClass: modality.iconClass,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardIcon
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                        lineNumber: 113,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardTitle,
                                                        children: modality.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                        lineNumber: 114,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                lineNumber: 112,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Body, {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardBody,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardDescription,
                                                        children: modality.shortDescription
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                        lineNumber: 117,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                        variant: "primary",
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].detailsButton} w-100`,
                                                        onClick: ()=>handleShowModal(modality),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$utility$2f$fa$2d$icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaIcon"], {
                                                                iconClass: "fas fa-info-circle",
                                                                className: "me-2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                                lineNumber: 123,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: modality.buttonText
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                                lineNumber: 124,
                                                                columnNumber: 45
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                        lineNumber: 118,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                                lineNumber: 116,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                        lineNumber: 111,
                                        columnNumber: 33
                                    }, this)
                                }, modality.id, false, {
                                    fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                    lineNumber: 110,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                            lineNumber: 107,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                    lineNumber: 101,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                lineNumber: 100,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                show: showModal,
                onHide: handleCloseModal,
                size: "lg",
                "aria-labelledby": "modality-detail-modal-title",
                centered: true,
                dialogClassName: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalDialog,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                        closeButton: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalHeader,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                            id: "modality-detail-modal-title",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalTitle,
                            children: selectedModalContent?.modalTitle
                        }, void 0, false, {
                            fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                            lineNumber: 144,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                        lineNumber: 143,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalBodyContentStacked,
                        children: [
                            " ",
                            selectedModalContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalImageContainerStacked,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: selectedModalContent.modalImage,
                                            alt: `Ilustração ${selectedModalContent.title}`,
                                            width: 900,
                                            height: 720,
                                            objectfit: "contain",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalImage
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                            lineNumber: 154,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                        lineNumber: 153,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalTextContent,
                                        dangerouslySetInnerHTML: {
                                            __html: selectedModalContent.modalText
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                        lineNumber: 164,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                        lineNumber: 149,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalFooter,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$fale_conosco_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                textClassButton: `btn btn-outline-custom btn-lg ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$modalities_section_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].modalFooterButton}`,
                                textMessage: `Olá, quero falar com especialista sobre ${selectedModalContent?.modalMessage}.`,
                                textTag: '#devSolar #beneficios',
                                onClick: handleCloseModal
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                lineNumber: 172,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "secondary",
                                onClick: handleCloseModal,
                                children: "Fechar"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                                lineNumber: 178,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                        lineNumber: 171,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/modalities_section_ds.js",
                lineNumber: 135,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
_s(ModalitiesSectionDS, "ZXAD5CvHou2oLmIUwUCOWIt8iEk=");
_c = ModalitiesSectionDS;
const __TURBOPACK__default__export__ = ModalitiesSectionDS;
var _c;
__turbopack_context__.k.register(_c, "ModalitiesSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "benefitIconContainer": "parceiros_financeiras_ds-module__AJ9VoW__benefitIconContainer",
  "partnerGrid": "parceiros_financeiras_ds-module__AJ9VoW__partnerGrid",
  "sectionPartners": "parceiros_financeiras_ds-module__AJ9VoW__sectionPartners",
  "sectionSubtitle": "parceiros_financeiras_ds-module__AJ9VoW__sectionSubtitle",
  "sectionTitle": "parceiros_financeiras_ds-module__AJ9VoW__sectionTitle",
  "subsection": "parceiros_financeiras_ds-module__AJ9VoW__subsection",
  "subsectionTitle": "parceiros_financeiras_ds-module__AJ9VoW__subsectionTitle",
});
}),
"[project]/src/components/devsolar/estructure/body/main/partner_card_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "benefitIconContainer": "partner_card_ds-module__iAqtPq__benefitIconContainer",
  "card": "partner_card_ds-module__iAqtPq__card",
  "logoContainer": "partner_card_ds-module__iAqtPq__logoContainer",
  "logoImage": "partner_card_ds-module__iAqtPq__logoImage",
  "partnerDescription": "partner_card_ds-module__iAqtPq__partnerDescription",
  "partnerName": "partner_card_ds-module__iAqtPq__partnerName",
  "textContainer": "partner_card_ds-module__iAqtPq__textContainer",
});
}),
"[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/partner_card_ds.module.css [app-client] (css module)"); // Criaremos este CSS
;
;
;
const PartnerCard = ({ logoUrl, name, description })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoContainer,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: logoUrl,
                    alt: `Logo ${name}`,
                    width: 60,
                    height: 60,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoImage,
                    // layout="responsive" // Pode ser útil dependendo do CSS
                    style: {
                        objectFit: 'contain'
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js",
                    lineNumber: 9,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js",
                lineNumber: 7,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerName,
                        children: name
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js",
                        lineNumber: 20,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerDescription,
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js",
                        lineNumber: 21,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js",
                lineNumber: 19,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js",
        lineNumber: 6,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PartnerCard;
const __TURBOPACK__default__export__ = PartnerCard;
var _c;
__turbopack_context__.k.register(_c, "PartnerCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/bv.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/bv.0k43wuwomwec9.webp");}),
"[project]/src/assets/bv.webp.mjs { IMAGE => \"[project]/src/assets/bv.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$bv$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/bv.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$bv$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 225,
    height: 225,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRiABAABXRUJQVlA4TBMBAAAvB8ABAM1VICICHgiADQIAAIAVQnUkAEfiwEsAwAGIawgIAAAARAEACABAACBBghAQCEICAQEeCVAHAADwQAByEAAAAM7/HmAAUCQCxigAASEAJgAAAAAAAAAAAAAAgFAAwAAKIAJWQiIgM9l5ICAoDAAAAOd//7WqpSwDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbM0AYAYYLB/5CVoAYBAAJvkFAKPx5ZAqG+u+NN2iFG3rlkr3XLZCtchgUlfHtdRJOzsaAKXkyDQIn8u/bzwJEj4GwPuMn/NWRl+btUuO6UT8KxNfT6nCFeFWvla6t4ch3kIxZjltbOmW3+Xc3rtfKBGfFDemM/8PTAM5MlwMLwA="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/canadian.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/canadian.19yoxll4yvpeu.webp");}),
"[project]/src/assets/canadian.webp.mjs { IMAGE => \"[project]/src/assets/canadian.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$canadian$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/canadian.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$canadian$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 150,
    height: 150,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRsQAAABXRUJQVlA4TLcAAAAvB8ABAM1VICICHggACQAAAIAAAAAMhg3sDQAAAAAAAAAAAAAAAAAAAAAAAAAAgGYcKBcACngAgAcCbAIAAABw/gvgV7GcFwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiC4oggAA4IEMgwAAAACc/65DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgUc6APyqvNP+1QSXSBYmuNbTIQ47HLZteYjyu+m3Hj0259rOWCsXwBMA"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/intelbras.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/intelbras.2-ze0yczdah13.webp");}),
"[project]/src/assets/intelbras.webp.mjs { IMAGE => \"[project]/src/assets/intelbras.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$intelbras$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/intelbras.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$intelbras$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 225,
    height: 225,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRvQAAABXRUJQVlA4TOcAAAAvB8ABAM1VICICHghADgIAAICrAvUDvPACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARGzI85h9v0ECAPBAAFIYAAAAzv/kGSDxAWAjoAAAAAAAAAAAAAAAAAAAAAAAAAAAIEoEAsAPG8LX5oEApDAAAACc/31iVsATDQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsGgbyzba/yA4A+MNPX/Tlw9XfTQAjIPY+epuKqUx7Vp1ffOz6P+POtd+l5TZKv658tvnOFPhUifVMVeJxhMKXrkecjGx2I07JZ+K0uz35vFAA8AEA"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/santander.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/santander.2diwnmym52g1j.webp");}),
"[project]/src/assets/santander.webp.mjs { IMAGE => \"[project]/src/assets/santander.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$santander$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/santander.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$santander$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 320,
    height: 320,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRkQBAABXRUJQVlA4TDgBAAAvB8ABEM1VICICHgjADioAAIC7XW+FUsI3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgprTQ2usDAAAPBAQHAQAA4PzvS0FQSEgCLIokgoBBgQIIAAEIAAAAAAAACQAAAKksCAAACCAAIPBAJAAAAAAAzr8BAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwB4IQA4CAADA+d+RgFoKKADQ/AgRASBIIAAAAQIAAAAAAMAAAAAAABIAtAqAUEAAswQIwIMjIkL7eQB/ClqltlZLEMAHAQWSSevjYFCqhCAAH0uibcuc9OaO6zbWDABHqHiy9KWNt6rpsSr4KwDyxO9j12jSYh1mi03N7W6jhUsiTx39K2Sb7Vld765KU0/miKqvLx9cOZ2HcZ/GVfaPfHH18wM="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/solagora.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/solagora.298hn4vma5og5.webp");}),
"[project]/src/assets/solagora.webp.mjs { IMAGE => \"[project]/src/assets/solagora.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$solagora$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/solagora.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$solagora$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 259,
    height: 194,
    blurWidth: 8,
    blurHeight: 6,
    blurDataURL: "data:image/webp;base64,UklGRtAAAABXRUJQVlA4TMMAAAAvB0ABAM1VICICHghaDgIAAIA3Jt22IgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgHBikaH9UwAA4IFgrUAAAACc/xbxAQBwAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAQAQFH3PBASEwAAAIDzvxURAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQ4CMFEAQC/zw984/1+AOfXvPOu1OAEO7w2v07Pu7Z1hVCiixTrTk60wKAVjTbqGqnogQA"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/assets/weg.webp (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/weg.2nv-q87pwy7xf.webp");}),
"[project]/src/assets/weg.webp.mjs { IMAGE => \"[project]/src/assets/weg.webp (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$weg$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/src/assets/weg.webp (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$weg$2e$webp__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 800,
    height: 800,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/webp;base64,UklGRuQAAABXRUJQVlA4TNcAAAAvB8ABAM1VICICHghACgMAAIDT8gIARnvIEAAAAAAAAAAAAAAABgAAAAAAAAAAAACMGTQCAOiVHSQAAA8E4AQCAADg/C+1BwCikAgAAAAAAAAAAMADAAAAAAAAAAAAAAAAAAiFlQBAbcUDATYBAAAAOP+5cwEASoUEAgAAAAAAAAAAACAAAAAAAAAAAAAAAERBEQAAXSXy+iuApVeO0x3DK4d92e0SAIqIckw95VrOlkUEAH/zwzZyxEi9snsEgEZ6l8Y3jSf39h0AHPZVv0uc/MLq7gKYAQA="
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.module.css [app-client] (css module)"); // Criaremos este CSS
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/partner_card_ds.js [app-client] (ecmascript)"); // Ajuste o caminho se necessário
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$bv$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$bv$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/bv.webp.mjs { IMAGE => "[project]/src/assets/bv.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$canadian$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$canadian$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/canadian.webp.mjs { IMAGE => "[project]/src/assets/canadian.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$intelbras$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$intelbras$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/intelbras.webp.mjs { IMAGE => "[project]/src/assets/intelbras.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$santander$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$santander$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/santander.webp.mjs { IMAGE => "[project]/src/assets/santander.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$solagora$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$solagora$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/solagora.webp.mjs { IMAGE => "[project]/src/assets/solagora.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$weg$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$weg$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/weg.webp.mjs { IMAGE => "[project]/src/assets/weg.webp (static in ecmascript, tag client)" } [app-client] (structured image object with data url, ecmascript)');
'use client';
;
;
;
;
;
;
;
;
;
// --- Dados de Exemplo (Substitua pelos seus dados reais) ---
const fornecedoresData = [
    {
        id: 'f1',
        name: 'Intelbras Solar',
        logoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$intelbras$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$intelbras$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        description: 'Soluções completas em equipamentos para energia solar fotovoltaica.'
    },
    {
        id: 'f2',
        name: 'WEG Solar',
        logoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$weg$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$weg$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        description: 'Tecnologia e eficiência em inversores, módulos e kits solares.'
    },
    {
        id: 'f3',
        name: 'Canadian Solar',
        logoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$canadian$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$canadian$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        description: 'Módulos fotovoltaicos de alta qualidade e performance global.'
    }
];
const financeirasData = [
    {
        id: 'fin1',
        name: 'Santander (Financiamentos)',
        logoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$santander$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$santander$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        description: 'Linhas de crédito especiais para projetos de energia solar.'
    },
    {
        id: 'fin2',
        name: 'BV Financeira',
        logoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$bv$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$bv$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        description: 'Facilidade e agilidade no financiamento do seu sistema solar.'
    },
    {
        id: 'fin3',
        name: 'Sol Agora (Creditas)',
        logoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$solagora$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$solagora$2e$webp__$28$static__in__ecmascript$2c$__tag__client$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
        description: 'Financiamento solar rápido, digital e sem burocracia.'
    }
];
// --- Fim dos Dados de Exemplo ---
function ParceirosFinanceirasSectionDS() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            id: "parceiros",
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionPartners}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center mb-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold`,
                                children: "Conheça Nossos Parceiros e Financeiras"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                lineNumber: 68,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} lead`,
                                children: "Somos uma rede que colabora para o benefício dos nossos clientes."
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                lineNumber: 69,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                        lineNumber: 67,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subsection,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subsectionTitle,
                                children: "Nossos Fornecedores"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                lineNumber: 74,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerGrid,
                                children: fornecedoresData.map((partner)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        logoUrl: partner.logoUrl,
                                        name: partner.name,
                                        description: partner.description
                                    }, partner.id, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                        lineNumber: 77,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                lineNumber: 75,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                        lineNumber: 73,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subsection,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subsectionTitle,
                                children: "Nossas Financeiras"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                lineNumber: 89,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$parceiros_financeiras_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].partnerGrid,
                                children: financeirasData.map((partner)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$partner_card_ds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        logoUrl: partner.logoUrl,
                                        name: partner.name,
                                        description: partner.description
                                    }, partner.id, false, {
                                        fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                        lineNumber: 92,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                                lineNumber: 90,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                        lineNumber: 88,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
                lineNumber: 66,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/devsolar/estructure/body/main/parceiros_financeiras_ds.js",
            lineNumber: 65,
            columnNumber: 13
        }, this)
    }, void 0, false);
}
_c = ParceirosFinanceirasSectionDS;
const __TURBOPACK__default__export__ = ParceirosFinanceirasSectionDS;
var _c;
__turbopack_context__.k.register(_c, "ParceirosFinanceirasSectionDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/devsolar/estructure/body/main/success_stories_ds.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "badge": "success_stories_ds-module__W60sga__badge",
  "badgePrimary": "success_stories_ds-module__W60sga__badgePrimary",
  "badgeSecondary": "success_stories_ds-module__W60sga__badgeSecondary",
  "badgesContainer": "success_stories_ds-module__W60sga__badgesContainer",
  "card-body": "success_stories_ds-module__W60sga__card-body",
  "cardShortDescription": "success_stories_ds-module__W60sga__cardShortDescription",
  "cardTitle": "success_stories_ds-module__W60sga__cardTitle",
  "carouselContainer": "success_stories_ds-module__W60sga__carouselContainer",
  "carouselPlaceholder": "success_stories_ds-module__W60sga__carouselPlaceholder",
  "detailsButton": "success_stories_ds-module__W60sga__detailsButton",
  "modalBodyText": "success_stories_ds-module__W60sga__modalBodyText",
  "modalFooter": "success_stories_ds-module__W60sga__modalFooter",
  "modalHeader": "success_stories_ds-module__W60sga__modalHeader",
  "modalTitle": "success_stories_ds-module__W60sga__modalTitle",
  "mySwiper": "success_stories_ds-module__W60sga__mySwiper",
  "sectionCases": "success_stories_ds-module__W60sga__sectionCases",
  "sectionSubtitle": "success_stories_ds-module__W60sga__sectionSubtitle",
  "sectionTitle": "success_stories_ds-module__W60sga__sectionTitle",
  "storyCard": "success_stories_ds-module__W60sga__storyCard",
  "swiper-button-next": "success_stories_ds-module__W60sga__swiper-button-next",
  "swiper-button-prev": "success_stories_ds-module__W60sga__swiper-button-prev",
  "swiper-pagination-bullet": "success_stories_ds-module__W60sga__swiper-pagination-bullet",
  "swiper-pagination-bullet-active": "success_stories_ds-module__W60sga__swiper-pagination-bullet-active",
  "swiperSlide": "success_stories_ds-module__W60sga__swiperSlide",
  "thumbnailContainer": "success_stories_ds-module__W60sga__thumbnailContainer",
  "thumbnailImage": "success_stories_ds-module__W60sga__thumbnailImage",
  "video": "success_stories_ds-module__W60sga__video",
});
}),
"[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SuccessStoriesDS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_context__.i("[project]/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript) <export default as Container>"); // Import Button
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$success_stories_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/devsolar/estructure/body/main/success_stories_ds.module.css [app-client] (css module)"); // Usaremos CSS Modules
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const SuccessStoriesCarousel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/components/devsolar/estructure/body/main/success_stories_carousel_client.js [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/devsolar/estructure/body/main/success_stories_carousel_client.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = SuccessStoriesCarousel;
function SuccessStoriesDS() {
    _s();
    const sectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [shouldRenderCarousel, setShouldRenderCarousel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SuccessStoriesDS.useEffect": ()=>{
            if (shouldRenderCarousel || !sectionRef.current || typeof IntersectionObserver === 'undefined') {
                return;
            }
            const observer = new IntersectionObserver({
                "SuccessStoriesDS.useEffect": (entries)=>{
                    const isVisible = entries.some({
                        "SuccessStoriesDS.useEffect.isVisible": (entry)=>entry.isIntersecting
                    }["SuccessStoriesDS.useEffect.isVisible"]);
                    if (isVisible) {
                        setShouldRenderCarousel(true);
                        observer.disconnect();
                    }
                }
            }["SuccessStoriesDS.useEffect"], {
                rootMargin: '300px 0px'
            });
            observer.observe(sectionRef.current);
            return ({
                "SuccessStoriesDS.useEffect": ()=>observer.disconnect()
            })["SuccessStoriesDS.useEffect"];
        }
    }["SuccessStoriesDS.useEffect"], [
        shouldRenderCarousel
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            ref: sectionRef,
            id: "cases",
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$success_stories_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionCases,
            "aria-labelledby": "cases-title",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-5 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                id: "cases-title",
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$success_stories_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle} fw-bold`,
                                children: "Cases de Sucesso"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$success_stories_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionSubtitle} lead`,
                                children: "Conheça quem já está economizando com energia solar"
                            }, void 0, false, {
                                fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
                                lineNumber: 56,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
                        lineNumber: 52,
                        columnNumber: 11
                    }, this),
                    shouldRenderCarousel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SuccessStoriesCarousel, {}, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
                        lineNumber: 62,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$devsolar$2f$estructure$2f$body$2f$main$2f$success_stories_ds$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].carouselPlaceholder,
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
                        lineNumber: 64,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
                lineNumber: 51,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/devsolar/estructure/body/main/success_stories_ds.js",
            lineNumber: 45,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(SuccessStoriesDS, "/yvgXCHctvyP34ZnQ5zKDtV54Pg=");
_c1 = SuccessStoriesDS;
var _c, _c1;
__turbopack_context__.k.register(_c, "SuccessStoriesCarousel");
__turbopack_context__.k.register(_c1, "SuccessStoriesDS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_19m_y5y._.js.map