(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_08a0sj_._.js","static/chunks/_19m_y5y._.js","static/chunks/node_modules_next_0fdic5-._.js","static/chunks/node_modules_@fortawesome_free-brands-svg-icons_index_mjs_0t4xi1y._.js","static/chunks/node_modules_@fortawesome_free-regular-svg-icons_index_mjs_0b0ovf3._.js","static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_1vn59s6._.js","static/chunks/node_modules_@fortawesome_fontawesome-svg-core_index_mjs_0_t21-z._.js","static/chunks/node_modules_react-bootstrap_esm_0in7661._.js","static/chunks/node_modules_157kit6._.js","static/chunks/src_components_devsolar_0ytont6._.css"],
    source: "dynamic"
});
