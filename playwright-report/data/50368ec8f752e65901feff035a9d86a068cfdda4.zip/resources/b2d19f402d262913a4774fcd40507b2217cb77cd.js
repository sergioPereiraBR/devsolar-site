(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript)"));
}),
]);