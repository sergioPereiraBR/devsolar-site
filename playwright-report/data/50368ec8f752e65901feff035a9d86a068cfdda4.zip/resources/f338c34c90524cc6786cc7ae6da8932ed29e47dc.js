(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0nk8_77._.css","static/chunks/node_modules_next_dist_1ui051e._.js"],
    source: "dynamic"
});
