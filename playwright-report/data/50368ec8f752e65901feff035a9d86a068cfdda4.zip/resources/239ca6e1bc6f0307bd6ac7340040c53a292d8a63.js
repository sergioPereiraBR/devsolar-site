(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/tremor/area-chart-15.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_lodash_1f0-mek._.js",
  "static/chunks/node_modules_recharts_es6_04_qd40._.js",
  "static/chunks/node_modules_0vyqxiy._.js",
  "static/chunks/src_1-txk2v._.js",
  "static/chunks/src_components_tremor_area-chart-15_tsx_1p06abq._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/tremor/area-chart-15.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/devsolar/estructure/body/header/LeadAccessModal.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_1l63jdo._.js",
  "static/chunks/src_components_devsolar_estructure_body_header_LeadAccessModal_1p06abq.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/devsolar/estructure/body/header/LeadAccessModal.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/node_modules/react-google-recaptcha/lib/esm/index.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_1uyxckz._.js",
  "static/chunks/node_modules_react-google-recaptcha_lib_esm_index_0bc28j-.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/react-google-recaptcha/lib/esm/index.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/node_modules/emoji-picker-react/dist/emoji-picker-react.esm.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_04k3oxe._.js",
  "static/chunks/node_modules_emoji-picker-react_dist_emoji-picker-react_esm_1p06abq.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/emoji-picker-react/dist/emoji-picker-react.esm.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_devsolar_utility_whatsapp_whatsapp_sender_ds_11ub4h1.js",
  "static/chunks/src_components_devsolar_utility_whatsapp_whatsapp_sender_ds_1p06abq.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/devsolar/utility/whatsapp/whatsapp_sender_ds.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/devsolar/estructure/body/main/location_map_ds.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_devsolar_estructure_body_main_location_map_ds_11_7k6w.js",
  "static/chunks/src_components_devsolar_estructure_body_main_location_map_ds_1p06abq.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/devsolar/estructure/body/main/location_map_ds.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/components/devsolar/estructure/body/main/success_stories_carousel_client.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_swiper_05nqgs9._.js",
  "static/chunks/src_1ab28fo._.js",
  {
    "path": "static/chunks/node_modules_swiper_0ope129._.css",
    "included": [
      "[project]/node_modules/swiper/swiper.css [app-client] (css)",
      "[project]/node_modules/swiper/modules/navigation.css [app-client] (css)",
      "[project]/node_modules/swiper/modules/pagination.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/node_modules_swiper_swiper_css_1igg3k2._.single.css",
      "static/chunks/node_modules_swiper_modules_navigation_css_1igg3k2._.single.css",
      "static/chunks/node_modules_swiper_modules_pagination_css_1igg3k2._.single.css"
    ]
  },
  "static/chunks/1x2-_devsolar_estructure_body_main_success_stories_carousel_client_1p06abq.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/devsolar/estructure/body/main/success_stories_carousel_client.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);