(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_devsolar_utility_whatsapp_whatsapp_sender_ds_11ub4h1.js"],
    source: "dynamic"
});
